import { Hono } from 'hono'
import type { Bindings } from '../index'
import { verifyToken } from './auth'

export const examRoutes = new Hono<{ Bindings: Bindings }>()

// GET /api/exams
examRoutes.get('/', async (c) => {
  const subjectId = c.req.query('subject_id')
  const examType = c.req.query('type')

  let query = `
    SELECT e.*, s.name as subject_name, s.color as subject_color, s.icon as subject_icon
    FROM exams e JOIN subjects s ON e.subject_id = s.id
    WHERE e.is_published = 1
  `
  const params: any[] = []
  if (subjectId) { query += ' AND e.subject_id = ?'; params.push(subjectId) }
  if (examType) { query += ' AND e.exam_type = ?'; params.push(examType) }
  query += ' ORDER BY e.year DESC, e.id DESC'

  const exams = await c.env.DB.prepare(query).bind(...params).all()
  return c.json({ exams: exams.results })
})

// GET /api/exams/:id
examRoutes.get('/:id', async (c) => {
  const id = c.req.param('id')
  const auth = c.req.header('Authorization')

  const exam = await c.env.DB.prepare(`
    SELECT e.*, s.name as subject_name, s.color as subject_color
    FROM exams e JOIN subjects s ON e.subject_id = s.id
    WHERE e.id = ? AND e.is_published = 1
  `).bind(id).first() as any

  if (!exam) return c.json({ error: 'Examen non trouvé' }, 404)

  let isSubscribed = false
  if (auth?.startsWith('Bearer ')) {
    const result = await verifyToken(auth.substring(7), c.env.DB)
    if (result) {
      const sub = await c.env.DB.prepare(`
        SELECT id FROM subscriptions 
        WHERE user_id = ? AND plan_id > 1 AND status = 'active' AND end_date > datetime('now')
      `).bind(result.userId).first()
      isSubscribed = !!sub
    }
  }

  if (!exam.is_free && !isSubscribed) {
    return c.json({ 
      exam: { ...exam, content: null, solution_content: null },
      requires_subscription: true 
    }, 403)
  }

  return c.json({ exam })
})
