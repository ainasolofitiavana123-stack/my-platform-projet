import { Hono } from 'hono'
import type { Bindings } from '../index'
import { verifyToken } from './auth'

export const quizRoutes = new Hono<{ Bindings: Bindings }>()

// GET /api/quiz - Liste des quiz
quizRoutes.get('/', async (c) => {
  const subjectId = c.req.query('subject_id')
  const difficulty = c.req.query('difficulty')
  
  let query = `
    SELECT q.*, s.name as subject_name, s.color as subject_color, s.icon as subject_icon,
      ch.title as chapter_title,
      (SELECT COUNT(*) FROM questions WHERE quiz_id = q.id) as question_count
    FROM quizzes q
    JOIN subjects s ON q.subject_id = s.id
    LEFT JOIN chapters ch ON q.chapter_id = ch.id
    WHERE q.is_published = 1
  `
  const params: any[] = []
  
  if (subjectId) { query += ' AND q.subject_id = ?'; params.push(subjectId) }
  if (difficulty) { query += ' AND q.difficulty = ?'; params.push(difficulty) }
  query += ' ORDER BY q.id DESC'

  const quizzes = await c.env.DB.prepare(query).bind(...params).all()
  return c.json({ quizzes: quizzes.results })
})

// GET /api/quiz/:id - Détail quiz (sans réponses)
quizRoutes.get('/:id', async (c) => {
  const id = c.req.param('id')
  const auth = c.req.header('Authorization')

  const quiz = await c.env.DB.prepare(`
    SELECT q.*, s.name as subject_name, s.color as subject_color,
      (SELECT COUNT(*) FROM questions WHERE quiz_id = q.id) as question_count
    FROM quizzes q JOIN subjects s ON q.subject_id = s.id
    WHERE q.id = ? AND q.is_published = 1
  `).bind(id).first() as any

  if (!quiz) return c.json({ error: 'Quiz non trouvé' }, 404)

  let userId = null
  let isSubscribed = false
  let attemptCount = 0

  if (auth?.startsWith('Bearer ')) {
    const result = await verifyToken(auth.substring(7), c.env.DB)
    if (result) {
      userId = result.userId
      const sub = await c.env.DB.prepare(`
        SELECT id FROM subscriptions 
        WHERE user_id = ? AND plan_id > 1 AND status = 'active' AND end_date > datetime('now')
      `).bind(userId).first()
      isSubscribed = !!sub
      
      const attempts = await c.env.DB.prepare(
        'SELECT COUNT(*) as count FROM quiz_attempts WHERE user_id = ? AND quiz_id = ?'
      ).bind(userId, id).first() as any
      attemptCount = attempts?.count || 0
    }
  }

  if (!quiz.is_free && !isSubscribed) {
    return c.json({ 
      quiz: { ...quiz, questions: [] }, 
      requires_subscription: true 
    }, 403)
  }

  // Get questions (without correct answers)
  const questions = await c.env.DB.prepare(`
    SELECT id, question_text, question_type, options, points, order_index
    FROM questions WHERE quiz_id = ? ORDER BY order_index ASC
  `).bind(id).all()

  return c.json({ 
    quiz, 
    questions: questions.results,
    attempt_count: attemptCount,
    can_attempt: attemptCount < quiz.max_attempts
  })
})

// POST /api/quiz/:id/submit - Soumettre réponses
quizRoutes.post('/:id/submit', async (c) => {
  const id = c.req.param('id')
  const auth = c.req.header('Authorization')

  if (!auth?.startsWith('Bearer ')) return c.json({ error: 'Non authentifié' }, 401)
  const authResult = await verifyToken(auth.substring(7), c.env.DB)
  if (!authResult) return c.json({ error: 'Token invalide' }, 401)

  const userId = authResult.userId
  const { answers, time_taken } = await c.req.json()

  const quiz = await c.env.DB.prepare('SELECT * FROM quizzes WHERE id = ? AND is_published = 1').bind(id).first() as any
  if (!quiz) return c.json({ error: 'Quiz non trouvé' }, 404)

  // Check max attempts
  const attemptCount = await c.env.DB.prepare(
    'SELECT COUNT(*) as count FROM quiz_attempts WHERE user_id = ? AND quiz_id = ?'
  ).bind(userId, id).first() as any

  if (attemptCount.count >= quiz.max_attempts) {
    return c.json({ error: 'Nombre maximum de tentatives atteint' }, 400)
  }

  // Get correct answers
  const questions = await c.env.DB.prepare(
    'SELECT * FROM questions WHERE quiz_id = ? ORDER BY order_index ASC'
  ).bind(id).all() as any

  let score = 0
  let totalPoints = 0
  const results: any[] = []

  for (const q of questions.results) {
    totalPoints += q.points
    const userAnswer = answers[q.id]
    const isCorrect = userAnswer === q.correct_answer
    if (isCorrect) score += q.points
    
    results.push({
      question_id: q.id,
      question_text: q.question_text,
      user_answer: userAnswer,
      correct_answer: q.correct_answer,
      is_correct: isCorrect,
      explanation: q.explanation,
      points: q.points
    })
  }

  const percentage = totalPoints > 0 ? Math.round((score / totalPoints) * 100) : 0
  const passed = percentage >= quiz.passing_score
  const attemptNumber = (attemptCount.count || 0) + 1

  // Save attempt
  await c.env.DB.prepare(`
    INSERT INTO quiz_attempts (user_id, quiz_id, score, total_points, answers, time_taken_seconds, passed, attempt_number)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(userId, id, score, totalPoints, JSON.stringify(answers), time_taken || 0, passed ? 1 : 0, attemptNumber).run()

  // Send notification
  const notifMsg = passed 
    ? `Félicitations! Vous avez réussi le quiz "${quiz.title}" avec ${percentage}%! 🎉`
    : `Quiz "${quiz.title}" terminé. Score: ${percentage}%. Continuez vos efforts! 💪`
  
  await c.env.DB.prepare(
    'INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)'
  ).bind(userId, passed ? 'Quiz réussi! 🎉' : 'Quiz terminé', notifMsg, passed ? 'success' : 'info').run()

  return c.json({ score, total_points: totalPoints, percentage, passed, results, attempt_number: attemptNumber })
})

// GET /api/quiz/:id/history - Historique tentatives
quizRoutes.get('/:id/history', async (c) => {
  const id = c.req.param('id')
  const auth = c.req.header('Authorization')

  if (!auth?.startsWith('Bearer ')) return c.json({ error: 'Non authentifié' }, 401)
  const result = await verifyToken(auth.substring(7), c.env.DB)
  if (!result) return c.json({ error: 'Token invalide' }, 401)

  const attempts = await c.env.DB.prepare(`
    SELECT * FROM quiz_attempts 
    WHERE user_id = ? AND quiz_id = ? 
    ORDER BY completed_at DESC
  `).bind(result.userId, id).all()

  return c.json({ attempts: attempts.results })
})
