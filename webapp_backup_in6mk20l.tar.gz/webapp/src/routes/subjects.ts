import { Hono } from 'hono'
import type { Bindings } from '../index'
import { verifyToken } from './auth'

export const subjectsRoutes = new Hono<{ Bindings: Bindings }>()

// GET /api/subjects - Liste des matières
subjectsRoutes.get('/', async (c) => {
  const classLevel = c.req.query('class_level') || 'terminale_a1'
  
  const subjects = await c.env.DB.prepare(`
    SELECT s.*, 
      (SELECT COUNT(*) FROM chapters ch WHERE ch.subject_id = s.id AND ch.is_published = 1) as chapter_count,
      (SELECT COUNT(*) FROM lessons l JOIN chapters ch ON l.chapter_id = ch.id WHERE ch.subject_id = s.id AND l.is_published = 1) as lesson_count,
      (SELECT COUNT(*) FROM quizzes q WHERE q.subject_id = s.id AND q.is_published = 1) as quiz_count
    FROM subjects s 
    WHERE s.is_active = 1 AND s.class_levels LIKE ?
    ORDER BY s.order_index ASC
  `).bind(`%${classLevel}%`).all()

  return c.json({ subjects: subjects.results })
})

// GET /api/subjects/:id - Détail matière
subjectsRoutes.get('/:id', async (c) => {
  const id = c.req.param('id')
  
  const subject = await c.env.DB.prepare('SELECT * FROM subjects WHERE id = ? AND is_active = 1').bind(id).first()
  if (!subject) return c.json({ error: 'Matière non trouvée' }, 404)

  // Get chapters with lesson counts
  const chapters = await c.env.DB.prepare(`
    SELECT ch.*,
      (SELECT COUNT(*) FROM lessons l WHERE l.chapter_id = ch.id AND l.is_published = 1) as lesson_count
    FROM chapters ch
    WHERE ch.subject_id = ? AND ch.is_published = 1
    ORDER BY ch.order_index ASC
  `).bind(id).all()

  const quizzes = await c.env.DB.prepare(`
    SELECT id, title, description, duration_minutes, passing_score, is_free, difficulty,
      (SELECT COUNT(*) FROM questions q WHERE q.quiz_id = quizzes.id) as question_count
    FROM quizzes 
    WHERE subject_id = ? AND is_published = 1
    ORDER BY id ASC
  `).bind(id).all()

  return c.json({ subject, chapters: chapters.results, quizzes: quizzes.results })
})

// GET /api/subjects/:id/chapters/:chapterId/lessons
subjectsRoutes.get('/:id/chapters/:chapterId/lessons', async (c) => {
  const { id, chapterId } = c.req.param()
  const auth = c.req.header('Authorization')
  
  let isSubscribed = false
  if (auth?.startsWith('Bearer ')) {
    const result = await verifyToken(auth.substring(7), c.env.DB)
    if (result) {
      const sub = await c.env.DB.prepare(`
        SELECT id FROM subscriptions 
        WHERE user_id = ? AND plan_id > 1 AND status = 'active' AND end_date > datetime('now')
      `).bind(result.userId).first()
      isSubscribed = !!sub
    }
  }

  const lessons = await c.env.DB.prepare(`
    SELECT id, title, lesson_type, duration_minutes, order_index, is_free,
      ${isSubscribed ? 'content,' : '"",'} media_url, view_count
    FROM lessons 
    WHERE chapter_id = ? AND is_published = 1
    ORDER BY order_index ASC
  `).bind(chapterId).all()

  return c.json({ lessons: lessons.results, is_subscribed: isSubscribed })
})
