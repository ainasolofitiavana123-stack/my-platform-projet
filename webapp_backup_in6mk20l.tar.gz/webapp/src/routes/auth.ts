import { Hono } from 'hono'
import type { Bindings } from '../index'

export const authRoutes = new Hono<{ Bindings: Bindings }>()

// Helper: Generate simple token
function generateToken(userId: number, secret: string = 'terminale-mg-secret'): string {
  const payload = btoa(JSON.stringify({ userId, exp: Date.now() + 30 * 24 * 60 * 60 * 1000 }))
  return `token_${userId}_${payload}`
}

// Helper: Hash password (simple - production should use bcrypt)
async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder()
  const data = encoder.encode(password + 'terminale-mg-salt')
  const hash = await crypto.subtle.digest('SHA-256', data)
  return btoa(String.fromCharCode(...new Uint8Array(hash)))
}

// Helper: Verify token
export async function verifyToken(token: string, db: D1Database): Promise<{ userId: number, user: any } | null> {
  try {
    const session = await db.prepare(
      'SELECT s.*, u.* FROM sessions s JOIN users u ON s.user_id = u.id WHERE s.token = ? AND s.expires_at > datetime("now")'
    ).bind(token).first() as any
    if (!session) return null
    return { userId: session.user_id, user: session }
  } catch {
    return null
  }
}

// Middleware helper
export async function requireAuth(c: any, next: any) {
  const auth = c.req.header('Authorization')
  if (!auth?.startsWith('Bearer ')) {
    return c.json({ error: 'Non authentifié' }, 401)
  }
  const token = auth.substring(7)
  const result = await verifyToken(token, c.env.DB)
  if (!result) {
    return c.json({ error: 'Token invalide ou expiré' }, 401)
  }
  c.set('userId', result.userId)
  c.set('user', result.user)
  return next()
}

// POST /api/auth/register
authRoutes.post('/register', async (c) => {
  try {
    const { email, password, full_name, class_level } = await c.req.json()

    if (!email || !password || !full_name) {
      return c.json({ error: 'Tous les champs sont requis' }, 400)
    }

    if (password.length < 6) {
      return c.json({ error: 'Le mot de passe doit contenir au moins 6 caractères' }, 400)
    }

    // Check existing user
    const existing = await c.env.DB.prepare('SELECT id FROM users WHERE email = ?').bind(email).first()
    if (existing) {
      return c.json({ error: 'Cet email est déjà utilisé' }, 409)
    }

    const passwordHash = await hashPassword(password)

    // Create user
    const result = await c.env.DB.prepare(
      'INSERT INTO users (email, password_hash, full_name, class_level, role) VALUES (?, ?, ?, ?, "student")'
    ).bind(email, passwordHash, full_name, class_level || 'terminale_a1').run()

    const userId = result.meta.last_row_id as number

    // Create free subscription
    const endDate = new Date()
    endDate.setFullYear(endDate.getFullYear() + 100)
    await c.env.DB.prepare(
      'INSERT INTO subscriptions (user_id, plan_id, end_date, status) VALUES (?, 1, ?, "active")'
    ).bind(userId, endDate.toISOString()).run()

    // Create session token
    const token = generateToken(userId)
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
    await c.env.DB.prepare(
      'INSERT INTO sessions (user_id, token, expires_at) VALUES (?, ?, ?)'
    ).bind(userId, token, expiresAt).run()

    // Create welcome notification
    await c.env.DB.prepare(
      'INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, "success")'
    ).bind(userId, 'Bienvenue sur Terminale Madagascar! 🎉', 
      'Votre compte a été créé avec succès. Commencez à explorer nos cours!').run()

    const user = await c.env.DB.prepare('SELECT id, email, full_name, role, class_level, avatar FROM users WHERE id = ?').bind(userId).first()

    return c.json({ token, user }, 201)
  } catch (err: any) {
    return c.json({ error: err.message || 'Erreur lors de l\'inscription' }, 500)
  }
})

// POST /api/auth/login
authRoutes.post('/login', async (c) => {
  try {
    const { email, password } = await c.req.json()

    if (!email || !password) {
      return c.json({ error: 'Email et mot de passe requis' }, 400)
    }

    const user = await c.env.DB.prepare(
      'SELECT * FROM users WHERE email = ? AND is_active = 1'
    ).bind(email).first() as any

    if (!user) {
      return c.json({ error: 'Email ou mot de passe incorrect' }, 401)
    }

    const passwordHash = await hashPassword(password)
    if (user.password_hash !== passwordHash) {
      return c.json({ error: 'Email ou mot de passe incorrect' }, 401)
    }

    // Create new session
    const token = generateToken(user.id)
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
    await c.env.DB.prepare(
      'INSERT INTO sessions (user_id, token, expires_at) VALUES (?, ?, ?)'
    ).bind(user.id, token, expiresAt).run()

    // Get active subscription
    const subscription = await c.env.DB.prepare(`
      SELECT s.*, sp.name as plan_name, sp.features 
      FROM subscriptions s 
      JOIN subscription_plans sp ON s.plan_id = sp.id 
      WHERE s.user_id = ? AND s.status = 'active' AND s.end_date > datetime('now')
      ORDER BY s.end_date DESC LIMIT 1
    `).bind(user.id).first() as any

    return c.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        full_name: user.full_name,
        role: user.role,
        class_level: user.class_level,
        avatar: user.avatar
      },
      subscription: subscription ? {
        plan_name: subscription.plan_name,
        end_date: subscription.end_date,
        status: subscription.status
      } : null
    })
  } catch (err: any) {
    return c.json({ error: err.message || 'Erreur de connexion' }, 500)
  }
})

// POST /api/auth/logout
authRoutes.post('/logout', async (c) => {
  const auth = c.req.header('Authorization')
  if (auth?.startsWith('Bearer ')) {
    const token = auth.substring(7)
    await c.env.DB.prepare('DELETE FROM sessions WHERE token = ?').bind(token).run()
  }
  return c.json({ message: 'Déconnecté avec succès' })
})

// GET /api/auth/me
authRoutes.get('/me', async (c) => {
  const auth = c.req.header('Authorization')
  if (!auth?.startsWith('Bearer ')) {
    return c.json({ error: 'Non authentifié' }, 401)
  }
  const token = auth.substring(7)
  const result = await verifyToken(token, c.env.DB)
  if (!result) {
    return c.json({ error: 'Token invalide' }, 401)
  }

  const user = await c.env.DB.prepare(
    'SELECT id, email, full_name, role, class_level, avatar, created_at FROM users WHERE id = ?'
  ).bind(result.userId).first()

  const subscription = await c.env.DB.prepare(`
    SELECT s.*, sp.name as plan_name, sp.features, sp.price_ariary, sp.price_dollar
    FROM subscriptions s 
    JOIN subscription_plans sp ON s.plan_id = sp.id 
    WHERE s.user_id = ? AND s.status = 'active' AND s.end_date > datetime('now')
    ORDER BY s.end_date DESC LIMIT 1
  `).bind(result.userId).first() as any

  const unreadNotifs = await c.env.DB.prepare(
    'SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0'
  ).bind(result.userId).first() as any

  return c.json({ 
    user, 
    subscription: subscription ? {
      plan_id: subscription.plan_id,
      plan_name: subscription.plan_name,
      end_date: subscription.end_date,
      features: subscription.features,
      price_ariary: subscription.price_ariary,
      price_dollar: subscription.price_dollar
    } : null,
    unread_notifications: unreadNotifs?.count || 0
  })
})
