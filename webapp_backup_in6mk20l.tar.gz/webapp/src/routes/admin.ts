import { Hono } from 'hono'
import type { Bindings } from '../index'
import { verifyToken } from './auth'

export const adminRoutes = new Hono<{ Bindings: Bindings }>()

// Middleware admin
async function requireAdmin(c: any, next: any) {
  const auth = c.req.header('Authorization')
  if (!auth?.startsWith('Bearer ')) return c.json({ error: 'Non authentifié' }, 401)
  const result = await verifyToken(auth.substring(7), c.env.DB)
  if (!result) return c.json({ error: 'Token invalide' }, 401)
  
  const user = await c.env.DB.prepare('SELECT role FROM users WHERE id = ?').bind(result.userId).first() as any
  if (!user || (user.role !== 'admin' && user.role !== 'teacher')) {
    return c.json({ error: 'Accès refusé - Admin requis' }, 403)
  }
  
  c.set('userId', result.userId)
  c.set('userRole', user.role)
  return next()
}

// GET /api/admin/stats
adminRoutes.get('/stats', requireAdmin, async (c) => {
  const [users, subscriptions, lessons, quizAttempts] = await Promise.all([
    c.env.DB.prepare('SELECT COUNT(*) as count FROM users WHERE role = "student"').first() as any,
    c.env.DB.prepare('SELECT COUNT(*) as count FROM subscriptions WHERE status = "active" AND end_date > datetime("now") AND plan_id > 1').first() as any,
    c.env.DB.prepare('SELECT COUNT(*) as count FROM lessons').first() as any,
    c.env.DB.prepare('SELECT COUNT(*) as count FROM quiz_attempts').first() as any,
  ])

  const recentUsers = await c.env.DB.prepare(`
    SELECT id, email, full_name, class_level, created_at FROM users 
    WHERE role = 'student' ORDER BY created_at DESC LIMIT 10
  `).all()

  const recentPayments = await c.env.DB.prepare(`
    SELECT p.*, u.full_name, u.email FROM payments p
    JOIN users u ON p.user_id = u.id
    ORDER BY p.created_at DESC LIMIT 10
  `).all()

  return c.json({
    stats: {
      total_students: users?.count || 0,
      active_subscriptions: subscriptions?.count || 0,
      total_lessons: lessons?.count || 0,
      total_quiz_attempts: quizAttempts?.count || 0
    },
    recent_users: recentUsers.results,
    recent_payments: recentPayments.results
  })
})

// GET /api/admin/users
adminRoutes.get('/users', requireAdmin, async (c) => {
  const page = parseInt(c.req.query('page') || '1')
  const limit = 20
  const offset = (page - 1) * limit

  const users = await c.env.DB.prepare(`
    SELECT u.*, 
      (SELECT sp.name FROM subscriptions s JOIN subscription_plans sp ON s.plan_id = sp.id 
       WHERE s.user_id = u.id AND s.status = 'active' AND s.end_date > datetime('now') 
       ORDER BY s.end_date DESC LIMIT 1) as current_plan
    FROM users u
    ORDER BY u.created_at DESC
    LIMIT ? OFFSET ?
  `).bind(limit, offset).all()

  const total = await c.env.DB.prepare('SELECT COUNT(*) as count FROM users').first() as any

  return c.json({ users: users.results, total: total?.count || 0, page, limit })
})

// POST /api/admin/announcements
adminRoutes.post('/announcements', requireAdmin, async (c) => {
  const userId = c.get('userId')
  const { title, content, target_audience, is_pinned } = await c.req.json()

  const result = await c.env.DB.prepare(`
    INSERT INTO announcements (title, content, author_id, target_audience, is_pinned, is_published)
    VALUES (?, ?, ?, ?, ?, 1)
  `).bind(title, content, userId, target_audience || 'all', is_pinned ? 1 : 0).run()

  return c.json({ id: result.meta.last_row_id, message: 'Annonce publiée' }, 201)
})

// GET /api/admin/announcements
adminRoutes.get('/announcements', requireAdmin, async (c) => {
  const announcements = await c.env.DB.prepare(`
    SELECT a.*, u.full_name as author_name FROM announcements a
    JOIN users u ON a.author_id = u.id
    ORDER BY a.created_at DESC
  `).all()
  return c.json({ announcements: announcements.results })
})
