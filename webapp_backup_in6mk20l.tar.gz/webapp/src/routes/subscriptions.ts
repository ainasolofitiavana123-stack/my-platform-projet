import { Hono } from 'hono'
import type { Bindings } from '../index'
import { verifyToken } from './auth'

export const subscriptionRoutes = new Hono<{ Bindings: Bindings }>()

// GET /api/subscriptions/plans
subscriptionRoutes.get('/plans', async (c) => {
  const plans = await c.env.DB.prepare(
    'SELECT * FROM subscription_plans WHERE is_active = 1 ORDER BY price_ariary ASC'
  ).all()
  return c.json({ plans: plans.results })
})

// GET /api/subscriptions/my
subscriptionRoutes.get('/my', async (c) => {
  const auth = c.req.header('Authorization')
  if (!auth?.startsWith('Bearer ')) return c.json({ error: 'Non authentifié' }, 401)
  const result = await verifyToken(auth.substring(7), c.env.DB)
  if (!result) return c.json({ error: 'Token invalide' }, 401)

  const subscriptions = await c.env.DB.prepare(`
    SELECT s.*, sp.name as plan_name, sp.features, sp.price_ariary, sp.price_dollar
    FROM subscriptions s
    JOIN subscription_plans sp ON s.plan_id = sp.id
    WHERE s.user_id = ?
    ORDER BY s.created_at DESC
  `).bind(result.userId).all()

  return c.json({ subscriptions: subscriptions.results })
})

// POST /api/subscriptions/subscribe
subscriptionRoutes.post('/subscribe', async (c) => {
  const auth = c.req.header('Authorization')
  if (!auth?.startsWith('Bearer ')) return c.json({ error: 'Non authentifié' }, 401)
  const authResult = await verifyToken(auth.substring(7), c.env.DB)
  if (!authResult) return c.json({ error: 'Token invalide' }, 401)

  const userId = authResult.userId
  const { plan_id, payment_method, payment_reference, currency } = await c.req.json()

  const plan = await c.env.DB.prepare(
    'SELECT * FROM subscription_plans WHERE id = ? AND is_active = 1'
  ).bind(plan_id).first() as any

  if (!plan) return c.json({ error: 'Plan non trouvé' }, 404)

  // Check existing active subscription
  const existing = await c.env.DB.prepare(`
    SELECT * FROM subscriptions 
    WHERE user_id = ? AND status = 'active' AND end_date > datetime('now') AND plan_id > 1
  `).bind(userId).first() as any

  const startDate = new Date()
  let endDate: Date

  if (existing && new Date(existing.end_date) > startDate) {
    // Extend existing subscription
    endDate = new Date(existing.end_date)
    endDate.setDate(endDate.getDate() + plan.duration_days)
  } else {
    endDate = new Date()
    endDate.setDate(endDate.getDate() + plan.duration_days)
  }

  const amount = currency === 'USD' ? Math.round(plan.price_dollar * 100) : plan.price_ariary

  // Create payment record
  const paymentResult = await c.env.DB.prepare(`
    INSERT INTO payments (user_id, amount, currency, payment_method, transaction_id, status)
    VALUES (?, ?, ?, ?, ?, 'completed')
  `).bind(userId, amount, currency || 'MGA', payment_method || 'manual', 
    payment_reference || `TXN-${Date.now()}`).run()

  const paymentId = paymentResult.meta.last_row_id

  // Create/update subscription
  const subResult = await c.env.DB.prepare(`
    INSERT INTO subscriptions (user_id, plan_id, end_date, status, payment_method, payment_reference, amount_paid, currency)
    VALUES (?, ?, ?, 'active', ?, ?, ?, ?)
  `).bind(userId, plan_id, endDate.toISOString(), payment_method || 'manual', 
    payment_reference || `TXN-${Date.now()}`, amount, currency || 'MGA').run()

  // Update payment with subscription id
  await c.env.DB.prepare(
    'UPDATE payments SET subscription_id = ? WHERE id = ?'
  ).bind(subResult.meta.last_row_id, paymentId).run()

  // Notification
  await c.env.DB.prepare(
    'INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, "success")'
  ).bind(userId, 'Abonnement activé! 🎉', 
    `Votre abonnement "${plan.name}" est maintenant actif jusqu'au ${endDate.toLocaleDateString('fr-FR')}`).run()

  return c.json({ 
    message: 'Abonnement activé avec succès!',
    end_date: endDate.toISOString(),
    plan: plan.name
  }, 201)
})

// GET /api/subscriptions/check-access
subscriptionRoutes.get('/check-access', async (c) => {
  const auth = c.req.header('Authorization')
  if (!auth?.startsWith('Bearer ')) return c.json({ has_access: false })
  
  const result = await verifyToken(auth.substring(7), c.env.DB)
  if (!result) return c.json({ has_access: false })

  const sub = await c.env.DB.prepare(`
    SELECT s.*, sp.name FROM subscriptions s
    JOIN subscription_plans sp ON s.plan_id = sp.id
    WHERE s.user_id = ? AND s.plan_id > 1 AND s.status = 'active' AND s.end_date > datetime('now')
    ORDER BY s.end_date DESC LIMIT 1
  `).bind(result.userId).first() as any

  return c.json({ 
    has_access: !!sub,
    plan: sub?.name || 'Gratuit',
    end_date: sub?.end_date || null
  })
})
