import { Hono } from 'hono'
import type { Bindings } from '../index'
import { verifyToken } from './auth'

export const lessonsRoutes = new Hono<{ Bindings: Bindings }>()

// GET /api/lessons/:id
lessonsRoutes.get('/:id', async (c) => {
  const id = c.req.param('id')
  const auth = c.req.header('Authorization')
  
  const lesson = await c.env.DB.prepare(`
    SELECT l.*, ch.title as chapter_title, ch.subject_id,
      s.name as subject_name, s.color as subject_color
    FROM lessons l
    JOIN chapters ch ON l.chapter_id = ch.id
    JOIN subjects s ON ch.subject_id = s.id
    WHERE l.id = ? AND l.is_published = 1
  `).bind(id).first() as any

  if (!lesson) return c.json({ error: 'Leçon non trouvée' }, 404)

  let userId = null
  let isSubscribed = false

  if (auth?.startsWith('Bearer ')) {
    const result = await verifyToken(auth.substring(7), c.env.DB)
    if (result) {
      userId = result.userId
      const sub = await c.env.DB.prepare(`
        SELECT id FROM subscriptions 
        WHERE user_id = ? AND plan_id > 1 AND status = 'active' AND end_date > datetime('now')
      `).bind(userId).first()
      isSubscribed = !!sub
    }
  }

  // Check access
  if (!lesson.is_free && !isSubscribed) {
    return c.json({ 
      error: 'Abonnement requis', 
      lesson: { id: lesson.id, title: lesson.title, is_free: false },
      requires_subscription: true 
    }, 403)
  }

  // Track view count
  await c.env.DB.prepare('UPDATE lessons SET view_count = view_count + 1 WHERE id = ?').bind(id).run()

  // Get progress if logged in
  let progress = null
  if (userId) {
    progress = await c.env.DB.prepare(
      'SELECT * FROM lesson_progress WHERE user_id = ? AND lesson_id = ?'
    ).bind(userId, id).first()
  }

  // Get next/prev lessons
  const siblings = await c.env.DB.prepare(`
    SELECT id, title, order_index FROM lessons 
    WHERE chapter_id = ? AND is_published = 1 ORDER BY order_index ASC
  `).bind(lesson.chapter_id).all() as any

  const currentIndex = siblings.results.findIndex((l: any) => l.id === parseInt(id))
  const prevLesson = currentIndex > 0 ? siblings.results[currentIndex - 1] : null
  const nextLesson = currentIndex < siblings.results.length - 1 ? siblings.results[currentIndex + 1] : null

  return c.json({ lesson, progress, prevLesson, nextLesson })
})

// POST /api/lessons/:id/complete
lessonsRoutes.post('/:id/complete', async (c) => {
  const id = c.req.param('id')
  const auth = c.req.header('Authorization')
  
  if (!auth?.startsWith('Bearer ')) return c.json({ error: 'Non authentifié' }, 401)
  const result = await verifyToken(auth.substring(7), c.env.DB)
  if (!result) return c.json({ error: 'Token invalide' }, 401)

  await c.env.DB.prepare(`
    INSERT INTO lesson_progress (user_id, lesson_id, is_completed, completed_at)
    VALUES (?, ?, 1, datetime('now'))
    ON CONFLICT(user_id, lesson_id) DO UPDATE SET is_completed = 1, completed_at = datetime('now')
  `).bind(result.userId, id).run()

  return c.json({ message: 'Leçon marquée comme complétée' })
})
