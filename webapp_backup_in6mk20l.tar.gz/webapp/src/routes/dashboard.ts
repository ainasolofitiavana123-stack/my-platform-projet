import { Hono } from 'hono'
import type { Bindings } from '../index'
import { verifyToken } from './auth'

export const dashboardRoutes = new Hono<{ Bindings: Bindings }>()

// GET /api/dashboard
dashboardRoutes.get('/', async (c) => {
  const auth = c.req.header('Authorization')
  if (!auth?.startsWith('Bearer ')) return c.json({ error: 'Non authentifié' }, 401)
  const result = await verifyToken(auth.substring(7), c.env.DB)
  if (!result) return c.json({ error: 'Token invalide' }, 401)

  const userId = result.userId

  // Stats
  const completedLessons = await c.env.DB.prepare(
    'SELECT COUNT(*) as count FROM lesson_progress WHERE user_id = ? AND is_completed = 1'
  ).bind(userId).first() as any

  const quizAttempts = await c.env.DB.prepare(
    'SELECT COUNT(*) as count, AVG(score * 100.0 / NULLIF(total_points, 0)) as avg_score FROM quiz_attempts WHERE user_id = ?'
  ).bind(userId).first() as any

  const passedQuizzes = await c.env.DB.prepare(
    'SELECT COUNT(*) as count FROM quiz_attempts WHERE user_id = ? AND passed = 1'
  ).bind(userId).first() as any

  // Recent activity
  const recentLessons = await c.env.DB.prepare(`
    SELECT lp.*, l.title as lesson_title, s.name as subject_name, s.color, s.icon
    FROM lesson_progress lp
    JOIN lessons l ON lp.lesson_id = l.id
    JOIN chapters ch ON l.chapter_id = ch.id
    JOIN subjects s ON ch.subject_id = s.id
    WHERE lp.user_id = ?
    ORDER BY lp.created_at DESC LIMIT 5
  `).bind(userId).all()

  const recentQuizzes = await c.env.DB.prepare(`
    SELECT qa.*, qz.title as quiz_title, s.name as subject_name, s.color
    FROM quiz_attempts qa
    JOIN quizzes qz ON qa.quiz_id = qz.id
    JOIN subjects s ON qz.subject_id = s.id
    WHERE qa.user_id = ?
    ORDER BY qa.completed_at DESC LIMIT 5
  `).bind(userId).all()

  // Subscription info
  const subscription = await c.env.DB.prepare(`
    SELECT s.*, sp.name as plan_name, sp.features
    FROM subscriptions s JOIN subscription_plans sp ON s.plan_id = sp.id
    WHERE s.user_id = ? AND s.status = 'active' AND s.end_date > datetime('now')
    ORDER BY s.end_date DESC LIMIT 1
  `).bind(userId).first() as any

  // Notifications
  const notifications = await c.env.DB.prepare(`
    SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 10
  `).bind(userId).all()

  // Announcements
  const announcements = await c.env.DB.prepare(`
    SELECT a.*, u.full_name as author_name FROM announcements a
    JOIN users u ON a.author_id = u.id
    WHERE a.is_published = 1
    ORDER BY a.is_pinned DESC, a.created_at DESC LIMIT 5
  `).all()

  return c.json({
    stats: {
      completed_lessons: completedLessons?.count || 0,
      quiz_attempts: quizAttempts?.count || 0,
      avg_quiz_score: Math.round(quizAttempts?.avg_score || 0),
      passed_quizzes: passedQuizzes?.count || 0
    },
    subscription: subscription ? {
      plan_name: subscription.plan_name,
      end_date: subscription.end_date,
      status: subscription.status
    } : null,
    recent_lessons: recentLessons.results,
    recent_quizzes: recentQuizzes.results,
    notifications: notifications.results,
    announcements: announcements.results
  })
})

// GET /api/dashboard/notifications
dashboardRoutes.get('/notifications', async (c) => {
  const auth = c.req.header('Authorization')
  if (!auth?.startsWith('Bearer ')) return c.json({ error: 'Non authentifié' }, 401)
  const result = await verifyToken(auth.substring(7), c.env.DB)
  if (!result) return c.json({ error: 'Token invalide' }, 401)

  const notifications = await c.env.DB.prepare(`
    SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 20
  `).bind(result.userId).all()

  return c.json({ notifications: notifications.results })
})

// POST /api/dashboard/notifications/read
dashboardRoutes.post('/notifications/read', async (c) => {
  const auth = c.req.header('Authorization')
  if (!auth?.startsWith('Bearer ')) return c.json({ error: 'Non authentifié' }, 401)
  const result = await verifyToken(auth.substring(7), c.env.DB)
  if (!result) return c.json({ error: 'Token invalide' }, 401)

  await c.env.DB.prepare(
    'UPDATE notifications SET is_read = 1 WHERE user_id = ?'
  ).bind(result.userId).run()

  return c.json({ message: 'Notifications marquées comme lues' })
})
