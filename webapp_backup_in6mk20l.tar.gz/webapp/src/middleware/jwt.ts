// ============================================
// MIDDLEWARE - JWT stateless (sans sessions DB)
// ============================================

import { APP_CONFIG } from '../config/app.config'

export type JWTPayload = {
  userId: number
  email: string
  role: string
  class_level: string
  iat: number
  exp: number
}

// Encode base64url
function b64url(str: string): string {
  return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '')
}

// Decode base64url
function fromb64url(str: string): string {
  str = str.replace(/-/g, '+').replace(/_/g, '/')
  while (str.length % 4) str += '='
  return atob(str)
}

// HMAC-SHA256 signature
async function hmacSign(data: string, secret: string): Promise<string> {
  const encoder = new TextEncoder()
  const key = await crypto.subtle.importKey(
    'raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  )
  const sig = await crypto.subtle.sign('HMAC', key, encoder.encode(data))
  return b64url(String.fromCharCode(...new Uint8Array(sig)))
}

// Générer un JWT stateless
export async function generateJWT(payload: Omit<JWTPayload, 'iat' | 'exp'>, secret: string = APP_CONFIG.jwt_secret): Promise<string> {
  const header = b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }))
  const now = Math.floor(Date.now() / 1000)
  const fullPayload = b64url(JSON.stringify({ ...payload, iat: now, exp: now + 30 * 24 * 60 * 60 }))
  const sig = await hmacSign(`${header}.${fullPayload}`, secret)
  return `${header}.${fullPayload}.${sig}`
}

// Vérifier et décoder un JWT stateless
export async function verifyJWT(token: string, secret: string = APP_CONFIG.jwt_secret): Promise<JWTPayload | null> {
  try {
    const parts = token.split('.')
    if (parts.length !== 3) return null
    const [header, payload, sig] = parts
    const expectedSig = await hmacSign(`${header}.${payload}`, secret)
    if (sig !== expectedSig) return null
    const data = JSON.parse(fromb64url(payload)) as JWTPayload
    if (data.exp < Math.floor(Date.now() / 1000)) return null
    return data
  } catch {
    return null
  }
}

// Hash password SHA-256
export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder()
  const data = encoder.encode(password + APP_CONFIG.salt)
  const hash = await crypto.subtle.digest('SHA-256', data)
  return b64url(String.fromCharCode(...new Uint8Array(hash)))
}

// Extraire le token de l'en-tête Authorization
export function extractToken(authHeader: string | undefined): string | null {
  if (!authHeader?.startsWith('Bearer ')) return null
  return authHeader.substring(7)
}
