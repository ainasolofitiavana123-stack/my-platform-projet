// ============================================
// MIDDLEWARE - Auth middleware (stateless JWT)
// ============================================

import { Context, Next } from 'hono'
import { verifyJWT, extractToken } from './jwt'
import type { AppBindings } from '../types'

// Middleware: utilisateur authentifié requis
export async function requireAuth(c: Context<{ Bindings: AppBindings }>, next: Next) {
  const token = extractToken(c.req.header('Authorization'))
  if (!token) {
    return c.json({ error: 'Authentification requise', code: 'UNAUTHENTICATED' }, 401)
  }
  const payload = await verifyJWT(token)
  if (!payload) {
    return c.json({ error: 'Token invalide ou expiré', code: 'INVALID_TOKEN' }, 401)
  }
  c.set('jwtPayload', payload)
  return next()
}

// Middleware: rôle admin requis
export async function requireAdmin(c: Context<{ Bindings: AppBindings }>, next: Next) {
  const token = extractToken(c.req.header('Authorization'))
  if (!token) {
    return c.json({ error: 'Authentification requise', code: 'UNAUTHENTICATED' }, 401)
  }
  const payload = await verifyJWT(token)
  if (!payload) {
    return c.json({ error: 'Token invalide ou expiré', code: 'INVALID_TOKEN' }, 401)
  }
  if (payload.role !== 'admin' && payload.role !== 'teacher') {
    return c.json({ error: 'Accès refusé - Droits administrateur requis', code: 'FORBIDDEN' }, 403)
  }
  c.set('jwtPayload', payload)
  return next()
}

// Middleware: abonnement premium requis
export async function requireSubscription(c: Context<{ Bindings: AppBindings }>, next: Next) {
  const token = extractToken(c.req.header('Authorization'))
  if (!token) {
    return c.json({ error: 'Authentification requise', code: 'UNAUTHENTICATED' }, 401)
  }
  const payload = await verifyJWT(token)
  if (!payload) {
    return c.json({ error: 'Token invalide ou expiré', code: 'INVALID_TOKEN' }, 401)
  }
  // Vérifier abonnement actif en DB
  const sub = await c.env.DB.prepare(`
    SELECT id FROM subscriptions 
    WHERE user_id = ? AND plan_id > 1 AND status = 'active' AND end_date > datetime('now')
  `).bind(payload.userId).first()
  
  if (!sub) {
    return c.json({ error: 'Abonnement premium requis', code: 'SUBSCRIPTION_REQUIRED', requires_subscription: true }, 403)
  }
  c.set('jwtPayload', payload)
  return next()
}

// Middleware optionnel: attacher le payload JWT si disponible
export async function optionalAuth(c: Context<{ Bindings: AppBindings }>, next: Next) {
  const token = extractToken(c.req.header('Authorization'))
  if (token) {
    const payload = await verifyJWT(token)
    if (payload) c.set('jwtPayload', payload)
  }
  return next()
}
