// ============================================
// CONTROLLER - AdminController
// ============================================

import { Context } from 'hono'
import { UserModel } from '../models/user.model'
import { AnnouncementModel } from '../models/announcement.model'
import { SubscriptionModel } from '../models/subscription.model'
import type { AppBindings } from '../types'
import type { JWTPayload } from '../middleware/jwt'

export class AdminController {
  static async getStats(c: Context<{ Bindings: AppBindings }>) {
    const subModel = new SubscriptionModel(c.env.DB)

    const [students, lessons, quizAttempts, payments] = await Promise.all([
      c.env.DB.prepare('SELECT COUNT(*) as count FROM users WHERE role = "student"').first() as any,
      c.env.DB.prepare('SELECT COUNT(*) as count FROM lessons').first() as any,
      c.env.DB.prepare('SELECT COUNT(*) as count FROM quiz_attempts').first() as any,
      c.env.DB.prepare('SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE status = "completed" AND currency = "MGA"').first() as any,
    ])

    const activeSubscriptions = await subModel.getActiveCount()

    const recentUsers = await c.env.DB.prepare(
      'SELECT id, email, full_name, class_level, role, created_at FROM users ORDER BY created_at DESC LIMIT 10'
    ).all()

    const recentPayments = await c.env.DB.prepare(`
      SELECT p.*, u.full_name, u.email FROM payments p
      JOIN users u ON p.user_id = u.id
      ORDER BY p.created_at DESC LIMIT 10
    `).all()

    return c.json({
      stats: {
        total_students: (students as any)?.count || 0,
        active_subscriptions: activeSubscriptions,
        total_lessons: (lessons as any)?.count || 0,
        total_quiz_attempts: (quizAttempts as any)?.count || 0,
        total_revenue_mga: (payments as any)?.total || 0
      },
      recent_users: recentUsers.results,
      recent_payments: recentPayments.results
    })
  }

  static async getUsers(c: Context<{ Bindings: AppBindings }>) {
    const page = parseInt(c.req.query('page') || '1')
    const userModel = new UserModel(c.env.DB)
    const { users, total } = await userModel.getAll(page)
    return c.json({ users, total, page, limit: 20 })
  }

  static async getAnnouncements(c: Context<{ Bindings: AppBindings }>) {
    const model = new AnnouncementModel(c.env.DB)
    const announcements = await model.getAll()
    return c.json({ announcements })
  }

  static async createAnnouncement(c: Context<{ Bindings: AppBindings }>) {
    const jwtPayload = c.get('jwtPayload') as JWTPayload
    const model = new AnnouncementModel(c.env.DB)
    const { title, content, target_audience, is_pinned } = await c.req.json()

    if (!title || !content) return c.json({ error: 'Titre et contenu requis' }, 400)

    const id = await model.create({
      title, content, authorId: jwtPayload.userId,
      targetAudience: target_audience, isPinned: is_pinned
    })
    return c.json({ id, message: 'Annonce publiée avec succès' }, 201)
  }

  static async deleteAnnouncement(c: Context<{ Bindings: AppBindings }>) {
    const id = parseInt(c.req.param('id'))
    const model = new AnnouncementModel(c.env.DB)
    await model.delete(id)
    return c.json({ message: 'Annonce supprimée' })
  }

  static async updateUserRole(c: Context<{ Bindings: AppBindings }>) {
    const id = parseInt(c.req.param('id'))
    const { role } = await c.req.json()
    if (!['student', 'teacher', 'admin'].includes(role)) {
      return c.json({ error: 'Rôle invalide' }, 400)
    }
    await c.env.DB.prepare('UPDATE users SET role = ? WHERE id = ?').bind(role, id).run()
    return c.json({ message: 'Rôle mis à jour' })
  }

  // Accorder un abonnement gratuit à un utilisateur
  static async grantSubscription(c: Context<{ Bindings: AppBindings }>) {
    const { user_id, plan_id, days } = await c.req.json()
    const subModel = new SubscriptionModel(c.env.DB)
    const endDate = new Date()
    endDate.setDate(endDate.getDate() + (days || 30))

    await c.env.DB.prepare(`
      INSERT INTO subscriptions (user_id, plan_id, end_date, status, payment_method)
      VALUES (?, ?, ?, 'active', 'admin_grant')
    `).bind(user_id, plan_id || 2, endDate.toISOString()).run()

    return c.json({ message: 'Abonnement accordé', end_date: endDate.toISOString() })
  }
}
