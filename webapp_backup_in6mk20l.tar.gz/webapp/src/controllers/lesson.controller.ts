// ============================================
// CONTROLLER - LessonController
// Accès libre : tout le contenu est accessible sans connexion
// ============================================

import { Context } from 'hono'
import { LessonModel } from '../models/lesson.model'
import { NotificationModel } from '../models/notification.model'
import type { AppBindings } from '../types'
import type { JWTPayload } from '../middleware/jwt'

export class LessonController {
  static async getById(c: Context<{ Bindings: AppBindings }>) {
    const id = parseInt(c.req.param('id'))
    const lessonModel = new LessonModel(c.env.DB)

    const lesson = await lessonModel.findById(id)
    if (!lesson) return c.json({ error: 'Leçon non trouvée' }, 404)

    // ✅ Accès libre : plus de vérification d'abonnement
    // Incrémenter les vues
    await lessonModel.incrementViewCount(id)

    // Progression de l'utilisateur (si connecté)
    const jwtPayload = c.get('jwtPayload') as JWTPayload | undefined
    let progress = null
    if (jwtPayload) {
      progress = await lessonModel.getProgress(jwtPayload.userId, id)
    }

    // Leçons voisines
    const siblings = await lessonModel.getSiblings(lesson.chapter_id)
    const currentIndex = siblings.findIndex(l => l.id === id)
    const prevLesson = currentIndex > 0 ? siblings[currentIndex - 1] : null
    const nextLesson = currentIndex < siblings.length - 1 ? siblings[currentIndex + 1] : null

    return c.json({ lesson, progress, prevLesson, nextLesson })
  }

  static async markComplete(c: Context<{ Bindings: AppBindings }>) {
    const id = parseInt(c.req.param('id'))
    const jwtPayload = c.get('jwtPayload') as JWTPayload | undefined
    const lessonModel = new LessonModel(c.env.DB)
    const notifModel = new NotificationModel(c.env.DB)

    // Si non connecté, on ignore silencieusement
    if (!jwtPayload) {
      return c.json({ message: 'Leçon vue (non sauvegardée - connectez-vous pour suivre votre progression)' })
    }

    await lessonModel.markComplete(jwtPayload.userId, id)

    const count = await c.env.DB.prepare(
      'SELECT COUNT(*) as count FROM lesson_progress WHERE user_id = ? AND is_completed = 1'
    ).bind(jwtPayload.userId).first() as any

    if (count?.count % 5 === 0) {
      await notifModel.create(jwtPayload.userId, `🎉 ${count.count} leçons complétées!`,
        'Félicitations pour votre progression!', 'success')
    }

    return c.json({ message: 'Leçon complétée!', total_completed: count?.count || 1 })
  }
}
