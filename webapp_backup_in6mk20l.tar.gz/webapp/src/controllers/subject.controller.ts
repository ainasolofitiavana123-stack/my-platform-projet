// ============================================
// CONTROLLER - SubjectController
// Accès libre : tout le contenu est public
// ============================================

import { Context } from 'hono'
import { SubjectModel } from '../models/subject.model'
import type { AppBindings } from '../types'

export class SubjectController {
  static async getAll(c: Context<{ Bindings: AppBindings }>) {
    const classLevel = c.req.query('class_level') || 'terminale_a1'
    const model = new SubjectModel(c.env.DB)
    const subjects = await model.findAll(classLevel)
    return c.json({ subjects })
  }

  static async getById(c: Context<{ Bindings: AppBindings }>) {
    const id = parseInt(c.req.param('id'))
    const model = new SubjectModel(c.env.DB)

    const subject = await model.findById(id)
    if (!subject) return c.json({ error: 'Matière non trouvée' }, 404)

    const chapters = await model.getChapters(id)

    const quizzes = await c.env.DB.prepare(`
      SELECT id, title, description, duration_minutes, passing_score, is_free, difficulty,
        (SELECT COUNT(*) FROM questions q WHERE q.quiz_id = quizzes.id) as question_count
      FROM quizzes WHERE subject_id = ? AND is_published = 1 ORDER BY id ASC
    `).bind(id).all()

    return c.json({ subject, chapters, quizzes: quizzes.results })
  }

  static async getChapterLessons(c: Context<{ Bindings: AppBindings }>) {
    const { id, chapterId } = c.req.param()
    const model = new SubjectModel(c.env.DB)

    // ✅ Accès libre : toutes les leçons visibles sans abonnement
    const lessons = await model.getLessons(parseInt(chapterId), true)
    return c.json({ lessons, is_subscribed: true })
  }
}
