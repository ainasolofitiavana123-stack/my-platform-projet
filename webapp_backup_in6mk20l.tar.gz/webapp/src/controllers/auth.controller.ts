// ============================================
// CONTROLLER - AuthController
// ============================================

import { Context } from 'hono'
import { UserModel } from '../models/user.model'
import { SubscriptionModel } from '../models/subscription.model'
import { NotificationModel } from '../models/notification.model'
import { generateJWT, verifyJWT, extractToken } from '../middleware/jwt'
import type { AppBindings } from '../types'

export class AuthController {
  static async register(c: Context<{ Bindings: AppBindings }>) {
    try {
      const { email, password, full_name, class_level } = await c.req.json()

      // Validation
      if (!email || !password || !full_name) {
        return c.json({ error: 'Tous les champs sont requis' }, 400)
      }
      if (password.length < 6) {
        return c.json({ error: 'Le mot de passe doit contenir au moins 6 caractères' }, 400)
      }
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!emailRegex.test(email)) {
        return c.json({ error: 'Format d\'email invalide' }, 400)
      }

      const userModel = new UserModel(c.env.DB)
      const subModel = new SubscriptionModel(c.env.DB)
      const notifModel = new NotificationModel(c.env.DB)

      // Vérifier email existant
      const existing = await userModel.findByEmail(email)
      if (existing) {
        return c.json({ error: 'Cet email est déjà utilisé' }, 409)
      }

      // Créer l'utilisateur
      const userId = await userModel.create({ email, password, full_name, class_level })

      // Créer abonnement gratuit
      await subModel.createFreeSubscription(userId)

      // Notification de bienvenue
      await notifModel.create(userId, 'Bienvenue sur Terminale Madagascar! 🎉',
        'Votre compte a été créé. Commencez à explorer nos cours!')

      // Récupérer l'utilisateur créé
      const user = await userModel.findById(userId)

      // Générer JWT stateless (sans session DB)
      const token = await generateJWT({
        userId: userId,
        email: user!.email,
        role: user!.role,
        class_level: user!.class_level
      })

      return c.json({ token, user: { id: userId, email, full_name, role: 'student', class_level } }, 201)
    } catch (err: any) {
      return c.json({ error: err.message || 'Erreur lors de l\'inscription' }, 500)
    }
  }

  static async login(c: Context<{ Bindings: AppBindings }>) {
    try {
      const { email, password } = await c.req.json()

      if (!email || !password) {
        return c.json({ error: 'Email et mot de passe requis' }, 400)
      }

      const userModel = new UserModel(c.env.DB)
      const subModel = new SubscriptionModel(c.env.DB)

      const user = await userModel.findByEmail(email)
      if (!user) {
        return c.json({ error: 'Email ou mot de passe incorrect' }, 401)
      }

      const isValid = await userModel.verifyPassword(user, password)
      if (!isValid) {
        return c.json({ error: 'Email ou mot de passe incorrect' }, 401)
      }

      // Générer JWT stateless (SANS session en base de données)
      const token = await generateJWT({
        userId: user.id,
        email: user.email,
        role: user.role,
        class_level: user.class_level
      })

      // Récupérer l'abonnement actif
      const subscription = await subModel.getActiveSubscription(user.id)

      return c.json({
        token,
        user: {
          id: user.id,
          email: user.email,
          full_name: user.full_name,
          role: user.role,
          class_level: user.class_level,
          avatar: user.avatar
        },
        subscription: subscription ? {
          plan_id: (subscription as any).plan_id,
          plan_name: (subscription as any).plan_name,
          end_date: subscription.end_date,
          status: subscription.status
        } : null
      })
    } catch (err: any) {
      return c.json({ error: err.message || 'Erreur de connexion' }, 500)
    }
  }

  // Logout - stateless JWT: juste confirmer (le client supprime le token)
  static async logout(c: Context<{ Bindings: AppBindings }>) {
    // Avec JWT stateless, pas besoin de supprimer en DB
    // Le client doit supprimer le token localement
    return c.json({ message: 'Déconnecté avec succès. Supprimez votre token local.' })
  }

  static async me(c: Context<{ Bindings: AppBindings }>) {
    try {
      const token = extractToken(c.req.header('Authorization'))
      if (!token) return c.json({ error: 'Non authentifié' }, 401)

      const payload = await verifyJWT(token)
      if (!payload) return c.json({ error: 'Token invalide ou expiré' }, 401)

      const userModel = new UserModel(c.env.DB)
      const subModel = new SubscriptionModel(c.env.DB)
      const notifModel = new NotificationModel(c.env.DB)

      const user = await userModel.findById(payload.userId)
      if (!user) return c.json({ error: 'Utilisateur introuvable' }, 404)

      const subscription = await subModel.getActiveSubscription(payload.userId)
      const unreadCount = await notifModel.getUnreadCount(payload.userId)

      return c.json({
        user,
        subscription: subscription ? {
          plan_id: (subscription as any).plan_id,
          plan_name: (subscription as any).plan_name,
          end_date: subscription.end_date,
          features: (subscription as any).features,
          price_ariary: (subscription as any).price_ariary,
          price_dollar: (subscription as any).price_dollar
        } : null,
        unread_notifications: unreadCount
      })
    } catch (err: any) {
      return c.json({ error: err.message || 'Erreur' }, 500)
    }
  }

  // Refresh token - émettre un nouveau JWT
  static async refreshToken(c: Context<{ Bindings: AppBindings }>) {
    const token = extractToken(c.req.header('Authorization'))
    if (!token) return c.json({ error: 'Token requis' }, 401)

    const payload = await verifyJWT(token)
    if (!payload) return c.json({ error: 'Token invalide' }, 401)

    // Vérifier que l'utilisateur existe encore
    const userModel = new UserModel(c.env.DB)
    const user = await userModel.findById(payload.userId)
    if (!user || !user.is_active) return c.json({ error: 'Utilisateur inactif' }, 401)

    const newToken = await generateJWT({
      userId: user.id,
      email: user.email,
      role: user.role,
      class_level: user.class_level
    })

    return c.json({ token: newToken })
  }

  // Mise à jour du profil utilisateur
  static async updateProfile(c: Context<{ Bindings: AppBindings }>) {
    try {
      const token = extractToken(c.req.header('Authorization'))
      if (!token) return c.json({ error: 'Non authentifié' }, 401)

      const payload = await verifyJWT(token)
      if (!payload) return c.json({ error: 'Token invalide ou expiré' }, 401)

      const { full_name, class_level, avatar } = await c.req.json()

      if (!full_name || full_name.trim().length < 2) {
        return c.json({ error: 'Le nom doit contenir au moins 2 caractères' }, 400)
      }

      const userModel = new UserModel(c.env.DB)
      await userModel.updateProfile(payload.userId, { full_name: full_name.trim(), class_level, avatar })

      const updatedUser = await userModel.findById(payload.userId)

      // Générer un nouveau JWT avec les infos mises à jour
      const newToken = await generateJWT({
        userId: updatedUser!.id,
        email: updatedUser!.email,
        role: updatedUser!.role,
        class_level: updatedUser!.class_level
      })

      return c.json({
        message: 'Profil mis à jour avec succès',
        user: {
          id: updatedUser!.id,
          email: updatedUser!.email,
          full_name: updatedUser!.full_name,
          role: updatedUser!.role,
          class_level: updatedUser!.class_level,
          avatar: updatedUser!.avatar
        },
        token: newToken
      })
    } catch (err: any) {
      return c.json({ error: err.message || 'Erreur lors de la mise à jour' }, 500)
    }
  }

  // Changement de mot de passe
  static async changePassword(c: Context<{ Bindings: AppBindings }>) {
    try {
      const token = extractToken(c.req.header('Authorization'))
      if (!token) return c.json({ error: 'Non authentifié' }, 401)

      const payload = await verifyJWT(token)
      if (!payload) return c.json({ error: 'Token invalide ou expiré' }, 401)

      const { current_password, new_password } = await c.req.json()

      if (!current_password || !new_password) {
        return c.json({ error: 'Mot de passe actuel et nouveau mot de passe requis' }, 400)
      }
      if (new_password.length < 6) {
        return c.json({ error: 'Le nouveau mot de passe doit contenir au moins 6 caractères' }, 400)
      }

      const userModel = new UserModel(c.env.DB)
      const user = await userModel.findByEmail(payload.email)
      if (!user) return c.json({ error: 'Utilisateur introuvable' }, 404)

      // Vérifier le mot de passe actuel
      const isValid = await userModel.verifyPassword(user, current_password)
      if (!isValid) {
        return c.json({ error: 'Mot de passe actuel incorrect' }, 400)
      }

      // Mettre à jour le mot de passe
      const { hashPassword } = await import('../middleware/jwt')
      const hashedPassword = await hashPassword(new_password)
      await c.env.DB.prepare(
        'UPDATE users SET password_hash = ? WHERE id = ?'
      ).bind(hashedPassword, payload.userId).run()

      return c.json({ message: 'Mot de passe mis à jour avec succès' })
    } catch (err: any) {
      return c.json({ error: err.message || 'Erreur lors du changement de mot de passe' }, 500)
    }
  }
}
