// ============================================
// CONTROLLER - QuizController
// Accès libre : quiz accessibles sans connexion ni abonnement
// ============================================

import { Context } from 'hono'
import { QuizModel } from '../models/quiz.model'
import { NotificationModel } from '../models/notification.model'
import type { AppBindings } from '../types'
import type { JWTPayload } from '../middleware/jwt'

export class QuizController {
  static async getAll(c: Context<{ Bindings: AppBindings }>) {
    const model = new QuizModel(c.env.DB)
    const quizzes = await model.findAll({
      subjectId: c.req.query('subject_id'),
      difficulty: c.req.query('difficulty')
    })
    return c.json({ quizzes })
  }

  static async getById(c: Context<{ Bindings: AppBindings }>) {
    const id = parseInt(c.req.param('id'))
    const model = new QuizModel(c.env.DB)

    const quiz = await model.findById(id)
    if (!quiz) return c.json({ error: 'Quiz non trouvé' }, 404)

    // ✅ Accès libre : plus de vérification d'abonnement
    const jwtPayload = c.get('jwtPayload') as JWTPayload | undefined
    let attemptCount = 0

    if (jwtPayload) {
      attemptCount = await model.getAttemptCount(jwtPayload.userId, id)
    }

    // Questions SANS réponses pour l'étudiant
    const questions = await model.getQuestionsForStudent(id)

    return c.json({
      quiz,
      questions,
      attempt_count: attemptCount,
      can_attempt: true   // toujours autorisé
    })
  }

  static async submit(c: Context<{ Bindings: AppBindings }>) {
    const id = parseInt(c.req.param('id'))
    const jwtPayload = c.get('jwtPayload') as JWTPayload | undefined
    const model = new QuizModel(c.env.DB)
    const notifModel = new NotificationModel(c.env.DB)

    const quiz = await model.findById(id)
    if (!quiz) return c.json({ error: 'Quiz non trouvé' }, 404)

    const { answers, time_taken } = await c.req.json()

    // Récupérer toutes les questions AVEC les réponses (côté serveur uniquement)
    const questions = await model.getQuestionsWithAnswers(id)

    let score = 0
    let totalPoints = 0
    const results: any[] = []

    for (const q of questions) {
      totalPoints += q.points
      const userAnswer = answers[q.id]
      const isCorrect = userAnswer === q.correct_answer
      if (isCorrect) score += q.points

      results.push({
        question_id: q.id,
        question_text: q.question_text,
        user_answer: userAnswer,
        correct_answer: q.correct_answer,
        is_correct: isCorrect,
        explanation: q.explanation,
        points: q.points
      })
    }

    const percentage = totalPoints > 0 ? Math.round((score / totalPoints) * 100) : 0
    const passed = percentage >= quiz.passing_score

    // ✅ Sauvegarder seulement si connecté
    let attemptNumber = 1
    if (jwtPayload) {
      const attemptCount = await model.getAttemptCount(jwtPayload.userId, id)
      attemptNumber = attemptCount + 1

      await model.saveAttempt({
        userId: jwtPayload.userId, quizId: id, score, totalPoints,
        answers, timeTaken: time_taken || 0, passed, attemptNumber
      })

      // Notification
      const msg = passed
        ? `Félicitations! Quiz "${quiz.title}" réussi avec ${percentage}%! 🎉`
        : `Quiz "${quiz.title}" terminé. Score: ${percentage}%. Continuez vos efforts! 💪`
      await notifModel.create(jwtPayload.userId, passed ? 'Quiz réussi! 🎉' : 'Quiz terminé', msg,
        passed ? 'success' : 'info')
    }

    return c.json({ score, total_points: totalPoints, percentage, passed, results, attempt_number: attemptNumber })
  }

  static async getHistory(c: Context<{ Bindings: AppBindings }>) {
    const id = parseInt(c.req.param('id'))
    const jwtPayload = c.get('jwtPayload') as JWTPayload | undefined
    if (!jwtPayload) return c.json({ attempts: [] })
    const model = new QuizModel(c.env.DB)
    const attempts = await model.getAttemptHistory(jwtPayload.userId, id)
    return c.json({ attempts })
  }
}
