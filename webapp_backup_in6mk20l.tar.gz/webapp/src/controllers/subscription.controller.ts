// ============================================
// CONTROLLER - SubscriptionController
// ============================================

import { Context } from 'hono'
import { SubscriptionModel } from '../models/subscription.model'
import { NotificationModel } from '../models/notification.model'
import { verifyJWT, extractToken } from '../middleware/jwt'
import type { AppBindings } from '../types'
import type { JWTPayload } from '../middleware/jwt'

export class SubscriptionController {
  static async getPlans(c: Context<{ Bindings: AppBindings }>) {
    const model = new SubscriptionModel(c.env.DB)
    const plans = await model.getAllPlans()
    return c.json({ plans })
  }

  static async mySubscriptions(c: Context<{ Bindings: AppBindings }>) {
    const jwtPayload = c.get('jwtPayload') as JWTPayload
    const model = new SubscriptionModel(c.env.DB)
    const subscriptions = await model.getUserSubscriptions(jwtPayload.userId)
    return c.json({ subscriptions })
  }

  static async subscribe(c: Context<{ Bindings: AppBindings }>) {
    const jwtPayload = c.get('jwtPayload') as JWTPayload
    const model = new SubscriptionModel(c.env.DB)
    const notifModel = new NotificationModel(c.env.DB)

    const { plan_id, payment_method, payment_reference, currency } = await c.req.json()

    const plan = await model.getPlanById(plan_id)
    if (!plan) return c.json({ error: 'Plan non trouvé' }, 404)

    const amount = currency === 'USD' ? Math.round(plan.price_dollar * 100) : plan.price_ariary

    const { subscriptionId, endDate } = await model.createPaidSubscription({
      userId: jwtPayload.userId,
      planId: plan_id,
      durationDays: plan.duration_days,
      paymentMethod: payment_method || 'manual',
      paymentReference: payment_reference || `TXN-${Date.now()}`,
      amount,
      currency: currency || 'MGA'
    })

    // Notification
    await notifModel.create(jwtPayload.userId, 'Abonnement activé! 🎉',
      `Votre abonnement "${plan.name}" est actif jusqu'au ${endDate.toLocaleDateString('fr-FR')}`, 'success')

    return c.json({
      message: 'Abonnement activé avec succès!',
      subscription_id: subscriptionId,
      end_date: endDate.toISOString(),
      plan: plan.name
    }, 201)
  }

  static async checkAccess(c: Context<{ Bindings: AppBindings }>) {
    const token = extractToken(c.req.header('Authorization'))
    if (!token) return c.json({ has_access: false })

    const payload = await verifyJWT(token)
    if (!payload) return c.json({ has_access: false })

    const model = new SubscriptionModel(c.env.DB)
    const sub = await model.getActiveSubscription(payload.userId)
    const hasPremium = !!sub && (sub as any).plan_id > 1

    return c.json({
      has_access: hasPremium,
      plan: (sub as any)?.plan_name || 'Gratuit',
      end_date: sub?.end_date || null
    })
  }
}
