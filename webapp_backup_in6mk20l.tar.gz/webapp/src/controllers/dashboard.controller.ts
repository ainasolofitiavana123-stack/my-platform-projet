// ============================================
// CONTROLLER - DashboardController
// ============================================

import { Context } from 'hono'
import { SubscriptionModel } from '../models/subscription.model'
import { NotificationModel } from '../models/notification.model'
import { AnnouncementModel } from '../models/announcement.model'
import type { AppBindings } from '../types'
import type { JWTPayload } from '../middleware/jwt'

export class DashboardController {
  static async getDashboard(c: Context<{ Bindings: AppBindings }>) {
    const jwtPayload = c.get('jwtPayload') as JWTPayload
    const userId = jwtPayload.userId

    const subModel = new SubscriptionModel(c.env.DB)
    const notifModel = new NotificationModel(c.env.DB)
    const annModel = new AnnouncementModel(c.env.DB)

    // Stats parallèles
    const [completedLessons, quizStats, passedQuizzes, subscription] = await Promise.all([
      c.env.DB.prepare('SELECT COUNT(*) as count FROM lesson_progress WHERE user_id = ? AND is_completed = 1').bind(userId).first() as any,
      c.env.DB.prepare('SELECT COUNT(*) as count, AVG(score * 100.0 / NULLIF(total_points, 0)) as avg_score FROM quiz_attempts WHERE user_id = ?').bind(userId).first() as any,
      c.env.DB.prepare('SELECT COUNT(*) as count FROM quiz_attempts WHERE user_id = ? AND passed = 1').bind(userId).first() as any,
      subModel.getActiveSubscription(userId)
    ])

    // Activité récente
    const [recentLessons, recentQuizzes, notifications, announcements] = await Promise.all([
      c.env.DB.prepare(`
        SELECT lp.*, l.title as lesson_title, s.name as subject_name, s.color, s.icon
        FROM lesson_progress lp
        JOIN lessons l ON lp.lesson_id = l.id
        JOIN chapters ch ON l.chapter_id = ch.id
        JOIN subjects s ON ch.subject_id = s.id
        WHERE lp.user_id = ? ORDER BY lp.created_at DESC LIMIT 5
      `).bind(userId).all(),
      c.env.DB.prepare(`
        SELECT qa.*, qz.title as quiz_title, s.name as subject_name, s.color
        FROM quiz_attempts qa
        JOIN quizzes qz ON qa.quiz_id = qz.id
        JOIN subjects s ON qz.subject_id = s.id
        WHERE qa.user_id = ? ORDER BY qa.completed_at DESC LIMIT 5
      `).bind(userId).all(),
      notifModel.getForUser(userId, 10),
      annModel.getPublic(5)
    ])

    // Progression par matière
    const subjectProgress = await c.env.DB.prepare(`
      SELECT s.id, s.name, s.icon, s.color,
        COUNT(DISTINCT l.id) as total_lessons,
        COUNT(DISTINCT CASE WHEN lp.is_completed = 1 THEN l.id END) as completed_lessons
      FROM subjects s
      JOIN chapters ch ON ch.subject_id = s.id
      JOIN lessons l ON l.chapter_id = ch.id
      LEFT JOIN lesson_progress lp ON lp.lesson_id = l.id AND lp.user_id = ?
      WHERE s.is_active = 1
      GROUP BY s.id HAVING total_lessons > 0
      ORDER BY s.order_index ASC LIMIT 6
    `).bind(userId).all()

    return c.json({
      stats: {
        completed_lessons: (completedLessons as any)?.count || 0,
        quiz_attempts: (quizStats as any)?.count || 0,
        avg_quiz_score: Math.round((quizStats as any)?.avg_score || 0),
        passed_quizzes: (passedQuizzes as any)?.count || 0
      },
      subscription: subscription ? {
        plan_name: (subscription as any).plan_name,
        end_date: subscription.end_date,
        status: subscription.status
      } : null,
      recent_lessons: recentLessons.results,
      recent_quizzes: recentQuizzes.results,
      subject_progress: subjectProgress.results,
      notifications,
      announcements
    })
  }

  static async getNotifications(c: Context<{ Bindings: AppBindings }>) {
    const jwtPayload = c.get('jwtPayload') as JWTPayload
    const model = new NotificationModel(c.env.DB)
    const notifications = await model.getForUser(jwtPayload.userId)
    return c.json({ notifications })
  }

  static async markNotificationsRead(c: Context<{ Bindings: AppBindings }>) {
    const jwtPayload = c.get('jwtPayload') as JWTPayload
    const model = new NotificationModel(c.env.DB)
    await model.markAllRead(jwtPayload.userId)
    return c.json({ message: 'Notifications marquées comme lues' })
  }
}
