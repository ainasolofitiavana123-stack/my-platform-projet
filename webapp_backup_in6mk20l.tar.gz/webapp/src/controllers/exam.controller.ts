// ============================================
// CONTROLLER - ExamController
// Accès libre : tous les examens accessibles sans connexion
// ============================================

import { Context } from 'hono'
import { ExamModel } from '../models/exam.model'
import type { AppBindings } from '../types'

export class ExamController {
  static async getAll(c: Context<{ Bindings: AppBindings }>) {
    const model = new ExamModel(c.env.DB)
    const exams = await model.findAll({
      subjectId: c.req.query('subject_id'),
      type: c.req.query('type')
    })
    return c.json({ exams })
  }

  static async getById(c: Context<{ Bindings: AppBindings }>) {
    const id = parseInt(c.req.param('id'))
    const model = new ExamModel(c.env.DB)

    const exam = await model.findById(id)
    if (!exam) return c.json({ error: 'Examen non trouvé' }, 404)

    // ✅ Accès libre : plus de vérification d'abonnement
    return c.json({ exam })
  }
}
