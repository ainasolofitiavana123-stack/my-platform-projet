// ============================================
// VIEW/ROUTER - Routes Leçons
// Accès libre : tout est public, auth optionnelle
// ============================================

import { Hono } from 'hono'
import { LessonController } from '../controllers/lesson.controller'
import { optionalAuth } from '../middleware/auth.middleware'
import type { AppBindings, AppVariables } from '../types'

export const lessonRouter = new Hono<{ Bindings: AppBindings; Variables: AppVariables }>()

// GET /api/lessons/:id (public - auth optionnelle pour la progression)
lessonRouter.get('/:id', optionalAuth, LessonController.getById)

// POST /api/lessons/:id/complete (auth optionnelle - ignoré si non connecté)
lessonRouter.post('/:id/complete', optionalAuth, LessonController.markComplete)
