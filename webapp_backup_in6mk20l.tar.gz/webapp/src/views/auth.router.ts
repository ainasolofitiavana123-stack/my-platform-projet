// ============================================
// VIEW/ROUTER - Routes Auth
// ============================================

import { Hono } from 'hono'
import { AuthController } from '../controllers/auth.controller'
import { requireAuth } from '../middleware/auth.middleware'
import type { AppBindings, AppVariables } from '../types'

export const authRouter = new Hono<{ Bindings: AppBindings; Variables: AppVariables }>()

// POST /api/auth/register
authRouter.post('/register', AuthController.register)

// POST /api/auth/login
authRouter.post('/login', AuthController.login)

// POST /api/auth/logout (stateless - juste confirmation)
authRouter.post('/logout', AuthController.logout)

// GET /api/auth/me (JWT stateless)
authRouter.get('/me', AuthController.me)

// POST /api/auth/refresh
authRouter.post('/refresh', AuthController.refreshToken)

// PUT /api/auth/profile - Mettre à jour le profil
authRouter.put('/profile', AuthController.updateProfile)

// PUT /api/auth/change-password - Changer le mot de passe
authRouter.put('/change-password', AuthController.changePassword)

