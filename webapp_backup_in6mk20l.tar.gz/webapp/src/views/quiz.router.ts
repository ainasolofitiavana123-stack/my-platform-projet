// ============================================
// VIEW/ROUTER - Routes Quiz
// Accès libre : tout est public, auth optionnelle
// ============================================

import { Hono } from 'hono'
import { QuizController } from '../controllers/quiz.controller'
import { optionalAuth } from '../middleware/auth.middleware'
import type { AppBindings, AppVariables } from '../types'

export const quizRouter = new Hono<{ Bindings: AppBindings; Variables: AppVariables }>()

// GET /api/quiz (public)
quizRouter.get('/', QuizController.getAll)

// GET /api/quiz/:id (public - auth optionnelle pour le suivi)
quizRouter.get('/:id', optionalAuth, QuizController.getById)

// POST /api/quiz/:id/submit (public - auth optionnelle pour sauvegarder)
quizRouter.post('/:id/submit', optionalAuth, QuizController.submit)

// GET /api/quiz/:id/history (auth optionnelle)
quizRouter.get('/:id/history', optionalAuth, QuizController.getHistory)
