// ============================================
// VIEW/ROUTER - Routes Sujets
// ============================================

import { Hono } from 'hono'
import { SubjectController } from '../controllers/subject.controller'
import type { AppBindings, AppVariables } from '../types'

export const subjectRouter = new Hono<{ Bindings: AppBindings; Variables: AppVariables }>()

// GET /api/subjects?class_level=terminale_a1
subjectRouter.get('/', SubjectController.getAll)

// GET /api/subjects/:id
subjectRouter.get('/:id', SubjectController.getById)

// GET /api/subjects/:id/chapters/:chapterId/lessons
subjectRouter.get('/:id/chapters/:chapterId/lessons', SubjectController.getChapterLessons)
