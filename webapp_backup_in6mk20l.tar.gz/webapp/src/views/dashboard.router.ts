// ============================================
// VIEW/ROUTER - Routes Dashboard
// ============================================

import { Hono } from 'hono'
import { DashboardController } from '../controllers/dashboard.controller'
import { requireAuth } from '../middleware/auth.middleware'
import type { AppBindings, AppVariables } from '../types'

export const dashboardRouter = new Hono<{ Bindings: AppBindings; Variables: AppVariables }>()

// Toutes les routes dashboard nécessitent l'authentification
dashboardRouter.use('/*', requireAuth)

// GET /api/dashboard
dashboardRouter.get('/', DashboardController.getDashboard)

// GET /api/dashboard/notifications
dashboardRouter.get('/notifications', DashboardController.getNotifications)

// POST /api/dashboard/notifications/read
dashboardRouter.post('/notifications/read', DashboardController.markNotificationsRead)
