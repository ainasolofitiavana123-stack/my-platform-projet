// ============================================
// VIEW/ROUTER - Routes Abonnements
// ============================================

import { Hono } from 'hono'
import { SubscriptionController } from '../controllers/subscription.controller'
import { requireAuth } from '../middleware/auth.middleware'
import type { AppBindings, AppVariables } from '../types'

export const subscriptionRouter = new Hono<{ Bindings: AppBindings; Variables: AppVariables }>()

// GET /api/subscriptions/plans (public)
subscriptionRouter.get('/plans', SubscriptionController.getPlans)

// GET /api/subscriptions/check-access (public - vérifie le token si présent)
subscriptionRouter.get('/check-access', SubscriptionController.checkAccess)

// GET /api/subscriptions/my (auth requise)
subscriptionRouter.get('/my', requireAuth, SubscriptionController.mySubscriptions)

// POST /api/subscriptions/subscribe (auth requise)
subscriptionRouter.post('/subscribe', requireAuth, SubscriptionController.subscribe)
