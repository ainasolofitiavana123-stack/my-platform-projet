// ============================================
// VIEW/ROUTER - Routes Admin
// ============================================

import { Hono } from 'hono'
import { AdminController } from '../controllers/admin.controller'
import { requireAdmin } from '../middleware/auth.middleware'
import type { AppBindings, AppVariables } from '../types'

export const adminRouter = new Hono<{ Bindings: AppBindings; Variables: AppVariables }>()

// Toutes les routes admin nécessitent le rôle admin/teacher
adminRouter.use('/*', requireAdmin)

// GET /api/admin/stats
adminRouter.get('/stats', AdminController.getStats)

// GET /api/admin/users
adminRouter.get('/users', AdminController.getUsers)

// GET /api/admin/announcements
adminRouter.get('/announcements', AdminController.getAnnouncements)

// POST /api/admin/announcements
adminRouter.post('/announcements', AdminController.createAnnouncement)

// DELETE /api/admin/announcements/:id
adminRouter.delete('/announcements/:id', AdminController.deleteAnnouncement)

// PATCH /api/admin/users/:id/role
adminRouter.patch('/users/:id/role', AdminController.updateUserRole)

// POST /api/admin/grant-subscription
adminRouter.post('/grant-subscription', AdminController.grantSubscription)
