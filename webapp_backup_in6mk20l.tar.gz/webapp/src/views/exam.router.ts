// ============================================
// VIEW/ROUTER - Routes Examens
// ============================================

import { Hono } from 'hono'
import { ExamController } from '../controllers/exam.controller'
import { optionalAuth } from '../middleware/auth.middleware'
import type { AppBindings, AppVariables } from '../types'

export const examRouter = new Hono<{ Bindings: AppBindings; Variables: AppVariables }>()

// GET /api/exams (public)
examRouter.get('/', ExamController.getAll)

// GET /api/exams/:id (auth optionnelle)
examRouter.get('/:id', optionalAuth, ExamController.getById)
