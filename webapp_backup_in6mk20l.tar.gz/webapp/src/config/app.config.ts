// ============================================
// CONFIG - Configuration centrale de l'application
// ============================================

export const APP_CONFIG = {
  name: 'Terminale Madagascar',
  description: 'Plateforme de cours en ligne pour Terminale A1 & A2',
  version: '2.0.0',
  admin_email: 'ainasolofitiavana123@gmail.com',
  admin_password: 'Admin@2024!', // mot de passe par défaut - à changer
  jwt_secret: 'terminale-mg-jwt-secret-2024',
  jwt_expires_in: 30 * 24 * 60 * 60 * 1000, // 30 jours en ms
  salt: 'terminale-mg-salt-v2',
}

export const SUBSCRIPTION_PLANS = {
  FREE: 1,
  MONTHLY: 2,
  QUARTERLY: 3,
  ANNUAL: 4,
}

export const USER_ROLES = {
  STUDENT: 'student',
  TEACHER: 'teacher',
  ADMIN: 'admin',
}

export const CLASS_LEVELS = {
  A1: 'terminale_a1',
  A2: 'terminale_a2',
}
