// ============================================
// APP - Point d'entrée principal (Architecture MVC)
// ============================================
// Structure:
//   Models    → src/models/          (accès aux données)
//   Views     → src/views/           (routers/endpoints)
//   Controllers → src/controllers/  (logique métier)
//   Middleware  → src/middleware/    (JWT stateless, auth)
//   Config      → src/config/       (configuration)
// ============================================

import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'
import type { AppBindings, AppVariables } from './types'
import { APP_CONFIG } from './config/app.config'
import { UserModel } from './models/user.model'

// ---- Views (Routers) ----
import { authRouter }         from './views/auth.router'
import { subjectRouter }      from './views/subject.router'
import { lessonRouter }       from './views/lesson.router'
import { quizRouter }         from './views/quiz.router'
import { subscriptionRouter } from './views/subscription.router'
import { examRouter }         from './views/exam.router'
import { dashboardRouter }    from './views/dashboard.router'
import { adminRouter }        from './views/admin.router'

const app = new Hono<{ Bindings: AppBindings; Variables: AppVariables }>()

// ---- Middleware global ----
app.use('/api/*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
  exposeHeaders: ['Authorization'],
}))

// ---- Static files ----
app.use('/static/*', serveStatic({ root: './public' }))

// ---- Initialisation au premier appel ----
app.use('/api/*', async (c, next) => {
  // Créer le compte admin si inexistant (idempotent)
  try {
    const userModel = new UserModel(c.env.DB)
    await userModel.ensureAdminExists()
  } catch {}
  return next()
})

// ---- API Routes (MVC Views) ----
app.route('/api/auth',          authRouter)
app.route('/api/subjects',      subjectRouter)
app.route('/api/lessons',       lessonRouter)
app.route('/api/quiz',          quizRouter)
app.route('/api/subscriptions', subscriptionRouter)
app.route('/api/exams',         examRouter)
app.route('/api/dashboard',     dashboardRouter)
app.route('/api/admin',         adminRouter)

// ---- Routes publiques ----
app.get('/api/health', (c) => c.json({
  status: 'ok',
  app: APP_CONFIG.name,
  version: APP_CONFIG.version,
  architecture: 'MVC',
  timestamp: new Date().toISOString()
}))

// Route publique: annonces
app.get('/api/public/announcements', async (c) => {
  const result = await c.env.DB.prepare(`
    SELECT a.*, u.full_name as author_name FROM announcements a
    JOIN users u ON a.author_id = u.id
    WHERE a.is_published = 1
    ORDER BY a.is_pinned DESC, a.created_at DESC LIMIT 5
  `).all()
  return c.json({ announcements: result.results })
})

// ---- SPA fallback (servir l'app frontend pour toutes les autres routes) ----
app.get('*', (c) => c.html(buildHTML()))

function buildHTML(): string {
  return `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Terminale Madagascar - Plateforme de Cours en Ligne</title>
  <meta name="description" content="Plateforme de cours en ligne pour Terminale A1 et A2 - Madagascar.">
  <meta name="theme-color" content="#4F46E5">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="/static/styles.css">
</head>
<body class="bg-gray-50 min-h-screen">
  <div id="app">
    <div id="loading-screen" class="fixed inset-0 bg-indigo-900 flex items-center justify-center z-50">
      <div class="text-center text-white px-4">
        <div class="text-6xl mb-4">📚</div>
        <h1 class="text-3xl font-bold mb-2">Terminale Madagascar</h1>
        <p class="text-indigo-200 mb-2">Plateforme de cours en ligne</p>
        <p class="text-indigo-300 text-sm mb-6">Terminale A1 &amp; A2</p>
        <div class="flex justify-center">
          <div class="animate-spin rounded-full h-10 w-10 border-t-4 border-white border-opacity-75"></div>
        </div>
      </div>
    </div>
  </div>
  <script src="/static/app.js"></script>
</body>
</html>`
}

export default app
