// ============================================
// TYPES - Types centraux de l'application
// ============================================

import type { JWTPayload } from './middleware/jwt'

export type AppBindings = {
  DB: D1Database
}

export type AppVariables = {
  jwtPayload?: JWTPayload
}

// ---- Models Types ----
export interface User {
  id: number
  email: string
  password_hash: string
  full_name: string
  role: 'student' | 'teacher' | 'admin'
  class_level: string
  avatar?: string
  is_active: number
  created_at: string
  updated_at?: string
}

export interface Subject {
  id: number
  name: string
  code: string
  description?: string
  icon?: string
  color: string
  class_levels: string
  coefficient: number
  order_index: number
  is_active: number
  chapter_count?: number
  lesson_count?: number
  quiz_count?: number
}

export interface Chapter {
  id: number
  subject_id: number
  title: string
  description?: string
  order_index: number
  is_free: number
  is_published: number
  lesson_count?: number
}

export interface Lesson {
  id: number
  chapter_id: number
  title: string
  content: string
  lesson_type: string
  media_url?: string
  duration_minutes: number
  order_index: number
  is_free: number
  is_published: number
  view_count: number
  chapter_title?: string
  subject_id?: number
  subject_name?: string
  subject_color?: string
}

export interface Quiz {
  id: number
  subject_id: number
  chapter_id?: number
  title: string
  description?: string
  duration_minutes: number
  passing_score: number
  max_attempts: number
  is_free: number
  is_published: number
  difficulty: 'easy' | 'medium' | 'hard'
  subject_name?: string
  subject_color?: string
  subject_icon?: string
  question_count?: number
}

export interface Question {
  id: number
  quiz_id: number
  question_text: string
  question_type: 'mcq' | 'true_false' | 'short_answer'
  options?: string
  correct_answer: string
  explanation?: string
  points: number
  order_index: number
}

export interface SubscriptionPlan {
  id: number
  name: string
  description?: string
  price_ariary: number
  price_dollar: number
  duration_days: number
  features?: string
  is_active: number
}

export interface Subscription {
  id: number
  user_id: number
  plan_id: number
  start_date: string
  end_date: string
  status: string
  plan_name?: string
  features?: string
  price_ariary?: number
  price_dollar?: number
}

export interface Exam {
  id: number
  subject_id: number
  title: string
  description?: string
  exam_type: string
  year?: number
  duration_minutes: number
  content?: string
  solution_content?: string
  is_free: number
  is_published: number
  subject_name?: string
  subject_color?: string
  subject_icon?: string
}

export interface Announcement {
  id: number
  title: string
  content: string
  author_id: number
  is_published: number
  is_pinned: number
  target_audience: string
  created_at: string
  author_name?: string
}

export interface ApiResponse<T = any> {
  data?: T
  error?: string
  code?: string
  message?: string
}
