// ============================================
// MODEL - ExamModel
// ============================================

import type { Exam } from '../types'

export class ExamModel {
  constructor(private db: D1Database) {}

  async findAll(filters: { subjectId?: string, type?: string } = {}): Promise<Exam[]> {
    let query = `
      SELECT e.*, s.name as subject_name, s.color as subject_color, s.icon as subject_icon
      FROM exams e JOIN subjects s ON e.subject_id = s.id
      WHERE e.is_published = 1
    `
    const params: any[] = []
    if (filters.subjectId) { query += ' AND e.subject_id = ?'; params.push(filters.subjectId) }
    if (filters.type) { query += ' AND e.exam_type = ?'; params.push(filters.type) }
    query += ' ORDER BY e.year DESC, e.id DESC'
    const result = await this.db.prepare(query).bind(...params).all()
    return result.results as Exam[]
  }

  async findById(id: number): Promise<Exam | null> {
    return await this.db.prepare(`
      SELECT e.*, s.name as subject_name, s.color as subject_color
      FROM exams e JOIN subjects s ON e.subject_id = s.id
      WHERE e.id = ? AND e.is_published = 1
    `).bind(id).first() as Exam | null
  }
}
