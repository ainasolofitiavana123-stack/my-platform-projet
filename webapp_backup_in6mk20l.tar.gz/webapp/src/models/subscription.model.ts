// ============================================
// MODEL - SubscriptionModel
// ============================================

import type { SubscriptionPlan, Subscription } from '../types'

export class SubscriptionModel {
  constructor(private db: D1Database) {}

  async getAllPlans(): Promise<SubscriptionPlan[]> {
    const result = await this.db.prepare(
      'SELECT * FROM subscription_plans WHERE is_active = 1 ORDER BY price_ariary ASC'
    ).all()
    return result.results as SubscriptionPlan[]
  }

  async getPlanById(id: number): Promise<SubscriptionPlan | null> {
    return await this.db.prepare('SELECT * FROM subscription_plans WHERE id = ? AND is_active = 1').bind(id).first() as SubscriptionPlan | null
  }

  async getActiveSubscription(userId: number): Promise<Subscription | null> {
    return await this.db.prepare(`
      SELECT s.*, sp.name as plan_name, sp.features, sp.price_ariary, sp.price_dollar
      FROM subscriptions s JOIN subscription_plans sp ON s.plan_id = sp.id
      WHERE s.user_id = ? AND s.status = 'active' AND s.end_date > datetime('now')
      ORDER BY s.end_date DESC LIMIT 1
    `).bind(userId).first() as Subscription | null
  }

  async hasActiveSubscription(userId: number): Promise<boolean> {
    const sub = await this.db.prepare(`
      SELECT id FROM subscriptions
      WHERE user_id = ? AND plan_id > 1 AND status = 'active' AND end_date > datetime('now')
    `).bind(userId).first()
    return !!sub
  }

  async getUserSubscriptions(userId: number): Promise<Subscription[]> {
    const result = await this.db.prepare(`
      SELECT s.*, sp.name as plan_name, sp.features, sp.price_ariary, sp.price_dollar
      FROM subscriptions s JOIN subscription_plans sp ON s.plan_id = sp.id
      WHERE s.user_id = ? ORDER BY s.created_at DESC
    `).bind(userId).all()
    return result.results as Subscription[]
  }

  async createFreeSubscription(userId: number): Promise<void> {
    const endDate = new Date()
    endDate.setFullYear(endDate.getFullYear() + 100)
    await this.db.prepare(
      'INSERT INTO subscriptions (user_id, plan_id, end_date, status) VALUES (?, 1, ?, "active")'
    ).bind(userId, endDate.toISOString()).run()
  }

  async createPaidSubscription(data: {
    userId: number, planId: number, durationDays: number,
    paymentMethod: string, paymentReference: string, amount: number, currency: string
  }): Promise<{ subscriptionId: number, endDate: Date }> {
    // Récupérer l'abonnement actif actuel
    const existing = await this.getActiveSubscription(data.userId)
    const startDate = new Date()
    let endDate = new Date()

    if (existing && existing.plan_id > 1 && new Date(existing.end_date) > startDate) {
      endDate = new Date(existing.end_date)
    }
    endDate.setDate(endDate.getDate() + data.durationDays)

    // Créer le paiement
    const paymentResult = await this.db.prepare(`
      INSERT INTO payments (user_id, amount, currency, payment_method, transaction_id, status)
      VALUES (?, ?, ?, ?, ?, 'completed')
    `).bind(data.userId, data.amount, data.currency, data.paymentMethod,
      data.paymentReference || `TXN-${Date.now()}`).run()

    // Créer l'abonnement
    const subResult = await this.db.prepare(`
      INSERT INTO subscriptions (user_id, plan_id, end_date, status, payment_method, payment_reference, amount_paid, currency)
      VALUES (?, ?, ?, 'active', ?, ?, ?, ?)
    `).bind(data.userId, data.planId, endDate.toISOString(), data.paymentMethod,
      data.paymentReference || `TXN-${Date.now()}`, data.amount, data.currency).run()

    const subId = subResult.meta.last_row_id as number
    await this.db.prepare('UPDATE payments SET subscription_id = ? WHERE id = ?')
      .bind(subId, paymentResult.meta.last_row_id).run()

    return { subscriptionId: subId, endDate }
  }

  async getActiveCount(): Promise<number> {
    const r = await this.db.prepare(
      'SELECT COUNT(*) as count FROM subscriptions WHERE status = "active" AND end_date > datetime("now") AND plan_id > 1'
    ).first() as any
    return r?.count || 0
  }
}
