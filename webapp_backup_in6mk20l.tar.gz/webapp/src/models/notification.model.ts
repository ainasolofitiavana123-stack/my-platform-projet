// ============================================
// MODEL - NotificationModel
// ============================================

export class NotificationModel {
  constructor(private db: D1Database) {}

  async create(userId: number, title: string, message: string, type: string = 'info', link?: string): Promise<void> {
    await this.db.prepare(
      'INSERT INTO notifications (user_id, title, message, type, link) VALUES (?, ?, ?, ?, ?)'
    ).bind(userId, title, message, type, link || null).run()
  }

  async getForUser(userId: number, limit = 20): Promise<any[]> {
    const result = await this.db.prepare(
      'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?'
    ).bind(userId, limit).all()
    return result.results
  }

  async getUnreadCount(userId: number): Promise<number> {
    const r = await this.db.prepare(
      'SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0'
    ).bind(userId).first() as any
    return r?.count || 0
  }

  async markAllRead(userId: number): Promise<void> {
    await this.db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').bind(userId).run()
  }
}
