// ============================================
// MODEL - QuizModel
// ============================================

import type { Quiz, Question } from '../types'

export class QuizModel {
  constructor(private db: D1Database) {}

  async findAll(filters: { subjectId?: string, difficulty?: string } = {}): Promise<Quiz[]> {
    let query = `
      SELECT q.*, s.name as subject_name, s.color as subject_color, s.icon as subject_icon,
        ch.title as chapter_title,
        (SELECT COUNT(*) FROM questions WHERE quiz_id = q.id) as question_count
      FROM quizzes q
      JOIN subjects s ON q.subject_id = s.id
      LEFT JOIN chapters ch ON q.chapter_id = ch.id
      WHERE q.is_published = 1
    `
    const params: any[] = []
    if (filters.subjectId) { query += ' AND q.subject_id = ?'; params.push(filters.subjectId) }
    if (filters.difficulty) { query += ' AND q.difficulty = ?'; params.push(filters.difficulty) }
    query += ' ORDER BY q.id DESC'
    const result = await this.db.prepare(query).bind(...params).all()
    return result.results as Quiz[]
  }

  async findById(id: number): Promise<Quiz | null> {
    return await this.db.prepare(`
      SELECT q.*, s.name as subject_name, s.color as subject_color, s.icon as subject_icon,
        (SELECT COUNT(*) FROM questions WHERE quiz_id = q.id) as question_count
      FROM quizzes q JOIN subjects s ON q.subject_id = s.id
      WHERE q.id = ? AND q.is_published = 1
    `).bind(id).first() as Quiz | null
  }

  // Questions SANS les bonnes réponses (pour le frontend)
  async getQuestionsForStudent(quizId: number): Promise<Omit<Question, 'correct_answer' | 'explanation'>[]> {
    const result = await this.db.prepare(
      'SELECT id, question_text, question_type, options, points, order_index FROM questions WHERE quiz_id = ? ORDER BY order_index ASC'
    ).bind(quizId).all()
    return result.results as any[]
  }

  // Questions AVEC les bonnes réponses (pour correction)
  async getQuestionsWithAnswers(quizId: number): Promise<Question[]> {
    const result = await this.db.prepare(
      'SELECT * FROM questions WHERE quiz_id = ? ORDER BY order_index ASC'
    ).bind(quizId).all()
    return result.results as Question[]
  }

  async getAttemptCount(userId: number, quizId: number): Promise<number> {
    const r = await this.db.prepare(
      'SELECT COUNT(*) as count FROM quiz_attempts WHERE user_id = ? AND quiz_id = ?'
    ).bind(userId, quizId).first() as any
    return r?.count || 0
  }

  async saveAttempt(data: {
    userId: number, quizId: number, score: number, totalPoints: number,
    answers: Record<string, string>, timeTaken: number, passed: boolean, attemptNumber: number
  }): Promise<number> {
    const result = await this.db.prepare(`
      INSERT INTO quiz_attempts (user_id, quiz_id, score, total_points, answers, time_taken_seconds, passed, attempt_number)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      data.userId, data.quizId, data.score, data.totalPoints,
      JSON.stringify(data.answers), data.timeTaken,
      data.passed ? 1 : 0, data.attemptNumber
    ).run()
    return result.meta.last_row_id as number
  }

  async getAttemptHistory(userId: number, quizId: number): Promise<any[]> {
    const result = await this.db.prepare(
      'SELECT * FROM quiz_attempts WHERE user_id = ? AND quiz_id = ? ORDER BY completed_at DESC'
    ).bind(userId, quizId).all()
    return result.results
  }
}
