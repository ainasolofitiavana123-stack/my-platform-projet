// ============================================
// MODEL - UserModel (accès aux données utilisateurs)
// ============================================

import type { User } from '../types'
import { hashPassword } from '../middleware/jwt'
import { APP_CONFIG } from '../config/app.config'

export class UserModel {
  constructor(private db: D1Database) {}

  async findById(id: number): Promise<User | null> {
    return await this.db.prepare(
      'SELECT id, email, full_name, role, class_level, avatar, is_active, created_at FROM users WHERE id = ?'
    ).bind(id).first() as User | null
  }

  async findByEmail(email: string): Promise<User | null> {
    return await this.db.prepare(
      'SELECT * FROM users WHERE email = ? AND is_active = 1'
    ).bind(email).first() as User | null
  }

  async create(data: {
    email: string
    password: string
    full_name: string
    class_level?: string
    role?: string
  }): Promise<number> {
    const password_hash = await hashPassword(data.password)
    const result = await this.db.prepare(
      'INSERT INTO users (email, password_hash, full_name, class_level, role) VALUES (?, ?, ?, ?, ?)'
    ).bind(
      data.email,
      password_hash,
      data.full_name,
      data.class_level || 'terminale_a1',
      data.role || 'student'
    ).run()
    return result.meta.last_row_id as number
  }

  async verifyPassword(user: User, password: string): Promise<boolean> {
    const hash = await hashPassword(password)
    return user.password_hash === hash
  }

  async updateProfile(id: number, data: Partial<Pick<User, 'full_name' | 'class_level' | 'avatar'>>): Promise<void> {
    const fields = Object.entries(data).filter(([_, v]) => v !== undefined)
    if (!fields.length) return
    const sets = fields.map(([k]) => `${k} = ?`).join(', ')
    const values = fields.map(([_, v]) => v)
    await this.db.prepare(`UPDATE users SET ${sets}, updated_at = datetime('now') WHERE id = ?`)
      .bind(...values, id).run()
  }

  async getAll(page = 1, limit = 20): Promise<{ users: User[], total: number }> {
    const offset = (page - 1) * limit
    const users = await this.db.prepare(`
      SELECT u.id, u.email, u.full_name, u.role, u.class_level, u.is_active, u.created_at,
        (SELECT sp.name FROM subscriptions s JOIN subscription_plans sp ON s.plan_id = sp.id 
         WHERE s.user_id = u.id AND s.status = 'active' AND s.end_date > datetime('now') 
         ORDER BY s.end_date DESC LIMIT 1) as current_plan
      FROM users u ORDER BY u.created_at DESC LIMIT ? OFFSET ?
    `).bind(limit, offset).all()
    const total = await this.db.prepare('SELECT COUNT(*) as count FROM users').first() as any
    return { users: users.results as User[], total: total?.count || 0 }
  }

  async ensureAdminExists(): Promise<void> {
    const admin = await this.findByEmail(APP_CONFIG.admin_email)
    if (!admin) {
      const adminId = await this.create({
        email: APP_CONFIG.admin_email,
        password: APP_CONFIG.admin_password,
        full_name: 'Administrateur Principal',
        role: 'admin',
        class_level: 'terminale_a1'
      })
      await this.db.prepare(
        'INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, "success")'
      ).bind(adminId, 'Compte administrateur créé', `Bienvenue sur Terminale Madagascar!`).run()
    } else {
      // S'assurer que le rôle est admin ET que le mot de passe est correct
      const isValid = await this.verifyPassword(admin, APP_CONFIG.admin_password)
      if (!isValid) {
        // Mettre à jour le mot de passe et le rôle
        const newHash = await hashPassword(APP_CONFIG.admin_password)
        await this.db.prepare('UPDATE users SET password_hash = ?, role = "admin" WHERE email = ?')
          .bind(newHash, APP_CONFIG.admin_email).run()
      } else if (admin.role !== 'admin') {
        await this.db.prepare('UPDATE users SET role = "admin" WHERE email = ?')
          .bind(APP_CONFIG.admin_email).run()
      }
    }
  }
}
