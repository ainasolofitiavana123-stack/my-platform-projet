// ============================================
// MODEL - LessonModel
// ============================================

import type { Lesson } from '../types'

export class LessonModel {
  constructor(private db: D1Database) {}

  async findById(id: number): Promise<Lesson | null> {
    return await this.db.prepare(`
      SELECT l.*, ch.title as chapter_title, ch.subject_id,
        s.name as subject_name, s.color as subject_color
      FROM lessons l
      JOIN chapters ch ON l.chapter_id = ch.id
      JOIN subjects s ON ch.subject_id = s.id
      WHERE l.id = ? AND l.is_published = 1
    `).bind(id).first() as Lesson | null
  }

  async incrementViewCount(id: number): Promise<void> {
    await this.db.prepare('UPDATE lessons SET view_count = view_count + 1 WHERE id = ?').bind(id).run()
  }

  async getSiblings(chapterId: number): Promise<Array<{ id: number, title: string, order_index: number }>> {
    const result = await this.db.prepare(
      'SELECT id, title, order_index FROM lessons WHERE chapter_id = ? AND is_published = 1 ORDER BY order_index ASC'
    ).bind(chapterId).all()
    return result.results as any[]
  }

  async getProgress(userId: number, lessonId: number): Promise<any> {
    return await this.db.prepare(
      'SELECT * FROM lesson_progress WHERE user_id = ? AND lesson_id = ?'
    ).bind(userId, lessonId).first()
  }

  async markComplete(userId: number, lessonId: number): Promise<void> {
    await this.db.prepare(`
      INSERT INTO lesson_progress (user_id, lesson_id, is_completed, completed_at)
      VALUES (?, ?, 1, datetime('now'))
      ON CONFLICT(user_id, lesson_id) DO UPDATE SET is_completed = 1, completed_at = datetime('now')
    `).bind(userId, lessonId).run()
  }
}
