// ============================================
// MODEL - AnnouncementModel
// ============================================

import type { Announcement } from '../types'

export class AnnouncementModel {
  constructor(private db: D1Database) {}

  async getPublic(limit = 5): Promise<Announcement[]> {
    const result = await this.db.prepare(`
      SELECT a.*, u.full_name as author_name FROM announcements a
      JOIN users u ON a.author_id = u.id
      WHERE a.is_published = 1
      ORDER BY a.is_pinned DESC, a.created_at DESC LIMIT ?
    `).bind(limit).all()
    return result.results as Announcement[]
  }

  async getAll(): Promise<Announcement[]> {
    const result = await this.db.prepare(`
      SELECT a.*, u.full_name as author_name FROM announcements a
      JOIN users u ON a.author_id = u.id
      ORDER BY a.created_at DESC
    `).all()
    return result.results as Announcement[]
  }

  async create(data: {
    title: string, content: string, authorId: number,
    targetAudience?: string, isPinned?: boolean
  }): Promise<number> {
    const result = await this.db.prepare(`
      INSERT INTO announcements (title, content, author_id, target_audience, is_pinned, is_published)
      VALUES (?, ?, ?, ?, ?, 1)
    `).bind(data.title, data.content, data.authorId, data.targetAudience || 'all', data.isPinned ? 1 : 0).run()
    return result.meta.last_row_id as number
  }

  async delete(id: number): Promise<void> {
    await this.db.prepare('DELETE FROM announcements WHERE id = ?').bind(id).run()
  }
}
