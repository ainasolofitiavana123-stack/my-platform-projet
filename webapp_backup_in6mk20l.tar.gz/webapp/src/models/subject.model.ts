// ============================================
// MODEL - SubjectModel
// ============================================

import type { Subject, Chapter, Lesson } from '../types'

export class SubjectModel {
  constructor(private db: D1Database) {}

  async findAll(classLevel: string): Promise<Subject[]> {
    const result = await this.db.prepare(`
      SELECT s.*,
        (SELECT COUNT(*) FROM chapters ch WHERE ch.subject_id = s.id AND ch.is_published = 1) as chapter_count,
        (SELECT COUNT(*) FROM lessons l JOIN chapters ch ON l.chapter_id = ch.id WHERE ch.subject_id = s.id AND l.is_published = 1) as lesson_count,
        (SELECT COUNT(*) FROM quizzes q WHERE q.subject_id = s.id AND q.is_published = 1) as quiz_count
      FROM subjects s
      WHERE s.is_active = 1 AND s.class_levels LIKE ?
      ORDER BY s.order_index ASC
    `).bind(`%${classLevel}%`).all()
    return result.results as Subject[]
  }

  async findById(id: number): Promise<Subject | null> {
    return await this.db.prepare('SELECT * FROM subjects WHERE id = ? AND is_active = 1').bind(id).first() as Subject | null
  }

  async getChapters(subjectId: number): Promise<Chapter[]> {
    const result = await this.db.prepare(`
      SELECT ch.*,
        (SELECT COUNT(*) FROM lessons l WHERE l.chapter_id = ch.id AND l.is_published = 1) as lesson_count
      FROM chapters ch
      WHERE ch.subject_id = ? AND ch.is_published = 1
      ORDER BY ch.order_index ASC
    `).bind(subjectId).all()
    return result.results as Chapter[]
  }

  async getLessons(chapterId: number, includeContent: boolean = false): Promise<Lesson[]> {
    const contentField = includeContent ? 'content,' : '"" as content,'
    const result = await this.db.prepare(`
      SELECT id, title, lesson_type, ${contentField} duration_minutes, order_index, is_free, media_url, view_count
      FROM lessons
      WHERE chapter_id = ? AND is_published = 1
      ORDER BY order_index ASC
    `).bind(chapterId).all()
    return result.results as Lesson[]
  }
}
