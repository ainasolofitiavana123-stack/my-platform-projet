# 📚 Terminale Madagascar - Plateforme de Cours en Ligne

## 🏗️ Architecture MVC

```
src/
├── config/
│   └── app.config.ts          # Configuration centrale (admin email, JWT secret)
│
├── models/                    # 📦 MODELS - Accès aux données (D1 SQLite)
│   ├── user.model.ts          # Utilisateurs, auth, ensureAdminExists
│   ├── subject.model.ts       # Matières, chapitres, leçons
│   ├── lesson.model.ts        # Leçons, progression
│   ├── quiz.model.ts          # Quiz, questions, tentatives
│   ├── subscription.model.ts  # Plans, abonnements, paiements
│   ├── exam.model.ts          # Examens BAC
│   ├── notification.model.ts  # Notifications utilisateur
│   └── announcement.model.ts  # Annonces publiques
│
├── controllers/               # 🎮 CONTROLLERS - Logique métier
│   ├── auth.controller.ts     # Inscription, connexion, JWT stateless
│   ├── subject.controller.ts  # Gestion des matières
│   ├── lesson.controller.ts   # Affichage et progression
│   ├── quiz.controller.ts     # Quiz, soumission, correction
│   ├── subscription.controller.ts # Abonnements, paiements
│   ├── exam.controller.ts     # Examens BAC
│   ├── dashboard.controller.ts # Tableau de bord utilisateur
│   └── admin.controller.ts    # Administration
│
├── views/                     # 👁️ VIEWS - Routers/Endpoints HTTP
│   ├── auth.router.ts         # POST /api/auth/*
│   ├── subject.router.ts      # GET /api/subjects/*
│   ├── lesson.router.ts       # GET/POST /api/lessons/*
│   ├── quiz.router.ts         # GET/POST /api/quiz/*
│   ├── subscription.router.ts # GET/POST /api/subscriptions/*
│   ├── exam.router.ts         # GET /api/exams/*
│   ├── dashboard.router.ts    # GET/POST /api/dashboard/*
│   └── admin.router.ts        # GET/POST/DELETE /api/admin/*
│
├── middleware/                # 🔒 MIDDLEWARE
│   ├── jwt.ts                 # JWT Stateless HMAC-SHA256
│   └── auth.middleware.ts     # requireAuth, requireAdmin, optionalAuth
│
├── types.ts                   # Types TypeScript centraux
└── index.tsx                  # Point d'entrée principal
```

## 🔐 JWT Stateless (Sans Sessions)

L'authentification est **100% stateless** - aucune session n'est stockée en base de données :
- Le JWT contient : `userId`, `email`, `role`, `class_level`, `iat`, `exp`
- Signature HMAC-SHA256 vérifiée à chaque requête
- Expiration automatique après 30 jours
- Le token est stocké uniquement dans `localStorage` côté client
- **Logout** = suppression du token côté client uniquement

## 👤 Compte Administrateur

| Champ | Valeur |
|-------|--------|
| Email | `ainasolofitiavana123@gmail.com` |
| Mot de passe | `Admin@2024!` |
| Rôle | `admin` |

Le compte admin est **créé automatiquement** au démarrage via `UserModel.ensureAdminExists()`.

## 🌐 URL de la Plateforme
- **Développement local** : `http://localhost:3000`

## ✅ Fonctionnalités

### 📖 Cours
- **16 matières** Terminale A1 & A2
- Chapitres structurés avec leçons détaillées
- Suivi de progression par leçon

### 🎯 Quiz Interactifs
- 11+ quiz avec chronomètre temps réel
- Correction automatique avec explications
- Historique des tentatives

### 📝 Examens BAC
- BAC officiels 2022, 2023
- Devoirs pratiques

### 💳 Abonnements

| Plan | Ariary | Dollar | Durée |
|------|--------|--------|-------|
| Gratuit | 0 Ar | $0 | Illimité |
| Mensuel | 15 000 Ar | $3 | 30 jours |
| Trimestriel | 40 000 Ar | $8 | 90 jours |
| Annuel | 130 000 Ar | $26 | 365 jours |

**Paiements** : MVola, Orange Money, Visa/MasterCard, PayPal

## 🚀 Démarrage Rapide

```bash
# Installation
npm install

# Migrations DB locale
npm run db:migrate:local

# Build
npm run build

# Démarrer (avec PM2)
pm2 start ecosystem.config.cjs

# Test
curl http://localhost:3000/api/health
```

## 📡 API Endpoints

```
GET  /api/health                    # Santé + version
POST /api/auth/register             # Inscription
POST /api/auth/login                # Connexion JWT
GET  /api/auth/me                   # Profil (JWT requis)
POST /api/auth/refresh              # Refresh token
POST /api/auth/logout               # Logout (stateless)

GET  /api/subjects?class_level=...  # Liste matières
GET  /api/subjects/:id              # Détail matière
GET  /api/subjects/:id/chapters/:chapterId/lessons

GET  /api/lessons/:id              # Leçon
POST /api/lessons/:id/complete     # Marquer complété (auth)

GET  /api/quiz                     # Liste quiz
GET  /api/quiz/:id                 # Détail quiz
POST /api/quiz/:id/submit          # Soumettre réponses (auth)
GET  /api/quiz/:id/history         # Historique (auth)

GET  /api/subscriptions/plans      # Plans disponibles
GET  /api/subscriptions/my         # Mes abonnements (auth)
POST /api/subscriptions/subscribe  # S'abonner (auth)

GET  /api/exams                    # Liste examens
GET  /api/exams/:id               # Examen

GET  /api/dashboard               # Tableau de bord (auth)
GET  /api/dashboard/notifications  # Notifications (auth)

GET  /api/admin/stats             # Stats admin (admin)
GET  /api/admin/users             # Utilisateurs (admin)
POST /api/admin/announcements     # Nouvelle annonce (admin)
```

## 🛠️ Stack Technique

- **Backend** : Hono.js (TypeScript) - Architecture MVC
- **Auth** : JWT HMAC-SHA256 Stateless (sans sessions DB)
- **Database** : Cloudflare D1 (SQLite)
- **Frontend** : HTML/JS Vanilla + TailwindCSS CDN
- **Déploiement** : Cloudflare Pages/Workers

## 📅 Statut
- **Version** : 2.0.0 MVC
- **Date** : Février 2026
- **Architecture** : MVC + JWT Stateless ✅
