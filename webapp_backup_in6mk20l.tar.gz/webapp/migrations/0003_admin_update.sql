-- Migration 0003: Mise à jour compte admin principal
-- Admin: ainasolofitiavana123@gmail.com

-- Supprimer l'ancien admin si existe
DELETE FROM users WHERE email = 'admin@terminale-mg.mg';

-- S'assurer que l'admin principal a le bon rôle
-- Le mot de passe sera mis à jour par UserModel.ensureAdminExists() au démarrage
INSERT OR IGNORE INTO users (id, email, password_hash, full_name, role, class_level, is_active)
VALUES (1, 'ainasolofitiavana123@gmail.com', 'will_be_set_on_first_login', 'Administrateur Principal', 'admin', 'terminale_a1', 1);

UPDATE users SET role = 'admin' WHERE email = 'ainasolofitiavana123@gmail.com';
