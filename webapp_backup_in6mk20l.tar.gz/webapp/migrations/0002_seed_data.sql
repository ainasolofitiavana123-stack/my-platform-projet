-- ================================================
-- Données initiales - Plans d'abonnement
-- ================================================

-- Plans d'abonnement
INSERT OR IGNORE INTO subscription_plans (id, name, description, price_ariary, price_dollar, duration_days, features) VALUES
(1, 'Gratuit', 'Accès limité aux cours et quiz gratuits', 0, 0, 36500, '["Accès aux cours gratuits","Quiz gratuits","Forum de discussion"]'),
(2, 'Mensuel', 'Accès complet pendant 1 mois', 15000, 3, 30, '["Accès complet à tous les cours","Tous les quiz illimités","Examens du BAC","Téléchargement de ressources","Support prioritaire","Suivi de progression"]'),
(3, 'Trimestriel', 'Accès complet pendant 3 mois', 40000, 8, 90, '["Accès complet à tous les cours","Tous les quiz illimités","Examens du BAC","Téléchargement de ressources","Support prioritaire","Suivi de progression","Économisez 11%"]'),
(4, 'Annuel', 'Accès complet pendant 1 an', 130000, 26, 365, '["Accès complet à tous les cours","Tous les quiz illimités","Examens du BAC","Téléchargement de ressources","Support prioritaire","Suivi de progression","Certificats de réussite","Économisez 28%"]');

-- ================================================
-- Matières Terminale A1 & A2 - Madagascar
-- ================================================

INSERT OR IGNORE INTO subjects (id, name, code, description, icon, color, class_levels, coefficient, order_index) VALUES
-- Matières communes A1 et A2
(1, 'Philosophie', 'PHILO', 'Étude des grandes questions existentielles, éthiques et logiques', '🧠', '#7C3AED', '["terminale_a1","terminale_a2"]', 3, 1),
(2, 'Histoire-Géographie', 'HISTGEO', 'Histoire mondiale et géographie humaine et physique', '🌍', '#059669', '["terminale_a1","terminale_a2"]', 3, 2),
(3, 'Éducation Civique', 'EDC', 'Citoyenneté, droits et devoirs civiques', '🏛️', '#DC2626', '["terminale_a1","terminale_a2"]', 2, 3),
(4, 'Mathématiques', 'MATHS', 'Mathématiques générales et approfondies', '📐', '#2563EB', '["terminale_a1","terminale_a2"]', 2, 4),
(5, 'Sciences Physiques', 'SCP', 'Physique-Chimie appliquée', '⚗️', '#7C3AED', '["terminale_a1","terminale_a2"]', 2, 5),
(6, 'Sciences de la Vie et de la Terre', 'SVT', 'Biologie, géologie et sciences naturelles', '🌱', '#16A34A', '["terminale_a1","terminale_a2"]', 2, 6),
(7, 'Français', 'FR', 'Littérature française, expression écrite et orale', '📝', '#EA580C', '["terminale_a1","terminale_a2"]', 3, 7),
(8, 'Malagasy', 'MLG', 'Langue et littérature malgache', '🇲🇬', '#B45309', '["terminale_a1","terminale_a2"]', 3, 8),
(9, 'Anglais', 'ENG', 'Langue anglaise - compréhension et expression', '🇬🇧', '#0891B2', '["terminale_a1","terminale_a2"]', 2, 9),

-- Matières spécifiques A1 (Lettres et Sciences Humaines)
(10, 'Latin', 'LAT', 'Langue et civilisation latines', '🏛️', '#92400E', '["terminale_a1"]', 2, 10),
(11, 'Grec Ancien', 'GREC', 'Langue et civilisation grecques anciennes', '🏺', '#78350F', '["terminale_a1"]', 2, 11),
(12, 'Littérature Comparée', 'LITCOMP', 'Analyse comparative des oeuvres littéraires', '📚', '#BE185D', '["terminale_a1"]', 3, 12),

-- Matières spécifiques A2 (Sciences Sociales et Économie)
(13, 'Économie', 'ECO', 'Microéconomie, macroéconomie et économie nationale', '📊', '#0369A1', '["terminale_a2"]', 4, 10),
(14, 'Sociologie', 'SOC', 'Sociétés, structures sociales et dynamiques', '👥', '#7E22CE', '["terminale_a2"]', 3, 11),
(15, 'Droit', 'DROIT', 'Droit civil, commercial et constitutionnel', '⚖️', '#15803D', '["terminale_a2"]', 3, 12),
(16, 'Gestion', 'GEST', 'Gestion comptable et administrative', '💼', '#1D4ED8', '["terminale_a2"]', 3, 13);

-- ================================================
-- Chapitres et Leçons - Philosophie
-- ================================================
INSERT OR IGNORE INTO chapters (id, subject_id, title, description, order_index, is_free) VALUES
(1, 1, 'Introduction à la Philosophie', 'Les bases et l''histoire de la philosophie', 1, 1),
(2, 1, 'La Conscience et l''Inconscient', 'Exploration de la conscience humaine', 2, 0),
(3, 1, 'La Liberté et le Destin', 'Qu''est-ce que la liberté réelle?', 3, 0),
(4, 1, 'La Morale et l''Éthique', 'Fondements de la morale philosophique', 4, 0),
(5, 1, 'La Connaissance et la Vérité', 'Épistémologie et théorie de la connaissance', 5, 0),
(6, 1, 'La Politique et la Société', 'Philosophie politique et sociale', 6, 0),

-- Chapitres Histoire-Géo
(7, 2, 'Le Monde au XXème Siècle', 'Les grandes transformations mondiales', 1, 1),
(8, 2, 'La Décolonisation et le Tiers-Monde', 'Indépendances et développement', 2, 0),
(9, 2, 'La Guerre Froide', 'USA vs URSS - bipolarisation du monde', 3, 0),
(10, 2, 'Le Monde Contemporain', 'Mondialisation et défis actuels', 4, 0),
(11, 2, 'Madagascar - Géographie', 'Relief, climat et régions de Madagascar', 5, 1),
(12, 2, 'Géopolitique Mondiale', 'Les grandes puissances et relations internationales', 6, 0),

-- Chapitres Économie (A2)
(13, 13, 'Introduction à l''Économie', 'Concepts fondamentaux de l''économie', 1, 1),
(14, 13, 'Microéconomie', 'Offre, demande et marchés', 2, 0),
(15, 13, 'Macroéconomie', 'PIB, croissance et politiques économiques', 3, 0),
(16, 13, 'Économie Internationale', 'Commerce mondial et échanges', 4, 0),
(17, 13, 'Économie Malgache', 'Structure et défis de l''économie de Madagascar', 5, 0),

-- Chapitres Français
(18, 7, 'Le Roman et ses Genres', 'Histoire et analyse du roman français', 1, 1),
(19, 7, 'La Poésie Française', 'Du Moyen-Âge au XXème siècle', 2, 0),
(20, 7, 'Le Théâtre', 'Tragédie, comédie et théâtre moderne', 3, 0),
(21, 7, 'Expression Écrite', 'Dissertation, commentaire et résumé', 4, 0),
(22, 7, 'Argumentation et Rhétorique', 'Techniques d''argumentation', 5, 0),

-- Chapitres Maths
(23, 4, 'Suites et Séries', 'Suites numériques et leurs propriétés', 1, 1),
(24, 4, 'Dérivation et Intégration', 'Calcul différentiel et intégral', 2, 0),
(25, 4, 'Probabilités et Statistiques', 'Calcul des probabilités', 3, 0),
(26, 4, 'Géométrie Analytique', 'Géométrie dans le plan et l''espace', 4, 0),

-- Chapitres Anglais
(27, 9, 'Grammar Advanced', 'Grammaire anglaise avancée', 1, 1),
(28, 9, 'Reading Comprehension', 'Techniques de compréhension écrite', 2, 0),
(29, 9, 'Essay Writing', 'Rédaction en anglais', 3, 0),

-- Chapitres SVT
(30, 6, 'La Génétique', 'Hérédité et génétique moléculaire', 1, 1),
(31, 6, 'L''Évolution des Espèces', 'Théories de l''évolution', 2, 0),
(32, 6, 'L''Écologie', 'Écosystèmes et environnement', 3, 0);

-- ================================================
-- Leçons initiales
-- ================================================
INSERT OR IGNORE INTO lessons (id, chapter_id, title, content, lesson_type, order_index, is_free) VALUES
(1, 1, 'Qu''est-ce que la Philosophie?', 
'<h2>Définition et origines de la Philosophie</h2>
<p>Le mot <strong>philosophie</strong> vient du grec ancien <em>philosophia</em> qui signifie « amour de la sagesse » (philein = aimer, sophia = sagesse).</p>

<h3>1. Les grandes questions philosophiques</h3>
<ul>
  <li><strong>Qu''est-ce que l''être?</strong> (Ontologie)</li>
  <li><strong>Comment connaissons-nous le monde?</strong> (Épistémologie)</li>
  <li><strong>Qu''est-ce qui est bien/mal?</strong> (Éthique)</li>
  <li><strong>Comment devons-nous vivre ensemble?</strong> (Philosophie politique)</li>
</ul>

<h3>2. Les grands philosophes</h3>
<table class="table">
  <tr><th>Philosophe</th><th>Époque</th><th>Apport principal</th></tr>
  <tr><td>Socrate</td><td>470-399 av. J.C</td><td>La maïeutique, connais-toi toi-même</td></tr>
  <tr><td>Platon</td><td>428-348 av. J.C</td><td>La théorie des Idées</td></tr>
  <tr><td>Aristote</td><td>384-322 av. J.C</td><td>La logique, la physique</td></tr>
  <tr><td>Descartes</td><td>1596-1650</td><td>Le cogito, la méthode</td></tr>
  <tr><td>Kant</td><td>1724-1804</td><td>La raison critique</td></tr>
</table>

<h3>3. La méthode philosophique</h3>
<p>La philosophie se pratique à travers :</p>
<ol>
  <li>La <strong>problématisation</strong> : poser les bonnes questions</li>
  <li>La <strong>conceptualisation</strong> : définir précisément les notions</li>
  <li>L''<strong>argumentation</strong> : construire des raisonnements solides</li>
</ol>

<div class="alert alert-info">
  <strong>💡 À retenir :</strong> La philosophie n''est pas une science qui donne des réponses définitives, mais une discipline qui apprend à <em>bien poser les questions</em> et à <em>raisonner rigoureusement</em>.
</div>', 'text', 1, 1),

(2, 1, 'Les Grandes Branches de la Philosophie',
'<h2>Les domaines de la philosophie</h2>
<p>La philosophie se divise en plusieurs branches principales :</p>

<h3>1. La Métaphysique</h3>
<p>Étude de l''être en tant qu''être, de la réalité ultime, de Dieu, de l''âme et du monde.</p>
<blockquote>« Pourquoi y a-t-il quelque chose plutôt que rien? » - Leibniz</blockquote>

<h3>2. L''Épistémologie</h3>
<p>Théorie de la connaissance : comment savons-nous ce que nous savons?</p>

<h3>3. L''Éthique</h3>
<p>Réflexion sur les normes morales, le bien et le mal, le devoir.</p>

<h3>4. La Logique</h3>
<p>Étude des principes du raisonnement valide et de l''argumentation.</p>

<h3>5. La Philosophie Politique</h3>
<p>Réflexion sur la justice, l''État, le pouvoir et la démocratie.</p>', 'text', 2, 1),

(3, 7, 'La Première Guerre Mondiale (1914-1918)',
'<h2>La Grande Guerre</h2>
<h3>1. Les causes</h3>
<ul>
  <li><strong>Causes immédiates :</strong> Assassinat de l''archiduc François-Ferdinand à Sarajevo (28 juin 1914)</li>
  <li><strong>Causes profondes :</strong> Nationalisme, impérialisme, course aux armements, système d''alliances</li>
</ul>

<h3>2. Les deux camps</h3>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
  <div style="background:#fef2f2;padding:1rem;border-radius:0.5rem">
    <h4>Triple Alliance</h4>
    <ul><li>Allemagne</li><li>Autriche-Hongrie</li><li>Italie (puis neutre)</li></ul>
  </div>
  <div style="background:#eff6ff;padding:1rem;border-radius:0.5rem">
    <h4>Triple Entente</h4>
    <ul><li>France</li><li>Russie</li><li>Royaume-Uni</li></ul>
  </div>
</div>

<h3>3. Les grandes batailles</h3>
<ul>
  <li><strong>Verdun (1916)</strong> : 700 000 morts - guerre de tranchées</li>
  <li><strong>La Somme (1916)</strong> : 1 million de victimes</li>
  <li><strong>Marne (1914, 1918)</strong> : pivot de la guerre</li>
</ul>

<h3>4. Le bilan</h3>
<p>17 millions de morts • Révolution russe (1917) • Traité de Versailles (1919)</p>',
'text', 1, 1),

(4, 13, 'Les Fondements de l''Économie',
'<h2>Introduction à l''économie</h2>
<p>L''<strong>économie</strong> est la science qui étudie comment les individus et les sociétés gèrent des ressources rares pour satisfaire des besoins illimités.</p>

<h3>1. Les agents économiques</h3>
<ul>
  <li><strong>Les ménages</strong> : consomment et offrent du travail</li>
  <li><strong>Les entreprises</strong> : produisent et demandent du travail</li>
  <li><strong>L''État</strong> : régule et redistribue</li>
  <li><strong>Le reste du monde</strong> : échanges internationaux</li>
</ul>

<h3>2. Les trois questions fondamentales</h3>
<ol>
  <li><strong>Quoi produire?</strong> (allocation des ressources)</li>
  <li><strong>Comment produire?</strong> (techniques de production)</li>
  <li><strong>Pour qui produire?</strong> (distribution des revenus)</li>
</ol>

<h3>3. Les grands systèmes économiques</h3>
<table class="table">
  <tr><th>Système</th><th>Caractéristiques</th><th>Exemple</th></tr>
  <tr><td>Capitalisme</td><td>Propriété privée, marché libre</td><td>USA</td></tr>
  <tr><td>Socialisme</td><td>Propriété collective, planification</td><td>Cuba (ancien)</td></tr>
  <tr><td>Économie mixte</td><td>Marché + intervention de l''État</td><td>France, Madagascar</td></tr>
</table>', 'text', 1, 1),

(5, 18, 'Introduction au Roman Français',
'<h2>Le Roman - Genre Littéraire Majeur</h2>
<p>Le <strong>roman</strong> est un récit de fiction en prose, généralement long, qui explore les aventures et la vie intérieure de personnages.</p>

<h3>1. Histoire du Roman</h3>
<ul>
  <li><strong>XVII-XVIIIème s.</strong> : Roman d''aventures (Robinson Crusoe, Candide)</li>
  <li><strong>XIXème s.</strong> : Réalisme et naturalisme (Balzac, Zola, Flaubert)</li>
  <li><strong>XXème s.</strong> : Nouveau roman, roman psychologique</li>
</ul>

<h3>2. Les caractéristiques du roman</h3>
<ul>
  <li>Récit long en prose</li>
  <li>Personnages nombreux et développés</li>
  <li>Intrigue complexe</li>
  <li>Représentation du réel ou de l''imaginaire</li>
</ul>

<h3>3. Grands romanciers français</h3>
<ul>
  <li><strong>Honoré de Balzac</strong> - La Comédie Humaine</li>
  <li><strong>Gustave Flaubert</strong> - Madame Bovary</li>
  <li><strong>Émile Zola</strong> - Les Rougon-Macquart</li>
  <li><strong>Marcel Proust</strong> - À la Recherche du Temps Perdu</li>
  <li><strong>Albert Camus</strong> - L''Étranger, La Peste</li>
</ul>', 'text', 1, 1),

(6, 23, 'Introduction aux Suites Numériques',
'<h2>Suites Numériques</h2>
<p>Une <strong>suite numérique</strong> est une liste ordonnée de nombres appelés <em>termes</em>.</p>

<h3>1. Définition</h3>
<p>On note une suite : (u<sub>n</sub>)<sub>n∈ℕ</sub> ou u<sub>0</sub>, u<sub>1</sub>, u<sub>2</sub>, ...</p>

<h3>2. Suite Arithmétique</h3>
<div style="background:#f0f9ff;padding:1rem;border-radius:0.5rem;margin:1rem 0">
  <p><strong>Définition :</strong> u<sub>n+1</sub> = u<sub>n</sub> + r (r = raison)</p>
  <p><strong>Terme général :</strong> u<sub>n</sub> = u<sub>0</sub> + n×r</p>
  <p><strong>Somme :</strong> S = n × (u<sub>0</sub> + u<sub>n-1</sub>) / 2</p>
</div>

<h3>3. Suite Géométrique</h3>
<div style="background:#f0fdf4;padding:1rem;border-radius:0.5rem;margin:1rem 0">
  <p><strong>Définition :</strong> u<sub>n+1</sub> = u<sub>n</sub> × q (q = raison)</p>
  <p><strong>Terme général :</strong> u<sub>n</sub> = u<sub>0</sub> × q<sup>n</sup></p>
  <p><strong>Somme :</strong> S = u<sub>0</sub> × (1 - q<sup>n</sup>) / (1 - q) si q ≠ 1</p>
</div>

<h3>4. Exemple résolu</h3>
<p><strong>Exercice :</strong> Soit la suite (u<sub>n</sub>) définie par u<sub>0</sub> = 3 et u<sub>n+1</sub> = u<sub>n</sub> + 5</p>
<p><strong>Solution :</strong> C''est une suite arithmétique de raison r = 5</p>
<p>u<sub>n</sub> = 3 + 5n → u<sub>10</sub> = 3 + 50 = <strong>53</strong></p>', 'text', 1, 1),

(7, 27, 'Advanced English Grammar',
'<h2>Advanced Grammar - Terminale Level</h2>

<h3>1. Complex Tenses</h3>
<table class="table">
  <tr><th>Tense</th><th>Structure</th><th>Example</th></tr>
  <tr><td>Present Perfect</td><td>have/has + V3</td><td>I have studied for the exam</td></tr>
  <tr><td>Past Perfect</td><td>had + V3</td><td>She had left before I arrived</td></tr>
  <tr><td>Future Perfect</td><td>will have + V3</td><td>By 2030, they will have built it</td></tr>
</table>

<h3>2. Conditional Sentences</h3>
<ul>
  <li><strong>Type 1 (Real):</strong> If + present → will + V<br><em>If I study hard, I will pass the exam</em></li>
  <li><strong>Type 2 (Unreal):</strong> If + past → would + V<br><em>If I had money, I would travel</em></li>
  <li><strong>Type 3 (Past):</strong> If + past perfect → would have + V3<br><em>If I had studied, I would have passed</em></li>
</ul>

<h3>3. Passive Voice</h3>
<p><strong>Active:</strong> The teacher corrects the homework</p>
<p><strong>Passive:</strong> The homework <em>is corrected</em> by the teacher</p>', 'text', 1, 1),

(8, 30, 'La Génétique Mendelienne',
'<h2>Les Lois de Mendel</h2>
<p>Gregor Mendel (1822-1884), moine augustin, a découvert les lois de l''hérédité en expérimentant sur des pois.</p>

<h3>1. Première Loi - Loi de Pureté des Gamètes</h3>
<p>Chaque individu possède 2 allèles pour chaque caractère. Lors de la formation des gamètes, les 2 allèles se séparent → chaque gamète ne reçoit qu''1 allèle.</p>

<h3>2. Deuxième Loi - Loi de Ségrégation Indépendante</h3>
<p>Lors de la méiose, les allèles de gènes situés sur des chromosomes différents se séparent indépendamment.</p>

<h3>3. Croisements</h3>
<div style="background:#f0fdf4;padding:1rem;border-radius:0.5rem">
  <p><strong>Parents :</strong> AA (Vert) × aa (Jaune)</p>
  <p><strong>F1 :</strong> Aa (tous Verts → dominance)</p>
  <p><strong>F2 (F1×F1) :</strong> 1 AA : 2 Aa : 1 aa = 3 Vert : 1 Jaune</p>
</div>

<h3>4. Vocabulaire clé</h3>
<ul>
  <li><strong>Allèle :</strong> forme alternative d''un gène</li>
  <li><strong>Dominant/Récessif :</strong> relation entre allèles</li>
  <li><strong>Phénotype :</strong> caractère observable</li>
  <li><strong>Génotype :</strong> constitution génétique</li>
</ul>', 'text', 1, 1);

-- ================================================
-- Quiz initiaux
-- ================================================
INSERT OR IGNORE INTO quizzes (id, subject_id, chapter_id, title, description, duration_minutes, passing_score, is_free, difficulty) VALUES
(1, 1, 1, 'Quiz - Introduction à la Philosophie', 'Testez vos connaissances sur les bases de la philosophie', 20, 60, 1, 'easy'),
(2, 1, 2, 'Quiz - Conscience et Inconscient', 'Questions sur la conscience selon les philosophes', 25, 60, 0, 'medium'),
(3, 2, 7, 'Quiz - 1ère et 2ème Guerres Mondiales', 'Évaluez vos connaissances historiques', 30, 60, 1, 'medium'),
(4, 13, 13, 'Quiz - Fondements de l''Économie', 'Concepts de base de l''économie', 20, 60, 1, 'easy'),
(5, 7, 18, 'Quiz - Roman Français', 'Le roman et ses grands auteurs', 20, 60, 1, 'easy'),
(6, 4, 23, 'Quiz - Suites Numériques', 'Calculs et propriétés des suites', 30, 70, 0, 'medium'),
(7, 9, 27, 'Quiz - Advanced Grammar', 'Test your English grammar skills', 25, 65, 1, 'medium'),
(8, 6, 30, 'Quiz - Génétique', 'Les lois de Mendel et la génétique', 30, 65, 0, 'medium'),
(9, 1, NULL, 'Quiz BAC Blanc - Philosophie', 'Entraînement au BAC complet en Philosophie', 60, 70, 0, 'hard'),
(10, 2, NULL, 'Quiz BAC Blanc - Histoire-Géo', 'Questions sur toutes les périodes étudiées', 45, 65, 0, 'hard'),
(11, 13, NULL, 'Évaluation Économie Terminale A2', 'Tous les concepts économiques de Terminale', 50, 65, 0, 'hard');

-- ================================================
-- Questions de Quiz
-- ================================================

-- Quiz 1: Introduction Philosophie
INSERT OR IGNORE INTO questions (id, quiz_id, question_text, question_type, options, correct_answer, explanation, points, order_index) VALUES
(1, 1, 'Que signifie le mot "Philosophie" en grec ancien?',
'mcq',
'["Amour de la science","Amour de la sagesse","Connaissance de Dieu","Science de la nature"]',
'Amour de la sagesse',
'Philosophia vient de "philein" (aimer) et "sophia" (sagesse)',
2, 1),

(2, 1, 'Qui est considéré comme le "père de la philosophie occidentale"?',
'mcq',
'["Platon","Aristote","Socrate","Pythagore"]',
'Socrate',
'Socrate (470-399 av. J.C) est généralement considéré comme le fondateur de la philosophie morale et politique occidentale',
2, 2),

(3, 1, 'La maïeutique est une méthode philosophique de:',
'mcq',
'["Démonstration mathématique","Accouchement des esprits par le questionnement","Observation de la nature","Critique religieuse"]',
'Accouchement des esprits par le questionnement',
'La maïeutique de Socrate (art d''accoucher les esprits) consiste à aider l''interlocuteur à trouver la vérité par le dialogue',
2, 3),

(4, 1, 'Descartes est l''auteur de la célèbre formule:',
'mcq',
'["Je pense, donc je suis","L''homme est un animal raisonnable","La connaissance c''est le pouvoir","Connais-toi toi-même"]',
'Je pense, donc je suis',
'Le cogito cartésien : "Cogito ergo sum" est le point de départ de la philosophie de Descartes',
2, 4),

(5, 1, 'L''épistémologie est l''étude de:',
'mcq',
'["La beauté","La connaissance","La morale","La politique"]',
'La connaissance',
'L''épistémologie (du grec episteme = connaissance) est la branche de la philosophie qui étudie la nature et les limites de la connaissance',
1, 5),

(6, 1, 'La philosophie est une science exacte comme les mathématiques.',
'true_false',
'["Vrai","Faux"]',
'Faux',
'La philosophie n''est pas une science exacte. Elle pose des questions auxquelles on ne peut pas toujours répondre de façon définitive',
1, 6),

-- Quiz 3: Histoire
(7, 3, 'En quelle année a débuté la Première Guerre Mondiale?',
'mcq',
'["1912","1914","1916","1918"]',
'1914',
'La 1ère Guerre Mondiale a commencé le 28 juillet 1914 après l''assassinat de l''archiduc François-Ferdinand',
2, 1),

(8, 3, 'Quel événement a déclenché la Première Guerre Mondiale?',
'mcq',
'["L''invasion de la Belgique","L''assassinat de l''archiduc François-Ferdinand","La mobilisation de la Russie","La déclaration de guerre de l''Allemagne"]',
'L''assassinat de l''archiduc François-Ferdinand',
'L''assassinat à Sarajevo le 28 juin 1914 a été l''étincelle qui a déclenché la guerre mondiale',
2, 2),

(9, 3, 'Quel traité a mis fin à la Première Guerre Mondiale?',
'mcq',
'["Traité de Paris","Traité de Versailles","Traité de Berlin","Traité de Londres"]',
'Traité de Versailles',
'Le Traité de Versailles a été signé le 28 juin 1919, exactement 5 ans après l''attentat de Sarajevo',
2, 3),

(10, 3, 'La Seconde Guerre Mondiale a commencé en:',
'mcq',
'["1935","1937","1939","1941"]',
'1939',
'La 2ème Guerre Mondiale a commencé le 1er septembre 1939 avec l''invasion de la Pologne par l''Allemagne nazie',
2, 4),

-- Quiz 4: Économie
(11, 4, 'Qu''est-ce que le PIB?',
'mcq',
'["Produit Interne Brut","Prix Indicateur Brut","Production Industrielle de Base","Programme Industriel de Budget"]',
'Produit Interne Brut',
'Le PIB (Produit Intérieur Brut) mesure la valeur totale de tous les biens et services produits dans un pays en une année',
2, 1),

(12, 4, 'La loi de l''offre et de la demande stipule que:',
'mcq',
'["Si le prix augmente, la demande augmente","Si le prix augmente, l''offre augmente","Le prix est toujours fixé par l''État","L''offre est toujours supérieure à la demande"]',
'Si le prix augmente, l''offre augmente',
'Selon la loi de l''offre, quand le prix d''un bien augmente, les producteurs sont incités à en produire davantage',
2, 2),

(13, 4, 'Le chômage est mesuré par:',
'mcq',
'["Le taux d''emploi","Le taux de chômage","Le taux d''activité","Le taux de croissance"]',
'Le taux de chômage',
'Le taux de chômage est le rapport entre le nombre de chômeurs et la population active',
1, 3),

-- Quiz 5: Roman
(14, 5, 'Gustave Flaubert est l''auteur de:',
'mcq',
'["Les Misérables","Madame Bovary","Germinal","À la Recherche du Temps Perdu"]',
'Madame Bovary',
'Madame Bovary (1857) est le chef-d''œuvre de Flaubert, roman réaliste sur les illusions romantiques',
2, 1),

(15, 5, 'Le mouvement littéraire du XIXème siècle qui cherche à représenter la réalité objective est:',
'mcq',
'["Le Romantisme","Le Symbolisme","Le Réalisme","Le Surréalisme"]',
'Le Réalisme',
'Le Réalisme au XIXème siècle (Balzac, Flaubert, Stendhal) cherche à représenter fidèlement la réalité sociale',
2, 2),

(16, 5, 'Victor Hugo a écrit "Les Misérables".',
'true_false',
'["Vrai","Faux"]',
'Vrai',
'Les Misérables (1862) est le grand roman social de Victor Hugo, auteur romantique majeur',
1, 3),

-- Quiz 6: Maths
(17, 6, 'Dans une suite arithmétique de raison r=3 et de premier terme u0=1, quel est u5?',
'mcq',
'["13","14","15","16"]',
'16',
'u5 = u0 + 5×r = 1 + 5×3 = 1 + 15 = 16',
3, 1),

(18, 6, 'Une suite géométrique de raison q et de premier terme u0 a comme terme général:',
'mcq',
'["un = u0 + n×q","un = u0 × n×q","un = u0 × q^n","un = u0 + q^n"]',
'un = u0 × q^n',
'La formule du terme général d''une suite géométrique est un = u0 × q^n',
2, 2),

(19, 6, 'La somme des termes d''une suite arithmétique u0 + u1 + ... + u(n-1) est:',
'mcq',
'["n × (u0 + u(n-1))","n × (u0 + u(n-1)) / 2","(u0 + u(n-1)) / 2","n² × r"]',
'n × (u0 + u(n-1)) / 2',
'La somme de n termes d''une suite arithmétique = n × (premier terme + dernier terme) / 2',
3, 3),

-- Quiz 7: English
(20, 7, 'Complete: "If I ___ harder, I would pass the exam" (Type 2 conditional)',
'mcq',
'["study","studied","will study","had studied"]',
'studied',
'Type 2 conditional (unreal present/future): If + past simple → would + infinitive',
2, 1),

(21, 7, '"She has been studying for 3 hours." This sentence is in:',
'mcq',
'["Present Perfect","Present Continuous","Present Perfect Continuous","Past Perfect"]',
'Present Perfect Continuous',
'Present Perfect Continuous = have/has + been + V-ing. Expresses an action that started in the past and is still ongoing',
2, 2),

(22, 7, 'Transform to passive: "The teacher corrects the homework."',
'mcq',
'["The homework corrects by the teacher","The homework is corrected by the teacher","The homework was corrected by the teacher","The teacher is corrected the homework"]',
'The homework is corrected by the teacher',
'Passive voice (présent simple) = subject + is/are + V3 (past participle) + by + agent',
2, 3),

-- Quiz 8: SVT/Génétique  
(23, 8, 'Qui a découvert les lois de l''hérédité?',
'mcq',
'["Charles Darwin","Gregor Mendel","Louis Pasteur","James Watson"]',
'Gregor Mendel',
'Gregor Mendel (1822-1884), moine augustin autrichien, a établi les lois de l''hérédité en expérimentant sur des pois',
2, 1),

(24, 8, 'Qu''est-ce qu''un allèle?',
'mcq',
'["Un chromosome complet","Une forme alternative d''un gène","Une protéine","Un ARN messager"]',
'Une forme alternative d''un gène',
'Un allèle est une des formes alternatives que peut prendre un gène sur un locus donné',
2, 2),

(25, 8, 'Dans un croisement Aa × Aa, quelle est la proportion de phénotype récessif en F2?',
'mcq',
'["1/4","1/2","3/4","1"]',
'1/4',
'Le croisement Aa × Aa donne 1 AA : 2 Aa : 1 aa. Le phénotype récessif (aa) représente 1/4 des individus',
3, 3);

-- ================================================
-- Examens du BAC
-- ================================================
INSERT OR IGNORE INTO exams (id, subject_id, title, description, exam_type, year, duration_minutes, is_free, is_published) VALUES
(1, 1, 'BAC 2023 - Philosophie Série A', 'Épreuve officielle du Baccalauréat 2023 en Philosophie', 'bac', 2023, 240, 1, 1),
(2, 1, 'BAC 2022 - Philosophie Série A', 'Épreuve officielle du Baccalauréat 2022', 'bac', 2022, 240, 0, 1),
(3, 2, 'BAC 2023 - Histoire-Géographie Série A', 'Épreuve officielle du BAC 2023', 'bac', 2023, 240, 1, 1),
(4, 13, 'BAC 2023 - Économie Terminale A2', 'Épreuve officielle BAC A2 Économie 2023', 'bac', 2023, 240, 1, 1),
(5, 7, 'BAC 2023 - Français Série A', 'Épreuve officielle du BAC 2023 en Français', 'bac', 2023, 240, 1, 1),
(6, 1, 'Devoir Surveillé N°1 - Philosophie', 'Premier devoir de l''année en Philosophie', 'practice', NULL, 120, 0, 1),
(7, 13, 'Contrôle Économie - Microéconomie', 'Évaluation sur la microéconomie', 'practice', NULL, 90, 0, 1),
(8, 4, 'BAC Blanc - Mathématiques', 'Simulation du BAC en Mathématiques', 'practice', NULL, 180, 0, 1);

-- ================================================
-- Annonces initiales
-- ================================================
INSERT OR IGNORE INTO users (id, email, password_hash, full_name, role, is_active) VALUES
-- NOTE: Le compte admin principal est créé automatiquement au démarrage
-- via UserModel.ensureAdminExists() avec l'email ainasolofitiavana123@gmail.com
-- Ce compte seed est conservé comme backup uniquement
(1, 'ainasolofitiavana123@gmail.com', 'placeholder_will_be_overwritten', 'Administrateur Principal', 'admin', 1),
(2, 'prof.philo@terminale-mg.mg', 'placeholder_teacher', 'Prof. Razafindrakoto', 'teacher', 1);

INSERT OR IGNORE INTO announcements (id, title, content, author_id, is_pinned, target_audience) VALUES
(1, '🎉 Bienvenue sur Terminale Madagascar!', 
'Bienvenue sur votre plateforme de cours en ligne pour la Terminale A1 et A2. Commencez par explorer nos cours et testez vos connaissances avec nos quiz interactifs!', 
1, 1, 'all'),
(2, '📚 Nouveaux cours disponibles - Philosophie',
'Les cours de Philosophie pour le Chapitre 2 (Conscience et Inconscient) sont maintenant disponibles. Accédez-y avec votre abonnement.',
2, 0, 'all'),
(3, '🎯 Préparation au BAC 2024',
'Commencez dès maintenant votre préparation au BAC. Des quiz spéciaux BAC Blanc sont disponibles dans toutes les matières.',
1, 1, 'subscribers');
