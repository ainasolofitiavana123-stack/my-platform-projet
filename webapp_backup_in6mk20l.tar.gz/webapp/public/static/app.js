// ============================================
// Terminale Madagascar - Application Frontend
// Architecture MVC - Accès libre sans session requise
// ============================================

const API_BASE = '/api';
let currentUser = null;
let currentSubscription = null;

// JWT optionnel : si présent on l'utilise, sinon tout est accessible quand même
const TOKEN_KEY = 'terminale_mg_jwt';
const THEME_KEY = 'terminale_mg_theme';
let authToken = localStorage.getItem(TOKEN_KEY);

// ============ DARK MODE ============
let currentTheme = localStorage.getItem(THEME_KEY) || 'light';

function applyTheme(theme) {
  currentTheme = theme;
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem(THEME_KEY, theme);
  // Sync all toggles
  document.querySelectorAll('.theme-toggle').forEach(btn => {
    btn.classList.toggle('dark', theme === 'dark');
    btn.setAttribute('aria-label', theme === 'dark' ? 'Mode clair' : 'Mode sombre');
  });
  document.querySelectorAll('.theme-icon').forEach(icon => {
    icon.className = `theme-icon fas ${theme === 'dark' ? 'fa-sun' : 'fa-moon'} text-sm`;
  });
}

function toggleTheme() {
  applyTheme(currentTheme === 'dark' ? 'light' : 'dark');
}

// Apply theme immediately on load
applyTheme(currentTheme);

function isTokenExpired(token) {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return true;
    const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
    return payload.exp < Math.floor(Date.now() / 1000);
  } catch { return true; }
}

if (authToken && isTokenExpired(authToken)) {
  localStorage.removeItem(TOKEN_KEY);
  authToken = null;
}

// ============ UTILITIES ============
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  const icons = { success: 'check-circle', error: 'times-circle', warning: 'exclamation-triangle', info: 'info-circle' };
  toast.innerHTML = `<i class="fas fa-${icons[type] || 'info-circle'} mr-2"></i>${message}`;
  container.appendChild(toast);
  setTimeout(() => { toast.style.opacity = '0'; toast.style.transition = 'opacity 0.3s'; setTimeout(() => toast.remove(), 300); }, 3500);
}

function showModal(html, wide = false) {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `<div class="modal-box ${wide ? 'w-full max-w-2xl' : ''}">${html}</div>`;
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
  return overlay;
}

function closeModal() { document.querySelector('.modal-overlay')?.remove(); }

async function apiCall(method, endpoint, data = null) {
  const headers = { 'Content-Type': 'application/json' };
  if (authToken && !isTokenExpired(authToken)) {
    headers['Authorization'] = `Bearer ${authToken}`;
  } else if (authToken) {
    localStorage.removeItem(TOKEN_KEY);
    authToken = null;
    currentUser = null;
    currentSubscription = null;
  }
  const opts = { method, headers };
  if (data) opts.body = JSON.stringify(data);
  try {
    const res = await fetch(`${API_BASE}${endpoint}`, opts);
    const json = await res.json();
    if (res.status === 401) {
      localStorage.removeItem(TOKEN_KEY);
      authToken = null;
      currentUser = null;
    }
    return { ok: res.ok, status: res.status, data: json };
  } catch (e) {
    return { ok: false, status: 0, data: { error: 'Erreur réseau' } };
  }
}

function formatDate(dateStr) {
  if (!dateStr) return 'N/A';
  return new Date(dateStr).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
}

function formatAriary(amount) {
  return new Intl.NumberFormat('fr-MG').format(amount) + ' Ar';
}

function getInitials(name) {
  if (!name) return '?';
  return name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase();
}

function getDifficultyBadge(d) {
  const map = { easy: ['Facile', 'badge-easy'], medium: ['Moyen', 'badge-medium'], hard: ['Difficile', 'badge-hard'] };
  const [label, cls] = map[d] || ['Moyen', 'badge-medium'];
  return `<span class="badge ${cls}">${label}</span>`;
}

// ============ AUTH (optionnel) ============
async function checkAuth() {
  if (!authToken || isTokenExpired(authToken)) {
    authToken = null;
    localStorage.removeItem(TOKEN_KEY);
    return false;
  }
  const res = await apiCall('GET', '/auth/me');
  if (res.ok) {
    currentUser = res.data.user;
    currentSubscription = res.data.subscription;
    return true;
  }
  authToken = null;
  localStorage.removeItem(TOKEN_KEY);
  return false;
}

async function login(email, password) {
  const res = await apiCall('POST', '/auth/login', { email, password });
  if (res.ok) {
    authToken = res.data.token;
    currentUser = res.data.user;
    currentSubscription = res.data.subscription;
    localStorage.setItem(TOKEN_KEY, authToken);
    return true;
  }
  showToast(res.data.error || 'Erreur de connexion', 'error');
  return false;
}

async function register(data) {
  const res = await apiCall('POST', '/auth/register', data);
  if (res.ok) {
    authToken = res.data.token;
    currentUser = res.data.user;
    localStorage.setItem(TOKEN_KEY, authToken);
    return true;
  }
  showToast(res.data.error || "Erreur d'inscription", 'error');
  return false;
}

async function logout() {
  await apiCall('POST', '/auth/logout');
  authToken = null;
  currentUser = null;
  currentSubscription = null;
  localStorage.removeItem(TOKEN_KEY);
  navigateTo('home');
  showToast('Déconnecté avec succès', 'success');
}

// ============ ROUTER ============
const routes = {
  'home': renderHome,
  'subjects': renderSubjects,
  'subject': renderSubjectDetail,
  'lesson': renderLesson,
  'quiz': renderQuiz,
  'quiz-result': renderQuizResult,
  'exams': renderExams,
  'subscription': renderSubscription,
  'dashboard': renderDashboard,
  'login': renderLogin,
  'register': renderRegister,
  'admin': renderAdmin,
  'profile': renderProfile,
};

let currentRoute = 'home';
let routeParams = {};

function navigateTo(route, params = {}) {
  currentRoute = route;
  routeParams = params;
  window.history.pushState({ route, params }, '', `#${route}`);
  renderApp();
}

window.addEventListener('popstate', (e) => {
  if (e.state) { currentRoute = e.state.route; routeParams = e.state.params || {}; renderApp(); }
});

// ============ MAIN RENDER ============
function renderApp() {
  // Si non connecté et sur la page home et pas encore entré dans l'app → afficher landing
  if (!currentUser && currentRoute === 'home' && !sessionStorage.getItem('entered_app')) {
    renderLandingPage();
    return;
  }

  const app = document.getElementById('app');
  app.innerHTML = renderLayout();
  const handler = routes[currentRoute] || renderHome;
  const content = document.getElementById('main-content');
  if (content) content.innerHTML = '<div class="flex items-center justify-center min-h-64"><div class="animate-spin rounded-full h-12 w-12 border-t-4 border-indigo-600"></div></div>';
  handler();
}

function renderLayout() {
  const isLoggedIn = !!currentUser;
  const isDark = currentTheme === 'dark';

  return `
    <header class="app-header sticky top-0 z-40">
      <div class="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <button onclick="toggleSidebar()" class="md:hidden text-gray-600 mr-3">
          <i class="fas fa-bars text-xl"></i>
        </button>
        <div class="flex items-center gap-2 cursor-pointer" onclick="navigateTo('home')">
          <span class="text-2xl">📚</span>
          <div>
            <h1 class="font-bold text-indigo-700 text-sm leading-tight">Terminale Madagascar</h1>
            <p class="text-xs" style="color:var(--text-muted)">Série A1 & A2</p>
          </div>
        </div>
        <div class="flex items-center gap-3">
          <!-- Toggle thème clair/sombre -->
          <button onclick="toggleTheme()" class="theme-toggle ${isDark ? 'dark' : ''}" aria-label="${isDark ? 'Mode clair' : 'Mode sombre'}" title="${isDark ? 'Passer en mode clair' : 'Passer en mode sombre'}">
          </button>
          <i class="theme-icon fas ${isDark ? 'fa-sun' : 'fa-moon'} text-sm" style="color:var(--text-secondary);pointer-events:none;margin-left:-8px"></i>

          ${isLoggedIn ? `
            <button onclick="navigateTo('dashboard')" class="relative p-2 hover:text-indigo-600" style="color:var(--text-secondary)" title="Notifications">
              <i class="fas fa-bell text-lg"></i>
            </button>
            <!-- Avatar profil avec dropdown -->
            <div class="relative" id="profile-dropdown-wrapper">
              <button onclick="toggleProfileDropdown()" class="flex items-center gap-2 cursor-pointer hover:opacity-80 transition">
                <div class="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white text-xs font-bold border-2 border-indigo-300 overflow-hidden">
                  ${currentUser.avatar ? `<img src="${currentUser.avatar}" alt="" class="w-full h-full object-cover">` : getInitials(currentUser.full_name)}
                </div>
                <span class="hidden md:block text-sm font-medium max-w-24 truncate" style="color:var(--text-primary)">${currentUser.full_name.split(' ')[0]}</span>
                <i class="fas fa-chevron-down text-xs hidden md:block" style="color:var(--text-muted)"></i>
              </button>
              <!-- Dropdown menu -->
              <div id="profile-dropdown" class="hidden absolute right-0 top-12 w-52 rounded-2xl shadow-xl border overflow-hidden z-50" style="background:var(--bg-card);border-color:var(--border)">
                <div class="p-3 border-b" style="border-color:var(--border)">
                  <p class="font-semibold text-sm" style="color:var(--text-primary)">${currentUser.full_name}</p>
                  <p class="text-xs" style="color:var(--text-muted)">${currentUser.email}</p>
                  <span class="profile-badge mt-1 ${currentUser.role === 'admin' ? 'badge-admin' : currentUser.role === 'teacher' ? 'badge-teacher' : 'badge-student'}">
                    ${currentUser.role === 'admin' ? '🛡️ Admin' : currentUser.role === 'teacher' ? '👨‍🏫 Prof' : '🎓 Étudiant'}
                  </span>
                </div>
                <div class="py-1">
                  <button onclick="closeProfileDropdown(); navigateTo('profile')" class="w-full flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-indigo-50 transition text-left" style="color:var(--text-primary)">
                    <i class="fas fa-user-circle w-4 text-indigo-500"></i> Mon Profil
                  </button>
                  <button onclick="closeProfileDropdown(); navigateTo('dashboard')" class="w-full flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-indigo-50 transition text-left" style="color:var(--text-primary)">
                    <i class="fas fa-tachometer-alt w-4 text-blue-500"></i> Tableau de bord
                  </button>
                  ${currentUser.role === 'admin' || currentUser.role === 'teacher' ? `
                  <button onclick="closeProfileDropdown(); navigateTo('admin')" class="w-full flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-red-50 transition text-left" style="color:var(--text-primary)">
                    <i class="fas fa-cog w-4 text-red-500"></i> Administration
                  </button>
                  ` : ''}
                  <div class="border-t my-1" style="border-color:var(--border)"></div>
                  <button onclick="closeProfileDropdown(); logout()" class="w-full flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-red-50 text-red-500 transition text-left">
                    <i class="fas fa-sign-out-alt w-4"></i> Déconnexion
                  </button>
                </div>
              </div>
            </div>
          ` : `
            <button onclick="navigateTo('login')" class="text-sm font-medium hover:text-indigo-600 transition" style="color:var(--text-secondary)">Connexion</button>
            <button onclick="navigateTo('register')" class="bg-indigo-600 text-white text-sm px-3 py-1.5 rounded-lg hover:bg-indigo-700 transition">S'inscrire</button>
          `}
        </div>
      </div>
    </header>

    <div class="flex min-h-screen">
      <aside id="sidebar" class="app-sidebar sidebar fixed md:sticky top-0 md:top-16 left-0 h-screen md:h-auto w-64 shadow-lg z-30 overflow-y-auto flex-shrink-0 pt-4 md:pt-0">
        <div class="p-4">
          ${isLoggedIn ? `
            <div class="md:hidden flex items-center gap-3 p-3 rounded-xl mb-4" style="background:var(--primary-light)">
              <div class="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold overflow-hidden">
                ${currentUser.avatar ? `<img src="${currentUser.avatar}" alt="" class="w-full h-full object-cover">` : getInitials(currentUser.full_name)}
              </div>
              <div>
                <p class="font-semibold text-sm" style="color:var(--text-primary)">${currentUser.full_name}</p>
                <p class="text-xs text-indigo-600">Connecté ✓</p>
              </div>
            </div>
          ` : `
            <div class="md:hidden mb-4 p-3 bg-green-50 border border-green-200 rounded-xl text-center">
              <p class="text-xs text-green-700 font-semibold">✅ Accès libre</p>
              <p class="text-xs text-green-600 mt-1">Tout le contenu est disponible !</p>
            </div>
          `}

          <div class="mb-4">
            <p class="text-xs font-semibold uppercase tracking-wide mb-2" style="color:var(--text-muted)">Classe</p>
            <div class="flex gap-2">
              <button id="btn-a1" onclick="setClassLevel('terminale_a1')" class="flex-1 py-1.5 text-xs rounded-lg border-2 border-indigo-600 bg-indigo-600 text-white font-semibold">Tle A1</button>
              <button id="btn-a2" onclick="setClassLevel('terminale_a2')" class="flex-1 py-1.5 text-xs rounded-lg border-2 font-semibold hover:border-indigo-400 transition" style="border-color:var(--border);color:var(--text-secondary)">Tle A2</button>
            </div>
          </div>

          <nav>
            <p class="text-xs font-semibold uppercase tracking-wide mb-2 mt-4" style="color:var(--text-muted)">Menu</p>
            <ul class="space-y-1">
              <li><a onclick="navigateTo('home')" class="nav-link flex items-center gap-3 text-sm font-medium cursor-pointer ${currentRoute === 'home' ? 'active' : ''}"><i class="fas fa-home w-5"></i>Accueil</a></li>
              <li><a onclick="navigateTo('subjects')" class="nav-link flex items-center gap-3 text-sm font-medium cursor-pointer ${currentRoute === 'subjects' ? 'active' : ''}"><i class="fas fa-book w-5"></i>Matières & Cours</a></li>
              <li><a onclick="navigateTo('quiz', {filter: 'all'})" class="nav-link flex items-center gap-3 text-sm font-medium cursor-pointer ${currentRoute === 'quiz' ? 'active' : ''}"><i class="fas fa-question-circle w-5"></i>Quiz</a></li>
              <li><a onclick="navigateTo('exams')" class="nav-link flex items-center gap-3 text-sm font-medium cursor-pointer ${currentRoute === 'exams' ? 'active' : ''}"><i class="fas fa-file-alt w-5"></i>Examens BAC</a></li>
              <li><a onclick="navigateTo('subscription')" class="nav-link flex items-center gap-3 text-sm font-medium cursor-pointer ${currentRoute === 'subscription' ? 'active' : ''}"><i class="fas fa-crown w-5 text-yellow-500"></i>Soutenir le projet</a></li>
              ${isLoggedIn ? `
                <li><a onclick="navigateTo('dashboard')" class="nav-link flex items-center gap-3 text-sm font-medium cursor-pointer ${currentRoute === 'dashboard' ? 'active' : ''}"><i class="fas fa-tachometer-alt w-5"></i>Tableau de Bord</a></li>
                <li><a onclick="navigateTo('profile')" class="nav-link flex items-center gap-3 text-sm font-medium cursor-pointer ${currentRoute === 'profile' ? 'active' : ''}"><i class="fas fa-user-circle w-5"></i>Mon Profil</a></li>
              ` : ''}
              ${currentUser?.role === 'admin' || currentUser?.role === 'teacher' ? `<li><a onclick="navigateTo('admin')" class="nav-link flex items-center gap-3 text-sm font-medium cursor-pointer ${currentRoute === 'admin' ? 'active' : ''}"><i class="fas fa-cog w-5 text-red-500"></i>Administration</a></li>` : ''}
            </ul>
          </nav>

          <!-- Toggle thème dans la sidebar -->
          <div class="mt-4 flex items-center justify-between p-3 rounded-xl" style="background:var(--bg);border:1px solid var(--border)">
            <div class="flex items-center gap-2">
              <i class="fas ${currentTheme === 'dark' ? 'fa-moon text-indigo-400' : 'fa-sun text-yellow-500'} text-sm"></i>
              <span class="text-xs font-semibold" style="color:var(--text-secondary)">${currentTheme === 'dark' ? 'Mode sombre' : 'Mode clair'}</span>
            </div>
            <button onclick="toggleTheme()" class="theme-toggle ${currentTheme === 'dark' ? 'dark' : ''}"></button>
          </div>

          <!-- Bannière accès libre -->
          <div class="mt-4 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl p-4 text-white">
            <div class="text-xl mb-1">🎓</div>
            <p class="font-bold text-sm">Accès 100% Gratuit</p>
            <p class="text-xs text-green-100 mt-1">Tous les cours, quiz et examens accessibles librement !</p>
            ${!isLoggedIn ? `
              <button onclick="navigateTo('register')" class="mt-3 w-full bg-white text-green-700 text-xs font-bold py-1.5 rounded-lg hover:bg-green-50 transition">
                S'inscrire pour suivre sa progression
              </button>
            ` : ''}
          </div>

          ${isLoggedIn ? `
            <button onclick="logout()" class="mt-4 w-full flex items-center gap-2 text-sm hover:text-red-500 p-2 rounded-lg hover:bg-red-50 transition" style="color:var(--text-muted)">
              <i class="fas fa-sign-out-alt"></i> Déconnexion
            </button>
          ` : ''}
        </div>
      </aside>

      <div id="sidebar-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-20 hidden md:hidden" onclick="toggleSidebar()"></div>

      <main class="flex-1 p-4 md:p-6 min-w-0" id="main-content">
        <div class="flex items-center justify-center min-h-64">
          <div class="animate-spin rounded-full h-12 w-12 border-t-4 border-indigo-600"></div>
        </div>
      </main>
    </div>

    <div id="toast-container" class="fixed bottom-4 right-4 z-50 flex flex-col gap-2"></div>
  `;
}
let currentClassLevel = 'terminale_a1';
function setClassLevel(level) {
  currentClassLevel = level;
  const a1Active = level === 'terminale_a1';
  document.getElementById('btn-a1')?.classList.toggle('bg-indigo-600', a1Active);
  document.getElementById('btn-a1')?.classList.toggle('text-white', a1Active);
  document.getElementById('btn-a1')?.classList.toggle('border-indigo-600', a1Active);
  document.getElementById('btn-a2')?.classList.toggle('bg-indigo-600', !a1Active);
  document.getElementById('btn-a2')?.classList.toggle('text-white', !a1Active);
  document.getElementById('btn-a2')?.classList.toggle('border-indigo-600', !a1Active);
  if (currentRoute === 'subjects') renderSubjects();
}

function toggleSidebar() {
  document.getElementById('sidebar')?.classList.toggle('open');
  document.getElementById('sidebar-overlay')?.classList.toggle('hidden');
}

// ============ PROFILE DROPDOWN ============
function toggleProfileDropdown() {
  const dropdown = document.getElementById('profile-dropdown');
  if (!dropdown) return;
  dropdown.classList.toggle('hidden');
  // Close on outside click
  const handler = (e) => {
    const wrapper = document.getElementById('profile-dropdown-wrapper');
    if (wrapper && !wrapper.contains(e.target)) {
      dropdown.classList.add('hidden');
      document.removeEventListener('click', handler);
    }
  };
  if (!dropdown.classList.contains('hidden')) {
    setTimeout(() => document.addEventListener('click', handler), 50);
  }
}
function closeProfileDropdown() {
  document.getElementById('profile-dropdown')?.classList.add('hidden');
}

// ============ LANDING PAGE (visiteurs non connectés) ============
async function renderLandingPage() {
  const app = document.getElementById('app');

  const [announcementsRes, subjectsRes] = await Promise.all([
    apiCall('GET', '/public/announcements'),
    apiCall('GET', '/subjects?class_level=terminale_a1')
  ]);
  const announcements = announcementsRes.ok ? (announcementsRes.data.announcements || []).slice(0, 2) : [];
  const subjects = subjectsRes.ok ? (subjectsRes.data.subjects || []).slice(0, 6) : [];

  // Remplacer toute la page par la landing
  app.innerHTML = `
    <!-- Header landing -->
    <header class="app-header sticky top-0 z-40">
      <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div class="flex items-center gap-3">
          <span class="text-3xl">📚</span>
          <div>
            <h1 class="font-bold text-lg leading-tight" style="color:var(--primary)">Terminale Madagascar</h1>
            <p class="text-xs" style="color:var(--text-muted)">Série A1 & A2 · Réussis ton BAC !</p>
          </div>
        </div>
        <div class="flex items-center gap-3">
          <!-- Toggle thème -->
          <button onclick="toggleTheme()" class="theme-toggle ${currentTheme === 'dark' ? 'dark' : ''}" title="Changer de thème"></button>
          <i class="theme-icon fas ${currentTheme === 'dark' ? 'fa-sun' : 'fa-moon'} text-sm" style="color:var(--text-secondary);pointer-events:none;margin-left:-6px"></i>
          <button onclick="enterApp()" class="text-sm font-semibold hover:text-indigo-600 transition px-3 py-2 rounded-lg" style="color:var(--text-secondary)">Parcourir</button>
          <button onclick="navigateTo('login'); renderApp();" class="text-sm font-semibold hover:underline" style="color:var(--primary)">Connexion</button>
          <button onclick="navigateTo('register'); renderApp();" class="bg-indigo-600 text-white text-sm font-bold px-4 py-2 rounded-xl hover:bg-indigo-700 transition shadow-md">
            S'inscrire
          </button>
        </div>
      </div>
    </header>

    <!-- HERO SECTION -->
    <section class="landing-hero relative flex items-center justify-center overflow-hidden" style="min-height: 92vh;">
      <!-- Shapes flottantes -->
      <div class="floating-shape" style="width:400px;height:400px;top:-100px;right:-100px;animation-delay:0s"></div>
      <div class="floating-shape" style="width:250px;height:250px;bottom:50px;left:-80px;animation-delay:2s"></div>
      <div class="floating-shape" style="width:150px;height:150px;top:30%;right:15%;animation-delay:4s"></div>

      <div class="relative z-10 max-w-6xl mx-auto px-6 py-16 grid lg:grid-cols-2 gap-12 items-center">
        <!-- Texte hero -->
        <div class="text-white">
          <div class="inline-flex items-center gap-2 bg-white bg-opacity-20 rounded-full px-4 py-2 text-sm font-semibold mb-6">
            <span class="text-yellow-300">✨</span>
            <span>100% Gratuit · Aucune inscription requise</span>
          </div>
          <h1 class="text-4xl md:text-5xl lg:text-6xl font-black leading-tight mb-6">
            Réussis ton
            <span class="text-yellow-300">Baccalauréat</span>
            à Madagascar 🇲🇬
          </h1>
          <p class="text-indigo-100 text-lg md:text-xl mb-8 leading-relaxed">
            Cours complets, quiz interactifs et examens BAC officiels pour les élèves de <strong class="text-white">Terminale A1 & A2</strong>. Totalement gratuit, accessible partout.
          </p>
          <div class="flex flex-wrap gap-4 mb-8">
            <button onclick="enterApp()" class="group flex items-center gap-3 bg-white text-indigo-700 font-bold px-8 py-4 rounded-2xl hover:bg-indigo-50 transition shadow-lg text-lg">
              <i class="fas fa-play-circle text-indigo-500 group-hover:scale-110 transition"></i>
              Commencer maintenant
            </button>
            <button onclick="navigateTo('register'); renderApp();" class="flex items-center gap-3 border-2 border-white text-white font-bold px-8 py-4 rounded-2xl hover:bg-white hover:text-indigo-700 transition text-lg">
              <i class="fas fa-user-plus"></i>
              Créer un compte
            </button>
          </div>
          <!-- Stats rapides -->
          <div class="flex flex-wrap gap-6">
            ${[
              { icon: '📚', num: '16+', label: 'Matières' },
              { icon: '🎯', num: '11+', label: 'Quiz' },
              { icon: '📝', num: '8+', label: 'Examens BAC' },
              { icon: '🎓', num: '50+', label: 'Leçons' },
            ].map(s => `
              <div class="text-center">
                <p class="text-2xl font-black text-yellow-300">${s.num}</p>
                <p class="text-xs text-indigo-200">${s.icon} ${s.label}</p>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Illustration / Mockup -->
        <div class="hidden lg:block relative">
          <!-- Carte principale illustration -->
          <div class="relative">
            <!-- Mockup app -->
            <div class="rounded-3xl shadow-2xl overflow-hidden border-4 border-white border-opacity-30" style="background:rgba(255,255,255,0.12);backdrop-filter:blur(20px)">
              <div class="p-6">
                <!-- Header mock -->
                <div class="flex items-center gap-3 mb-5">
                  <div class="w-10 h-10 bg-yellow-400 rounded-full flex items-center justify-center text-lg">📚</div>
                  <div>
                    <p class="font-bold text-white text-sm">Terminale Madagascar</p>
                    <p class="text-xs text-indigo-200">Tableau de bord</p>
                  </div>
                </div>
                <!-- Stats mock -->
                <div class="grid grid-cols-2 gap-3 mb-4">
                  ${[
                    { icon: '📖', num: '24', label: 'Leçons vues', color: 'from-blue-400 to-blue-600' },
                    { icon: '🎯', num: '89%', label: 'Score moyen', color: 'from-green-400 to-green-600' },
                    { icon: '🏆', num: '7', label: 'Quiz réussis', color: 'from-yellow-400 to-orange-500' },
                    { icon: '🔥', num: '12j', label: 'Série active', color: 'from-red-400 to-pink-600' },
                  ].map(s => `
                    <div class="rounded-xl p-3 bg-gradient-to-br ${s.color}">
                      <div class="text-2xl mb-1">${s.icon}</div>
                      <p class="font-black text-white text-xl">${s.num}</p>
                      <p class="text-xs text-white text-opacity-80">${s.label}</p>
                    </div>
                  `).join('')}
                </div>
                <!-- Progress mock -->
                <div class="rounded-xl p-3 mb-3" style="background:rgba(255,255,255,0.1)">
                  <div class="flex justify-between text-xs text-white mb-2">
                    <span>📊 Philosophie - Chapitre 3</span>
                    <span class="font-bold">68%</span>
                  </div>
                  <div class="h-2 rounded-full" style="background:rgba(255,255,255,0.2)">
                    <div class="h-2 rounded-full bg-yellow-400" style="width:68%"></div>
                  </div>
                </div>
                <!-- Quiz card mock -->
                <div class="rounded-xl p-3" style="background:rgba(255,255,255,0.1)">
                  <p class="text-xs text-indigo-200 mb-2">🎯 Quiz du jour</p>
                  <p class="font-semibold text-white text-sm mb-3">Introduction à la Philosophie</p>
                  <div class="flex gap-2">
                    <div class="flex-1 py-1.5 rounded-lg text-center text-xs font-bold" style="background:rgba(255,255,255,0.15);color:white">A. Descartes</div>
                    <div class="flex-1 py-1.5 rounded-lg text-center text-xs font-bold bg-yellow-400 text-yellow-900">B. Kant ✓</div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Badge flottants -->
            <div class="absolute -top-4 -right-4 bg-yellow-400 text-yellow-900 font-black text-sm px-4 py-2 rounded-2xl shadow-lg animate-bounce">
              🎉 BAC 2025 !
            </div>
            <div class="absolute -bottom-4 -left-4 bg-green-400 text-green-900 font-black text-sm px-4 py-2 rounded-2xl shadow-lg">
              ✅ 100% Gratuit
            </div>
          </div>
        </div>
      </div>

      <!-- Scroll indicator -->
      <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white text-center animate-bounce">
        <i class="fas fa-chevron-down text-2xl opacity-70"></i>
      </div>
    </section>

    <!-- FEATURES SECTION -->
    <section class="py-20 px-6" style="background:var(--bg)">
      <div class="max-w-6xl mx-auto">
        <div class="text-center mb-14">
          <span class="text-sm font-bold uppercase tracking-widest" style="color:var(--primary)">Pourquoi nous choisir</span>
          <h2 class="text-3xl md:text-4xl font-black mt-2 mb-4" style="color:var(--text-heading)">
            Tout ce dont tu as besoin pour réussir
          </h2>
          <p class="text-lg max-w-2xl mx-auto" style="color:var(--text-secondary)">
            Une plateforme complète, gratuite et conçue spécialement pour les élèves malgaches de Terminale.
          </p>
        </div>

        <div class="grid md:grid-cols-3 gap-8">
          ${[
            { icon: '📖', emoji: '📖', title: 'Cours Complets', desc: 'Leçons structurées pour chaque matière de Terminale A1 et A2. Philosophie, Littérature, Histoire, Économie et plus encore.', color: 'bg-blue-100', iconColor: 'text-blue-600' },
            { icon: '🎯', emoji: '🎯', title: 'Quiz Interactifs', desc: 'Teste tes connaissances avec des quiz corrigés et expliqués. Suivi de progression et résultats détaillés.', color: 'bg-purple-100', iconColor: 'text-purple-600' },
            { icon: '📝', emoji: '📝', title: 'Examens BAC Officiels', desc: 'Accède aux sujets d\'examens BAC officiels et pratique dans les mêmes conditions que le vrai examen.', color: 'bg-red-100', iconColor: 'text-red-600' },
            { icon: '📊', emoji: '📊', title: 'Suivi de Progression', desc: 'Créez un compte gratuit pour suivre votre progression, vos scores et vos leçons complétées.', color: 'bg-green-100', iconColor: 'text-green-600' },
            { icon: '🌍', emoji: '🌍', title: 'Séries A1 & A2', desc: 'Contenu adapté pour Terminale A1 (Lettres & Sciences Humaines) et A2 (Sciences Sociales & Économie).', color: 'bg-yellow-100', iconColor: 'text-yellow-600' },
            { icon: '📱', emoji: '📱', title: 'Accessible Partout', desc: 'Fonctionne sur mobile, tablette et ordinateur. Étudie depuis n\'importe où, à n\'importe quel moment.', color: 'bg-orange-100', iconColor: 'text-orange-600' },
          ].map(f => `
            <div class="feature-card">
              <div class="feature-icon ${f.color}">
                <span class="${f.iconColor} text-3xl">${f.emoji}</span>
              </div>
              <h3 class="text-xl font-bold mb-3" style="color:var(--text-heading)">${f.title}</h3>
              <p style="color:var(--text-secondary)">${f.desc}</p>
            </div>
          `).join('')}
        </div>
      </div>
    </section>

    <!-- MATIÈRES PREVIEW -->
    <section class="py-20 px-6" style="background:var(--bg-card);border-top:1px solid var(--border);border-bottom:1px solid var(--border)">
      <div class="max-w-6xl mx-auto">
        <div class="flex items-center justify-between mb-10">
          <div>
            <span class="text-sm font-bold uppercase tracking-widest" style="color:var(--primary)">Au programme</span>
            <h2 class="text-3xl font-black mt-1" style="color:var(--text-heading)">Matières disponibles</h2>
          </div>
          <button onclick="enterApp()" class="hidden md:flex items-center gap-2 font-semibold hover:underline" style="color:var(--primary)">
            Voir toutes les matières <i class="fas fa-arrow-right"></i>
          </button>
        </div>

        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          ${subjects.length ? subjects.map(s => `
            <div class="subject-preview cursor-pointer" style="border-left-color:${s.color}" onclick="enterApp(); setTimeout(()=>navigateTo('subject',{id:${s.id}}), 100)">
              <div class="flex items-center gap-3">
                <span class="text-2xl">${s.icon}</span>
                <div class="flex-1 min-w-0">
                  <h3 class="font-bold text-sm truncate" style="color:var(--text-heading)">${s.name}</h3>
                  <p class="text-xs mt-0.5" style="color:var(--text-muted)">${s.lesson_count || 0} leçons · ${s.quiz_count || 0} quiz</p>
                </div>
                <i class="fas fa-arrow-right text-xs" style="color:var(--text-muted)"></i>
              </div>
            </div>
          `).join('') : [
            {icon:'📖',name:'Philosophie',sub:'A1 & A2'},
            {icon:'📜',name:'Littérature',sub:'A1'},
            {icon:'🌍',name:'Histoire-Géographie',sub:'A1 & A2'},
            {icon:'💰',name:'Économie',sub:'A2'},
            {icon:'👥',name:'Sciences Sociales',sub:'A2'},
            {icon:'🎭',name:'Arts & Culture',sub:'A1'},
          ].map(s => `
            <div class="subject-preview" style="border-left-color:#4F46E5">
              <div class="flex items-center gap-3">
                <span class="text-2xl">${s.icon}</span>
                <div>
                  <h3 class="font-bold text-sm" style="color:var(--text-heading)">${s.name}</h3>
                  <p class="text-xs" style="color:var(--text-muted)">${s.sub}</p>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
        <div class="text-center md:hidden">
          <button onclick="enterApp()" class="font-semibold hover:underline" style="color:var(--primary)">Voir toutes les matières →</button>
        </div>
      </div>
    </section>

    <!-- STATS SECTION -->
    <section class="py-16 px-6" style="background:var(--bg)">
      <div class="max-w-4xl mx-auto stats-band">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          ${[
            { icon: '📚', num: '16+', label: 'Matières couvertes' },
            { icon: '📖', num: '50+', label: 'Leçons disponibles' },
            { icon: '🎯', num: '11+', label: 'Quiz interactifs' },
            { icon: '📝', num: '8+', label: 'Sujets BAC' },
          ].map(s => `
            <div>
              <div class="text-4xl mb-2">${s.icon}</div>
              <p class="text-3xl font-black" style="color:var(--primary)">${s.num}</p>
              <p class="text-sm mt-1" style="color:var(--text-secondary)">${s.label}</p>
            </div>
          `).join('')}
        </div>
      </div>
    </section>

    <!-- ANNONCES -->
    ${announcements.length ? `
    <section class="py-12 px-6" style="background:var(--bg-card);border-top:1px solid var(--border)">
      <div class="max-w-3xl mx-auto">
        <h2 class="text-2xl font-bold text-center mb-8" style="color:var(--text-heading)">📢 Dernières annonces</h2>
        <div class="space-y-4">
          ${announcements.map(a => `
            <div class="rounded-2xl p-5 border-l-4 border-indigo-500" style="background:var(--bg);border:1px solid var(--border)">
              ${a.is_pinned ? '<span class="text-xs text-red-500 font-bold block mb-1">📌 ÉPINGLÉ</span>' : ''}
              <h3 class="font-bold mb-1" style="color:var(--text-heading)">${a.title}</h3>
              <p class="text-sm" style="color:var(--text-secondary)">${a.content ? a.content.slice(0, 100) + (a.content.length > 100 ? '...' : '') : ''}</p>
              <p class="text-xs mt-2" style="color:var(--text-muted)">${formatDate(a.created_at)}</p>
            </div>
          `).join('')}
        </div>
      </div>
    </section>
    ` : ''}

    <!-- CTA FINAL -->
    <section class="py-20 px-6" style="background:var(--bg)">
      <div class="max-w-3xl mx-auto cta-section">
        <div class="text-6xl mb-6">🚀</div>
        <h2 class="text-3xl md:text-4xl font-black text-white mb-4">
          Prêt à décrocher ton BAC ?
        </h2>
        <p class="text-indigo-100 text-lg mb-8">
          Rejoins des centaines d'élèves qui préparent leur baccalauréat sur Terminale Madagascar. C'est gratuit !
        </p>
        <div class="flex flex-wrap justify-center gap-4">
          <button onclick="enterApp()" class="flex items-center gap-3 bg-white text-indigo-700 font-black px-8 py-4 rounded-2xl hover:bg-indigo-50 transition shadow-lg text-lg">
            <i class="fas fa-book-open"></i> Explorer les cours
          </button>
          <button onclick="navigateTo('register'); renderApp();" class="flex items-center gap-3 border-2 border-white text-white font-black px-8 py-4 rounded-2xl hover:bg-white hover:text-indigo-700 transition text-lg">
            <i class="fas fa-user-plus"></i> Créer un compte gratuit
          </button>
        </div>
        <p class="text-indigo-200 text-sm mt-6">✅ Aucune carte de crédit · 0 Ar · Gratuit pour toujours</p>
      </div>
    </section>

    <!-- FOOTER -->
    <footer class="py-10 px-6 text-center border-t" style="background:var(--bg-card);border-color:var(--border)">
      <div class="flex items-center justify-center gap-2 mb-3">
        <span class="text-2xl">📚</span>
        <span class="font-bold text-lg" style="color:var(--primary)">Terminale Madagascar</span>
      </div>
      <p class="text-sm" style="color:var(--text-muted)">
        Plateforme de cours en ligne gratuite pour les élèves de Terminale A1 & A2 · Madagascar
      </p>
      <div class="flex justify-center gap-6 mt-4 text-sm" style="color:var(--text-secondary)">
        <button onclick="enterApp()" class="hover:underline">Cours</button>
        <button onclick="enterApp()" class="hover:underline">Quiz</button>
        <button onclick="enterApp()" class="hover:underline">Examens BAC</button>
        <button onclick="navigateTo('register'); renderApp();" class="hover:underline" style="color:var(--primary)">S'inscrire</button>
      </div>
      <p class="text-xs mt-4" style="color:var(--text-muted)">© 2025 Terminale Madagascar · Fait avec ❤️ pour les élèves malgaches</p>
    </footer>

    <div id="toast-container" class="fixed bottom-4 right-4 z-50 flex flex-col gap-2"></div>
  `;
}

function enterApp() {
  // Marquer que l'utilisateur veut naviguer dans l'app
  sessionStorage.setItem('entered_app', '1');
  currentRoute = 'home';
  renderApp();
}

// ============ HOME PAGE ============
async function renderHome() {
  const content = document.getElementById('main-content');

  const [announcementsRes, subsRes] = await Promise.all([
    apiCall('GET', '/public/announcements'),
    apiCall('GET', '/subscriptions/plans')
  ]);
  const announcements = announcementsRes.ok ? announcementsRes.data.announcements?.slice(0, 3) : [];

  content.innerHTML = `
    <div class="fade-in">
      <!-- Hero -->
      <div class="hero-gradient text-white rounded-2xl p-8 mb-6">
        <div class="max-w-2xl">
          <div class="flex items-center gap-2 text-indigo-200 text-sm mb-3">
            <i class="fas fa-graduation-cap"></i>
            <span>Terminale Série A1 & A2 · Madagascar</span>
          </div>
          <h1 class="text-3xl md:text-4xl font-bold mb-3">Réussis ton Baccalauréat ! 🎓</h1>
          <p class="text-indigo-100 text-lg mb-4">Cours complets, quiz interactifs et examens BAC — <strong>totalement gratuits</strong> pour tous les élèves de Terminale A1 et A2.</p>
          <div class="flex flex-wrap gap-3 mb-4">
            <button onclick="navigateTo('subjects')" class="bg-white text-indigo-700 font-bold px-6 py-3 rounded-xl hover:bg-indigo-50 transition flex items-center gap-2">
              <i class="fas fa-play-circle"></i> Commencer à apprendre
            </button>
            <button onclick="navigateTo('quiz', {filter: 'all'})" class="border-2 border-white text-white font-bold px-6 py-3 rounded-xl hover:bg-white hover:text-indigo-700 transition">
              🎯 Faire un quiz
            </button>
          </div>
          <!-- Bannière accès libre -->
          <div class="inline-flex items-center gap-2 bg-white bg-opacity-20 rounded-xl px-4 py-2">
            <span class="text-green-300 text-xl">✅</span>
            <span class="text-sm font-semibold">Aucune inscription requise · Tout est accessible librement</span>
          </div>
        </div>
      </div>

      <!-- Stats -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        ${[
          { icon: '📚', num: '16+', label: 'Matières' },
          { icon: '📖', num: '50+', label: 'Leçons' },
          { icon: '🎯', num: '11+', label: 'Quiz' },
          { icon: '📝', num: '8+', label: 'Examens BAC' },
        ].map(s => `
          <div class="stat-card text-center">
            <div class="text-3xl mb-1">${s.icon}</div>
            <div class="text-2xl font-bold text-indigo-600">${s.num}</div>
            <div class="text-sm text-gray-500">${s.label}</div>
          </div>
        `).join('')}
      </div>

      <div class="grid md:grid-cols-3 gap-6">
        <!-- Matières populaires -->
        <div class="md:col-span-2">
          <div class="flex items-center justify-between mb-4">
            <h2 class="text-xl font-bold text-gray-800">🔥 Matières Populaires</h2>
            <button onclick="navigateTo('subjects')" class="text-sm text-indigo-600 font-medium hover:underline">Voir tout →</button>
          </div>
          <div class="grid sm:grid-cols-2 gap-4" id="popular-subjects">
            ${[1,2,3,4].map(() => `<div class="card p-4 skeleton h-24"></div>`).join('')}
          </div>
        </div>

        <!-- Sidebar -->
        <div class="space-y-4">
          <!-- Accès rapide -->
          <div class="card p-4">
            <h3 class="font-bold text-gray-800 mb-3">🚀 Accès Rapide</h3>
            <div class="space-y-2">
              <button onclick="navigateTo('quiz', {filter: 'all'})" class="w-full text-left flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition">
                <span class="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">🎯</span>
                <span class="text-sm font-medium text-gray-700">Tous les quiz</span>
              </button>
              <button onclick="navigateTo('exams', {type: 'bac'})" class="w-full text-left flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition">
                <span class="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">📝</span>
                <span class="text-sm font-medium text-gray-700">Examens BAC officiels</span>
              </button>
              <button onclick="navigateTo('subjects')" class="w-full text-left flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition">
                <span class="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">📚</span>
                <span class="text-sm font-medium text-gray-700">Toutes les matières</span>
              </button>
              ${!currentUser ? `
                <button onclick="navigateTo('register')" class="w-full text-left flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition border border-indigo-200">
                  <span class="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">👤</span>
                  <div>
                    <span class="text-sm font-medium text-indigo-700">Créer un compte</span>
                    <p class="text-xs text-gray-400">Pour suivre sa progression</p>
                  </div>
                </button>
              ` : ''}
            </div>
          </div>

          <!-- Annonces -->
          <div class="card p-4">
            <h3 class="font-bold text-gray-800 mb-3">📢 Annonces</h3>
            <div class="space-y-3">
              ${announcements.length ? announcements.map(a => `
                <div class="border-l-4 border-indigo-400 pl-3 py-1">
                  ${a.is_pinned ? '<span class="text-xs text-red-500 font-bold">📌 ÉPINGLÉ</span>' : ''}
                  <p class="font-medium text-sm text-gray-800">${a.title}</p>
                  <p class="text-xs text-gray-500 mt-1">${formatDate(a.created_at)}</p>
                </div>
              `).join('') : '<p class="text-sm text-gray-500">Aucune annonce</p>'}
            </div>
          </div>
        </div>
      </div>

      <!-- Bandeau soutien -->
      <div class="mt-6 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-2xl p-6 text-white">
        <div class="flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <h3 class="text-2xl font-bold mb-1">💜 Soutenir la plateforme</h3>
            <p class="text-indigo-100">La plateforme est gratuite. Un abonnement volontaire aide à maintenir et améliorer le contenu.</p>
          </div>
          <div class="flex flex-wrap gap-3">
            <div class="bg-white bg-opacity-20 rounded-xl px-4 py-2 text-center">
              <p class="font-bold text-lg">15 000 Ar</p>
              <p class="text-xs text-indigo-100">/mois</p>
            </div>
            <div class="bg-white bg-opacity-20 rounded-xl px-4 py-2 text-center">
              <p class="font-bold text-lg">$3</p>
              <p class="text-xs text-indigo-100">/mois</p>
            </div>
            <button onclick="navigateTo('subscription')" class="bg-white text-indigo-600 font-bold px-6 py-2 rounded-xl hover:bg-indigo-50 transition">
              Soutenir →
            </button>
          </div>
        </div>
      </div>
    </div>
  `;

  loadPopularSubjects();
}

async function loadPopularSubjects() {
  const res = await apiCall('GET', `/subjects?class_level=${currentClassLevel}`);
  if (!res.ok) return;
  const subjects = res.data.subjects?.slice(0, 6) || [];
  const container = document.getElementById('popular-subjects');
  if (!container) return;

  container.innerHTML = subjects.map(s => `
    <div class="card p-4 subject-card cursor-pointer" style="border-left-color: ${s.color}" onclick="navigateTo('subject', {id: ${s.id}})">
      <div class="flex items-start gap-3">
        <span class="text-2xl">${s.icon}</span>
        <div class="flex-1 min-w-0">
          <h3 class="font-bold text-gray-800 text-sm">${s.name}</h3>
          <p class="text-xs text-gray-500 mt-1 line-clamp-2">${s.description || ''}</p>
          <div class="flex items-center gap-3 mt-2 text-xs text-gray-400">
            <span><i class="fas fa-book mr-1"></i>${s.lesson_count || 0} leçons</span>
            <span><i class="fas fa-question-circle mr-1"></i>${s.quiz_count || 0} quiz</span>
          </div>
        </div>
      </div>
    </div>
  `).join('');
}

// ============ SUBJECTS PAGE ============
async function renderSubjects() {
  const content = document.getElementById('main-content');
  const res = await apiCall('GET', `/subjects?class_level=${currentClassLevel}`);
  const subjects = res.ok ? res.data.subjects : [];

  content.innerHTML = `
    <div class="fade-in">
      <div class="flex items-center justify-between mb-6">
        <div>
          <h1 class="text-2xl font-bold text-gray-800">📚 Matières & Cours</h1>
          <p class="text-gray-500 text-sm mt-1">Terminale ${currentClassLevel === 'terminale_a1' ? 'A1' : 'A2'} · ${subjects.length} matières · <span class="text-green-600 font-semibold">Accès libre</span></p>
        </div>
        <div class="flex gap-2">
          <button onclick="setClassLevel('terminale_a1')" class="tab-btn text-sm ${currentClassLevel === 'terminale_a1' ? 'active' : 'bg-white border'}">Tle A1</button>
          <button onclick="setClassLevel('terminale_a2')" class="tab-btn text-sm ${currentClassLevel === 'terminale_a2' ? 'active' : 'bg-white border'}">Tle A2</button>
        </div>
      </div>

      <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        ${subjects.map(s => `
          <div class="card p-5 subject-card cursor-pointer" style="border-left-color: ${s.color}" onclick="navigateTo('subject', {id: ${s.id}})">
            <div class="flex items-start gap-3 mb-3">
              <span class="text-3xl">${s.icon}</span>
              <div>
                <h3 class="font-bold text-gray-800">${s.name}</h3>
                <span class="text-xs text-gray-400 font-mono">${s.code}</span>
                ${s.coefficient > 1 ? `<span class="ml-2 text-xs bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded">Coeff. ${s.coefficient}</span>` : ''}
              </div>
            </div>
            <p class="text-sm text-gray-500 mb-4 line-clamp-2">${s.description || ''}</p>
            <div class="flex items-center justify-between">
              <div class="flex gap-3 text-xs text-gray-400">
                <span><i class="fas fa-layer-group mr-1"></i>${s.chapter_count || 0} chap.</span>
                <span><i class="fas fa-book-open mr-1"></i>${s.lesson_count || 0} leçons</span>
                <span><i class="fas fa-question-circle mr-1"></i>${s.quiz_count || 0} quiz</span>
              </div>
              <span class="text-indigo-600 text-xs font-semibold">Voir →</span>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

// ============ SUBJECT DETAIL ============
async function renderSubjectDetail() {
  const content = document.getElementById('main-content');
  const id = routeParams.id;

  content.innerHTML = `<div class="flex items-center justify-center min-h-64"><div class="animate-spin rounded-full h-12 w-12 border-t-4 border-indigo-600"></div></div>`;

  const subjectRes = await apiCall('GET', `/subjects/${id}`);

  if (!subjectRes.ok) {
    content.innerHTML = '<div class="card p-8 text-center"><p class="text-red-500">Matière non trouvée</p></div>';
    return;
  }

  const { subject, chapters, quizzes } = subjectRes.data;

  content.innerHTML = `
    <div class="fade-in">
      <div class="card p-6 mb-6" style="border-top: 4px solid ${subject.color}">
        <button onclick="navigateTo('subjects')" class="text-sm text-indigo-600 hover:underline mb-3 flex items-center gap-1">
          <i class="fas fa-arrow-left"></i> Retour aux matières
        </button>
        <div class="flex items-start gap-4">
          <span class="text-4xl">${subject.icon}</span>
          <div>
            <h1 class="text-2xl font-bold text-gray-800">${subject.name}</h1>
            <p class="text-gray-500 mt-1">${subject.description || ''}</p>
            <div class="flex flex-wrap gap-4 mt-3 text-sm text-gray-500">
              <span><i class="fas fa-layer-group mr-1 text-indigo-500"></i>${chapters?.length || 0} chapitres</span>
              <span><i class="fas fa-graduation-cap mr-1 text-indigo-500"></i>Coeff. ${subject.coefficient}</span>
              <span class="text-green-600 font-semibold"><i class="fas fa-unlock mr-1"></i>Accès libre</span>
            </div>
          </div>
        </div>
      </div>

      <div class="flex gap-2 mb-6">
        <button class="tab-btn active" id="tab-chapters" onclick="showTab('chapters', this)">📖 Chapitres & Leçons</button>
        <button class="tab-btn bg-white border" id="tab-quizzes" onclick="showTab('quizzes', this)">🎯 Quiz (${quizzes?.length || 0})</button>
      </div>

      <div id="content-chapters" class="space-y-4">
        ${chapters?.map(ch => `
          <div class="card overflow-hidden">
            <div class="flex items-center justify-between p-4 cursor-pointer hover:bg-gray-50" onclick="toggleChapter('chapter-${ch.id}')">
              <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm" style="background: ${subject.color}20; color: ${subject.color}">
                  ${ch.order_index}
                </div>
                <div>
                  <h3 class="font-semibold text-gray-800">${ch.title}</h3>
                  <p class="text-xs text-gray-500">${ch.lesson_count || 0} leçons · <span class="text-green-600 font-semibold">Gratuit</span></p>
                </div>
              </div>
              <i class="fas fa-chevron-down text-gray-400 transition-transform" id="icon-chapter-${ch.id}"></i>
            </div>
            <div id="chapter-${ch.id}" class="hidden border-t">
              <div id="lessons-${ch.id}" class="p-4">
                <div class="text-center text-gray-400 text-sm py-4">Chargement...</div>
              </div>
            </div>
          </div>
        `).join('') || '<p class="text-gray-500 text-center py-8">Aucun chapitre disponible</p>'}
      </div>

      <div id="content-quizzes" class="hidden">
        <div class="grid sm:grid-cols-2 gap-4">
          ${quizzes?.map(q => `
            <div class="card p-5 cursor-pointer hover:shadow-md transition" onclick="navigateTo('quiz', {id: ${q.id}})">
              <div class="flex items-start justify-between gap-2 mb-3">
                <h3 class="font-bold text-gray-800 text-sm">${q.title}</h3>
                ${getDifficultyBadge(q.difficulty)}
              </div>
              <p class="text-xs text-gray-500 mb-3">${q.description || ''}</p>
              <div class="flex items-center justify-between text-xs text-gray-400">
                <div class="flex gap-3">
                  <span><i class="fas fa-question-circle mr-1"></i>${q.question_count || 0} questions</span>
                  <span><i class="fas fa-clock mr-1"></i>${q.duration_minutes} min</span>
                </div>
                <span class="badge badge-free"><i class="fas fa-unlock mr-1"></i>Gratuit</span>
              </div>
            </div>
          `).join('') || '<p class="text-gray-500 text-center py-8 col-span-2">Aucun quiz disponible</p>'}
        </div>
      </div>
    </div>
  `;

  window._currentSubjectId = id;
}

function toggleChapter(id) {
  const el = document.getElementById(id);
  const icon = document.getElementById('icon-' + id);
  el.classList.toggle('hidden');
  icon?.classList.toggle('rotate-180');
  if (!el.classList.contains('hidden')) {
    loadChapterLessons(id.replace('chapter-', ''));
  }
}

async function loadChapterLessons(chapterId) {
  const container = document.getElementById(`lessons-${chapterId}`);
  if (!container) return;
  const subjectId = window._currentSubjectId;
  const res = await apiCall('GET', `/subjects/${subjectId}/chapters/${chapterId}/lessons`);

  if (!res.ok) {
    container.innerHTML = '<p class="text-red-500 text-sm text-center">Erreur de chargement</p>';
    return;
  }

  const { lessons } = res.data;

  if (!lessons?.length) {
    container.innerHTML = '<p class="text-gray-400 text-sm text-center">Aucune leçon disponible</p>';
    return;
  }

  container.innerHTML = `
    <div class="space-y-2">
      ${lessons.map(l => `
        <div class="flex items-center gap-3 p-2 rounded-lg cursor-pointer hover:bg-indigo-50 hover:text-indigo-700 transition"
          onclick="navigateTo('lesson', {id: ${l.id}})">
          <div class="w-8 h-8 rounded-lg flex items-center justify-center bg-indigo-100 text-indigo-600">
            <i class="fas ${l.lesson_type === 'video' ? 'fa-play-circle' : l.lesson_type === 'pdf' ? 'fa-file-pdf' : 'fa-book-open'} text-sm"></i>
          </div>
          <div class="flex-1 min-w-0">
            <p class="text-sm font-medium text-gray-800 truncate">${l.title}</p>
            <p class="text-xs text-gray-400">${l.duration_minutes > 0 ? `${l.duration_minutes} min` : 'Lecture'}</p>
          </div>
          <i class="fas fa-arrow-right text-indigo-400 text-xs"></i>
        </div>
      `).join('')}
    </div>
  `;
}

function showTab(tab, btn) {
  document.querySelectorAll('[id^="content-"]').forEach(el => el.classList.add('hidden'));
  document.querySelectorAll('.tab-btn').forEach(el => { el.classList.remove('active'); el.classList.add('bg-white', 'border'); });
  document.getElementById(`content-${tab}`)?.classList.remove('hidden');
  btn.classList.add('active');
  btn.classList.remove('bg-white', 'border');
}

// ============ LESSON ============
async function renderLesson() {
  const content = document.getElementById('main-content');
  const id = routeParams.id;

  content.innerHTML = `<div class="flex items-center justify-center min-h-64"><div class="animate-spin rounded-full h-12 w-12 border-t-4 border-indigo-600"></div></div>`;

  const res = await apiCall('GET', `/lessons/${id}`);

  if (!res.ok) {
    content.innerHTML = '<div class="card p-8 text-center"><p class="text-red-500">Leçon non trouvée</p></div>';
    return;
  }

  const { lesson, progress, prevLesson, nextLesson } = res.data;

  content.innerHTML = `
    <div class="fade-in max-w-4xl">
      <div class="flex items-center gap-2 text-sm text-gray-500 mb-4">
        <button onclick="navigateTo('subjects')" class="hover:text-indigo-600">Matières</button>
        <i class="fas fa-chevron-right text-xs"></i>
        <button onclick="navigateTo('subject', {id: ${lesson.subject_id}})" class="hover:text-indigo-600" style="color: ${lesson.subject_color}">${lesson.subject_name}</button>
        <i class="fas fa-chevron-right text-xs"></i>
        <span class="text-gray-400">${lesson.chapter_title}</span>
      </div>

      <div class="card p-6 md:p-8">
        <div class="flex items-start justify-between gap-4 mb-6">
          <div>
            <h1 class="text-2xl font-bold text-gray-800">${lesson.title}</h1>
            <div class="flex items-center gap-3 mt-2 text-sm text-gray-400">
              <span><i class="fas fa-eye mr-1"></i>${lesson.view_count} vues</span>
              ${lesson.duration_minutes ? `<span><i class="fas fa-clock mr-1"></i>${lesson.duration_minutes} min</span>` : ''}
              <span class="text-green-600 font-semibold"><i class="fas fa-unlock mr-1"></i>Accès libre</span>
            </div>
          </div>
          ${progress?.is_completed ? `
            <span class="flex items-center gap-1 bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-semibold">
              <i class="fas fa-check-circle"></i> Complété
            </span>
          ` : ''}
        </div>

        <div class="lesson-content prose max-w-none">
          ${lesson.content}
        </div>

        ${!currentUser ? `
          <div class="mt-6 p-4 bg-indigo-50 border border-indigo-200 rounded-xl text-center">
            <p class="text-indigo-700 text-sm mb-2">
              <i class="fas fa-info-circle mr-1"></i>
              Créez un compte gratuit pour suivre votre progression et marquer les leçons complétées
            </p>
            <button onclick="navigateTo('register')" class="text-indigo-700 font-bold hover:underline text-sm">
              S'inscrire gratuitement →
            </button>
          </div>
        ` : ''}

        <div class="flex items-center justify-between mt-8 pt-6 border-t">
          <div>
            ${prevLesson ? `
              <button onclick="navigateTo('lesson', {id: ${prevLesson.id}})" class="flex items-center gap-2 text-gray-600 hover:text-indigo-600 font-medium">
                <i class="fas fa-arrow-left"></i> Leçon précédente
              </button>
            ` : ''}
          </div>
          <div class="flex gap-3">
            ${currentUser && !progress?.is_completed ? `
              <button onclick="markLessonComplete(${lesson.id})" class="bg-green-500 text-white px-5 py-2 rounded-xl hover:bg-green-600 transition font-medium flex items-center gap-2">
                <i class="fas fa-check"></i> Marquer complété
              </button>
            ` : ''}
            ${nextLesson ? `
              <button onclick="navigateTo('lesson', {id: ${nextLesson.id}})" class="bg-indigo-600 text-white px-5 py-2 rounded-xl hover:bg-indigo-700 transition font-medium flex items-center gap-2">
                Leçon suivante <i class="fas fa-arrow-right"></i>
              </button>
            ` : ''}
          </div>
        </div>
      </div>
    </div>
  `;
}

async function markLessonComplete(lessonId) {
  const res = await apiCall('POST', `/lessons/${lessonId}/complete`);
  if (res.ok) {
    showToast('Leçon marquée comme complétée! ✅', 'success');
    renderLesson();
  }
}

// ============ QUIZ LIST ============
async function renderQuiz() {
  const content = document.getElementById('main-content');
  const quizId = routeParams.id;

  if (quizId) {
    renderQuizDetail(quizId);
    return;
  }

  const filter = routeParams.filter || 'all';
  const subjectId = routeParams.subject_id || '';

  const res = await apiCall('GET', `/quiz?${subjectId ? `subject_id=${subjectId}` : ''}`);
  const quizzes = res.ok ? res.data.quizzes : [];
  const filtered = filter === 'free' ? quizzes.filter(q => q.is_free) : quizzes;

  content.innerHTML = `
    <div class="fade-in">
      <div class="flex items-center justify-between mb-6">
        <div>
          <h1 class="text-2xl font-bold text-gray-800">🎯 Quiz Interactifs</h1>
          <p class="text-gray-500 text-sm mt-1">${filtered.length} quiz disponibles · <span class="text-green-600 font-semibold">Tous accessibles librement</span></p>
        </div>
      </div>

      <div class="card p-4 mb-6">
        <div class="flex flex-wrap gap-2">
          <button onclick="delete routeParams.subject_id; renderQuiz();" class="text-xs px-3 py-1.5 rounded-lg font-medium ${!routeParams.subject_id ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}">Toutes matières</button>
          ${[...new Set(quizzes.map(q => JSON.stringify({id: q.subject_id, name: q.subject_name, color: q.subject_color})))].map(s => {
            const sObj = JSON.parse(s);
            return `<button onclick="routeParams.subject_id='${sObj.id}'; renderQuiz();" class="text-xs px-3 py-1.5 rounded-lg font-medium ${routeParams.subject_id == sObj.id ? 'text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}" style="${routeParams.subject_id == sObj.id ? `background: ${sObj.color}` : ''}">${sObj.name}</button>`;
          }).join('')}
        </div>
      </div>

      <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        ${filtered.map(q => `
          <div class="card p-5 cursor-pointer hover:shadow-md transition" onclick="navigateTo('quiz', {id: ${q.id}})">
            <div class="flex items-start justify-between gap-2 mb-2">
              <span class="text-lg">${q.subject_icon || '🎯'}</span>
              ${getDifficultyBadge(q.difficulty)}
            </div>
            <h3 class="font-bold text-gray-800 mb-1 text-sm">${q.title}</h3>
            <p class="text-xs font-medium mb-1" style="color: ${q.subject_color || '#6B7280'}">${q.subject_name}</p>
            ${q.chapter_title ? `<p class="text-xs text-gray-400 mb-3">${q.chapter_title}</p>` : '<div class="mb-3"></div>'}
            <div class="flex items-center justify-between text-xs text-gray-400">
              <div class="flex gap-3">
                <span><i class="fas fa-question-circle mr-1"></i>${q.question_count || 0} questions</span>
                <span><i class="fas fa-clock mr-1"></i>${q.duration_minutes} min</span>
              </div>
              <span class="badge badge-free"><i class="fas fa-unlock mr-1"></i>Gratuit</span>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

// ============ QUIZ DETAIL & TAKING ============
let quizTimer = null;
let quizStartTime = null;
let selectedAnswers = {};

async function renderQuizDetail(id) {
  const content = document.getElementById('main-content');
  content.innerHTML = `<div class="flex items-center justify-center min-h-64"><div class="animate-spin rounded-full h-12 w-12 border-t-4 border-indigo-600"></div></div>`;

  const res = await apiCall('GET', `/quiz/${id}`);

  if (!res.ok) {
    content.innerHTML = '<div class="card p-8 text-center"><p class="text-red-500">Quiz non trouvé</p></div>';
    return;
  }

  const { quiz, questions, attempt_count } = res.data;

  content.innerHTML = `
    <div class="fade-in max-w-2xl mx-auto">
      <button onclick="navigateTo('quiz', {})" class="text-sm text-indigo-600 hover:underline mb-4 flex items-center gap-1">
        <i class="fas fa-arrow-left"></i> Retour aux quiz
      </button>
      <div class="card p-6">
        <div class="flex items-start gap-3 mb-4">
          <span class="text-3xl">${quiz.subject_icon || '🎯'}</span>
          <div>
            <h1 class="text-2xl font-bold text-gray-800">${quiz.title}</h1>
            <p class="text-sm font-medium" style="color: ${quiz.subject_color}">${quiz.subject_name}</p>
          </div>
        </div>

        <p class="text-gray-500 mb-5">${quiz.description || ''}</p>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          ${[
            { icon: 'question-circle', label: 'Questions', value: questions?.length || 0 },
            { icon: 'clock', label: 'Durée', value: `${quiz.duration_minutes} min` },
            { icon: 'check-circle', label: 'Réussite', value: `${quiz.passing_score}%` },
            { icon: 'unlock', label: 'Accès', value: 'Gratuit' },
          ].map(s => `
            <div class="text-center p-3 bg-gray-50 rounded-xl">
              <i class="fas fa-${s.icon} text-indigo-400 text-lg mb-1"></i>
              <p class="font-bold text-gray-800">${s.value}</p>
              <p class="text-xs text-gray-500">${s.label}</p>
            </div>
          `).join('')}
        </div>

        ${!currentUser ? `
          <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center mb-4">
            <p class="text-blue-700 text-sm mb-1"><i class="fas fa-info-circle mr-1"></i>Vous pouvez faire ce quiz sans compte !</p>
            <p class="text-blue-600 text-xs">Créez un compte pour sauvegarder vos résultats et suivre votre progression.</p>
          </div>
        ` : ''}

        <button onclick="startQuiz(${quiz.id}, ${quiz.duration_minutes})" class="w-full bg-indigo-600 text-white font-bold py-4 rounded-xl hover:bg-indigo-700 transition text-lg flex items-center justify-center gap-2">
          <i class="fas fa-play"></i> Commencer le Quiz
        </button>
      </div>
    </div>
  `;

  window._currentQuiz = { quiz, questions };
}

function startQuiz(quizId, durationMinutes) {
  const { quiz, questions } = window._currentQuiz;
  selectedAnswers = {};
  quizStartTime = Date.now();

  const content = document.getElementById('main-content');
  let timeLeft = durationMinutes * 60;

  content.innerHTML = `
    <div class="fade-in max-w-2xl mx-auto">
      <div class="card p-4 mb-4 flex items-center justify-between sticky top-16 z-10">
        <h2 class="font-bold text-gray-800 text-sm">${quiz.title}</h2>
        <div class="flex items-center gap-3">
          <span id="quiz-progress-text" class="text-xs text-gray-500">0/${questions.length} répondus</span>
          <div id="quiz-timer" class="font-mono font-bold text-lg text-indigo-600">
            ${Math.floor(timeLeft / 60).toString().padStart(2, '0')}:${(timeLeft % 60).toString().padStart(2, '0')}
          </div>
        </div>
      </div>

      <div class="progress-bar mb-6">
        <div class="progress-fill" id="quiz-progress-bar" style="width: 0%"></div>
      </div>

      <div class="space-y-6" id="questions-container">
        ${questions.map((q, i) => `
          <div class="card p-6" id="question-${q.id}">
            <div class="flex items-start gap-3 mb-4">
              <span class="w-7 h-7 bg-indigo-600 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">${i + 1}</span>
              <div>
                <p class="font-semibold text-gray-800">${q.question_text}</p>
                <p class="text-xs text-gray-400 mt-1">${q.points} point${q.points > 1 ? 's' : ''}</p>
              </div>
            </div>
            <div class="space-y-2 ml-10">
              ${JSON.parse(q.options || '[]').map((opt, oi) => `
                <div class="quiz-option" id="option-${q.id}-${oi}" onclick="selectAnswer(${q.id}, '${opt.replace(/'/g, "\\'")}', this)">
                  <span class="font-bold text-gray-400 mr-2">${String.fromCharCode(65 + oi)}.</span>
                  ${opt}
                </div>
              `).join('')}
            </div>
          </div>
        `).join('')}
      </div>

      <div class="mt-6 card p-4 flex items-center justify-between">
        <p class="text-sm text-gray-500" id="answered-count">0 / ${questions.length} répondus</p>
        <button onclick="submitQuiz(${quizId})" class="bg-green-500 text-white font-bold px-8 py-3 rounded-xl hover:bg-green-600 transition flex items-center gap-2">
          <i class="fas fa-paper-plane"></i> Soumettre le Quiz
        </button>
      </div>
    </div>
  `;

  quizTimer = setInterval(() => {
    timeLeft--;
    const minutes = Math.floor(timeLeft / 60).toString().padStart(2, '0');
    const seconds = (timeLeft % 60).toString().padStart(2, '0');
    const timerEl = document.getElementById('quiz-timer');
    if (timerEl) {
      timerEl.textContent = `${minutes}:${seconds}`;
      if (timeLeft <= 60) timerEl.classList.add('timer-warning');
    }
    if (timeLeft <= 0) {
      clearInterval(quizTimer);
      showToast('Temps écoulé! Soumission automatique...', 'warning');
      submitQuiz(quizId);
    }
  }, 1000);
}

function selectAnswer(questionId, answer, element) {
  document.querySelectorAll(`[id^="option-${questionId}-"]`).forEach(el => el.classList.remove('selected'));
  element.classList.add('selected');
  selectedAnswers[questionId] = answer;

  const count = Object.keys(selectedAnswers).length;
  const total = window._currentQuiz.questions.length;
  const pct = (count / total) * 100;

  const progressBar = document.getElementById('quiz-progress-bar');
  if (progressBar) progressBar.style.width = pct + '%';
  const progressText = document.getElementById('quiz-progress-text');
  if (progressText) progressText.textContent = `${count}/${total} répondus`;
  const answeredCount = document.getElementById('answered-count');
  if (answeredCount) answeredCount.textContent = `${count} / ${total} répondus`;
}

async function submitQuiz(quizId) {
  clearInterval(quizTimer);
  const timeTaken = Math.round((Date.now() - quizStartTime) / 1000);

  const res = await apiCall('POST', `/quiz/${quizId}/submit`, {
    answers: selectedAnswers,
    time_taken: timeTaken
  });

  if (res.ok) {
    window._quizResult = res.data;
    navigateTo('quiz-result', { quizId });
  } else {
    showToast(res.data.error || 'Erreur lors de la soumission', 'error');
  }
}

// ============ QUIZ RESULT ============
function renderQuizResult() {
  const content = document.getElementById('main-content');
  const result = window._quizResult;
  if (!result) { navigateTo('quiz', {}); return; }

  const { score, total_points, percentage, passed, results } = result;

  content.innerHTML = `
    <div class="fade-in max-w-2xl mx-auto">
      <div class="card p-8 text-center mb-6 ${passed ? 'border-2 border-green-400' : 'border-2 border-orange-300'}">
        <div class="text-6xl mb-3">${passed ? '🎉' : '💪'}</div>
        <h2 class="text-3xl font-bold ${passed ? 'text-green-600' : 'text-orange-500'}">${percentage}%</h2>
        <p class="text-xl font-semibold text-gray-700 mt-1">${passed ? 'Félicitations! Quiz réussi!' : 'Continuez vos efforts!'}</p>
        <p class="text-gray-500 mt-2">${score} / ${total_points} points</p>

        <div class="flex justify-center mt-4">
          <div class="relative w-24 h-24">
            <svg class="w-24 h-24 transform -rotate-90" viewBox="0 0 36 36">
              <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#E5E7EB" stroke-width="3"/>
              <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="${passed ? '#10B981' : '#F59E0B'}" stroke-width="3" stroke-dasharray="${percentage}, 100"/>
            </svg>
            <div class="absolute inset-0 flex items-center justify-center">
              <span class="text-lg font-bold ${passed ? 'text-green-600' : 'text-orange-500'}">${percentage}%</span>
            </div>
          </div>
        </div>

        ${!currentUser ? `
          <div class="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-xl text-sm text-blue-700">
            <i class="fas fa-save mr-1"></i>
            Créez un compte pour sauvegarder vos résultats et suivre votre progression !
            <button onclick="navigateTo('register')" class="font-bold hover:underline ml-1">S'inscrire →</button>
          </div>
        ` : ''}

        <div class="flex gap-4 justify-center mt-5">
          <button onclick="navigateTo('quiz', {id: routeParams.quizId})" class="flex items-center gap-2 bg-gray-100 text-gray-700 px-5 py-2.5 rounded-xl hover:bg-gray-200 font-medium">
            <i class="fas fa-redo"></i> Recommencer
          </button>
          <button onclick="navigateTo('quiz', {})" class="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl hover:bg-indigo-700 font-medium">
            <i class="fas fa-list"></i> Autres quiz
          </button>
        </div>
      </div>

      <div class="card p-6">
        <h3 class="font-bold text-gray-800 mb-4">📊 Détail des réponses</h3>
        <div class="space-y-4">
          ${results.map((r, i) => `
            <div class="p-4 rounded-xl ${r.is_correct ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}">
              <div class="flex items-start gap-2 mb-2">
                <span class="text-lg">${r.is_correct ? '✅' : '❌'}</span>
                <p class="font-medium text-gray-800 text-sm">${i+1}. ${r.question_text}</p>
              </div>
              ${!r.is_correct ? `
                <p class="text-sm text-red-600 ml-6"><strong>Votre réponse:</strong> ${r.user_answer || 'Non répondu'}</p>
                <p class="text-sm text-green-700 ml-6"><strong>Bonne réponse:</strong> ${r.correct_answer}</p>
              ` : `
                <p class="text-sm text-green-700 ml-6"><strong>✓</strong> ${r.correct_answer}</p>
              `}
              ${r.explanation ? `<p class="text-xs text-gray-500 mt-2 ml-6 italic">${r.explanation}</p>` : ''}
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

// ============ EXAMS ============
async function renderExams() {
  const content = document.getElementById('main-content');
  const filter = routeParams.type || 'all';
  const queryParam = filter !== 'all' ? `?type=${filter}` : '';
  const res = await apiCall('GET', `/exams${queryParam}`);
  const exams = res.ok ? res.data.exams : [];

  content.innerHTML = `
    <div class="fade-in">
      <div class="flex items-center justify-between mb-6">
        <div>
          <h1 class="text-2xl font-bold text-gray-800">📝 Examens & BAC</h1>
          <p class="text-gray-500 text-sm mt-1">${exams.length} examens disponibles · <span class="text-green-600 font-semibold">Accès libre</span></p>
        </div>
        <div class="flex gap-2">
          <button onclick="routeParams.type='all'; renderExams();" class="tab-btn text-sm ${filter === 'all' ? 'active' : 'bg-white border'}">Tous</button>
          <button onclick="routeParams.type='bac'; renderExams();" class="tab-btn text-sm ${filter === 'bac' ? 'active' : 'bg-white border'}">BAC</button>
          <button onclick="routeParams.type='practice'; renderExams();" class="tab-btn text-sm ${filter === 'practice' ? 'active' : 'bg-white border'}">Pratique</button>
        </div>
      </div>

      <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        ${exams.map(e => `
          <div class="card p-5 cursor-pointer hover:shadow-md transition" onclick="viewExam(${e.id})">
            <div class="flex items-center gap-2 mb-3">
              <span class="text-2xl">${e.subject_icon || '📝'}</span>
              <span class="text-xs font-semibold px-2 py-0.5 rounded-full ${e.exam_type === 'bac' ? 'bg-red-100 text-red-700' : e.exam_type === 'official' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600'}">
                ${e.exam_type === 'bac' ? '🎓 BAC OFFICIEL' : e.exam_type === 'official' ? 'OFFICIEL' : 'PRATIQUE'}
              </span>
            </div>
            <h3 class="font-bold text-gray-800 mb-1 text-sm">${e.title}</h3>
            <p class="text-xs font-medium mb-1" style="color: ${e.subject_color}">${e.subject_name}</p>
            ${e.year ? `<p class="text-xs text-gray-400 mb-3">Année: ${e.year}</p>` : '<div class="mb-3"></div>'}
            <div class="flex items-center justify-between text-xs text-gray-400">
              <span><i class="fas fa-clock mr-1"></i>${e.duration_minutes} min</span>
              <span class="badge badge-free"><i class="fas fa-unlock mr-1"></i>Gratuit</span>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

async function viewExam(id) {
  const res = await apiCall('GET', `/exams/${id}`);
  if (!res.ok) { showToast('Erreur lors du chargement', 'error'); return; }

  const { exam } = res.data;
  const html = `
    <h2 class="text-xl font-bold text-gray-800 mb-2">${exam.title}</h2>
    <p class="text-sm text-gray-500 mb-1">${exam.subject_name} · ${exam.duration_minutes} minutes</p>
    ${exam.year ? `<p class="text-sm text-gray-500 mb-4">Année: ${exam.year}</p>` : ''}
    <p class="text-gray-600 mb-4">${exam.description || ''}</p>
    ${exam.content ? `
      <div class="bg-gray-50 rounded-xl p-4 text-sm text-gray-700 max-h-96 overflow-y-auto">
        ${exam.content}
      </div>
    ` : '<p class="text-center text-gray-400 py-8">Contenu disponible prochainement</p>'}
    <div class="mt-4 flex justify-end">
      <button onclick="closeModal()" class="bg-indigo-600 text-white px-5 py-2 rounded-xl hover:bg-indigo-700">Fermer</button>
    </div>
  `;
  showModal(html, true);
}

// ============ SUBSCRIPTION ============
async function renderSubscription() {
  const content = document.getElementById('main-content');
  const res = await apiCall('GET', '/subscriptions/plans');
  const plans = res.ok ? res.data.plans : [];

  content.innerHTML = `
    <div class="fade-in">
      <div class="text-center mb-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-2">💜 Soutenir la Plateforme</h1>
        <p class="text-gray-500 max-w-lg mx-auto">Terminale Madagascar est <strong>100% gratuit</strong> pour tous les élèves. Un abonnement volontaire nous aide à maintenir et enrichir le contenu.</p>
        <div class="mt-3 inline-flex items-center gap-2 bg-green-100 text-green-700 px-4 py-2 rounded-xl text-sm font-semibold">
          <i class="fas fa-unlock"></i> Tout le contenu reste accessible sans abonnement
        </div>
      </div>

      <div class="flex justify-center mb-8">
        <div class="bg-white rounded-xl p-1 shadow flex gap-1">
          <button id="btn-mga" onclick="setCurrency('MGA')" class="px-6 py-2 rounded-lg font-semibold text-sm bg-indigo-600 text-white transition">🇲🇬 Ariary (MGA)</button>
          <button id="btn-usd" onclick="setCurrency('USD')" class="px-6 py-2 rounded-lg font-semibold text-sm text-gray-600 hover:bg-gray-100 transition">🇺🇸 Dollar (USD)</button>
        </div>
      </div>

      <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto mb-10">
        ${plans.map((p, i) => {
          const featured = p.id === 3;
          const features = JSON.parse(p.features || '[]');
          return `
            <div class="plan-card ${featured ? 'featured' : ''} relative" id="plan-${p.id}">
              ${featured ? '<div class="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-indigo-600 text-white text-xs px-3 py-1 rounded-full font-bold">⭐ POPULAIRE</div>' : ''}
              <h3 class="font-bold text-gray-800 text-lg mb-1">${p.name}</h3>
              <p class="text-xs text-gray-500 mb-4">${p.description}</p>

              <div class="mb-4">
                <div class="price-mga">
                  <p class="text-3xl font-bold text-indigo-600">${p.price_ariary > 0 ? formatAriary(p.price_ariary) : 'Gratuit'}</p>
                  ${p.price_ariary > 0 ? `<p class="text-sm text-gray-400">${p.duration_days >= 365 ? 'par an' : p.duration_days >= 90 ? 'par 3 mois' : 'par mois'}</p>` : '<p class="text-sm text-gray-400">Pour toujours</p>'}
                </div>
                <div class="price-usd hidden">
                  <p class="text-3xl font-bold text-indigo-600">${p.price_dollar > 0 ? `$${p.price_dollar}` : 'Free'}</p>
                  ${p.price_dollar > 0 ? `<p class="text-sm text-gray-400">${p.duration_days >= 365 ? 'per year' : p.duration_days >= 90 ? 'per 3 months' : 'per month'}</p>` : '<p class="text-sm text-gray-400">Forever</p>'}
                </div>
              </div>

              <ul class="space-y-2 mb-6">
                ${features.map(f => `
                  <li class="flex items-start gap-2 text-sm text-gray-600">
                    <i class="fas fa-check text-green-500 mt-0.5 flex-shrink-0"></i>
                    ${f}
                  </li>
                `).join('')}
              </ul>

              ${p.id === 1 ? `
                <button class="w-full py-3 rounded-xl font-bold border-2 border-gray-200 text-gray-600 cursor-default">
                  Plan actuel (gratuit)
                </button>
              ` : `
                <button onclick="subscribePlan(${p.id}, '${p.name}')" class="w-full py-3 rounded-xl font-bold ${featured ? 'bg-indigo-600 text-white hover:bg-indigo-700' : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'} transition">
                  ${currentUser ? 'Soutenir avec ce plan' : 'Choisir ce plan'}
                </button>
              `}
            </div>
          `;
        }).join('')}
      </div>

      <div class="card p-6 max-w-2xl mx-auto text-center">
        <h3 class="font-bold text-gray-800 mb-4">💳 Méthodes de Paiement Acceptées</h3>
        <div class="flex flex-wrap justify-center gap-4">
          ${[
            { icon: '📱', name: 'MVola', desc: 'Telma' },
            { icon: '📱', name: 'Orange Money', desc: 'Orange' },
            { icon: '💳', name: 'Visa/MasterCard', desc: 'Carte bancaire' },
            { icon: '🌐', name: 'PayPal', desc: 'International' },
          ].map(m => `
            <div class="flex items-center gap-2 bg-gray-50 px-4 py-2 rounded-xl">
              <span class="text-xl">${m.icon}</span>
              <div class="text-left">
                <p class="font-semibold text-sm text-gray-800">${m.name}</p>
                <p class="text-xs text-gray-400">${m.desc}</p>
              </div>
            </div>
          `).join('')}
        </div>
        <p class="text-xs text-gray-400 mt-4">Paiement 100% sécurisé • Annulation à tout moment</p>
      </div>
    </div>
  `;
}

let currentCurrency = 'MGA';
function setCurrency(currency) {
  currentCurrency = currency;
  document.querySelectorAll('.price-mga').forEach(el => el.classList.toggle('hidden', currency !== 'MGA'));
  document.querySelectorAll('.price-usd').forEach(el => el.classList.toggle('hidden', currency !== 'USD'));
  document.getElementById('btn-mga')?.classList.toggle('bg-indigo-600', currency === 'MGA');
  document.getElementById('btn-mga')?.classList.toggle('text-white', currency === 'MGA');
  document.getElementById('btn-mga')?.classList.toggle('text-gray-600', currency !== 'MGA');
  document.getElementById('btn-usd')?.classList.toggle('bg-indigo-600', currency === 'USD');
  document.getElementById('btn-usd')?.classList.toggle('text-white', currency === 'USD');
  document.getElementById('btn-usd')?.classList.toggle('text-gray-600', currency !== 'USD');
}

async function subscribePlan(planId, planName) {
  if (!currentUser) {
    const html = `
      <div class="text-center">
        <div class="text-5xl mb-4">👤</div>
        <h3 class="text-xl font-bold text-gray-800 mb-2">Connexion optionnelle</h3>
        <p class="text-gray-500 mb-6">Pour soutenir la plateforme, vous pouvez vous connecter ou continuer en tant qu'invité.</p>
        <div class="flex flex-col gap-3">
          <button onclick="closeModal(); navigateTo('login')" class="bg-indigo-600 text-white font-bold py-3 px-6 rounded-xl hover:bg-indigo-700 transition">
            Se connecter
          </button>
          <button onclick="closeModal(); showPaymentModal(${planId}, '${planName}')" class="border-2 border-indigo-600 text-indigo-600 font-bold py-3 px-6 rounded-xl hover:bg-indigo-50 transition">
            Continuer sans compte
          </button>
          <button onclick="closeModal()" class="text-gray-500 hover:underline text-sm">Annuler</button>
        </div>
      </div>
    `;
    showModal(html);
    return;
  }
  showPaymentModal(planId, planName);
}

function showPaymentModal(planId, planName) {
  const html = `
    <div>
      <h3 class="text-xl font-bold text-gray-800 mb-2">💳 Soutenir - Plan ${planName}</h3>
      <p class="text-gray-500 text-sm mb-6">Choisissez votre méthode de paiement</p>

      <div class="space-y-3" id="payment-options">
        ${[
          { method: 'mvola', icon: '📱', name: 'MVola', desc: '+261 34 XX XXX XX', color: 'bg-red-50 border-red-200' },
          { method: 'orange_money', icon: '📱', name: 'Orange Money', desc: '+261 32 XX XXX XX', color: 'bg-orange-50 border-orange-200' },
          { method: 'stripe', icon: '💳', name: 'Carte Bancaire (Visa/MC)', desc: 'Paiement sécurisé', color: 'bg-blue-50 border-blue-200' },
          { method: 'paypal', icon: '🌐', name: 'PayPal', desc: 'email@paypal.com', color: 'bg-sky-50 border-sky-200' },
        ].map(m => `
          <div class="payment-method flex items-center gap-3 p-3 border-2 rounded-xl cursor-pointer hover:border-indigo-400 transition ${m.color}"
            onclick="selectPaymentMethod('${m.method}', this)">
            <span class="text-2xl">${m.icon}</span>
            <div>
              <p class="font-semibold text-sm text-gray-800">${m.name}</p>
              <p class="text-xs text-gray-500">${m.desc}</p>
            </div>
          </div>
        `).join('')}
      </div>

      <div id="payment-reference-section" class="hidden mt-4">
        <label class="block text-sm font-medium text-gray-700 mb-2">Référence de paiement</label>
        <input type="text" id="payment-ref" placeholder="Ex: TXN-123456 ou numéro de confirmation"
          class="w-full border-2 border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:border-indigo-400 focus:outline-none">
      </div>

      <div class="flex gap-3 mt-6">
        <button onclick="closeModal()" class="flex-1 py-3 rounded-xl border-2 border-gray-200 text-gray-600 font-semibold hover:bg-gray-50">
          Annuler
        </button>
        <button id="confirm-payment-btn" onclick="confirmPayment(${planId})" class="flex-1 py-3 rounded-xl bg-indigo-600 text-white font-bold hover:bg-indigo-700 transition" disabled>
          Confirmer →
        </button>
      </div>
      <p class="text-xs text-center text-gray-400 mt-3">En confirmant, vous acceptez nos conditions d'utilisation</p>
    </div>
  `;
  showModal(html);
}

let selectedPaymentMethod = null;
function selectPaymentMethod(method, element) {
  document.querySelectorAll('.payment-method').forEach(el => el.classList.remove('border-indigo-500'));
  element.classList.add('border-indigo-500');
  selectedPaymentMethod = method;
  document.getElementById('payment-reference-section')?.classList.remove('hidden');
  document.getElementById('confirm-payment-btn')?.removeAttribute('disabled');
}

async function confirmPayment(planId) {
  const ref = document.getElementById('payment-ref')?.value;
  const btn = document.getElementById('confirm-payment-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Traitement...'; }

  if (!currentUser) {
    // Utilisateur non connecté: juste afficher un message de confirmation
    closeModal();
    showToast('🙏 Merci pour votre soutien ! Contactez-nous avec votre référence de paiement.', 'success');
    return;
  }

  const res = await apiCall('POST', '/subscriptions/subscribe', {
    plan_id: planId,
    payment_method: selectedPaymentMethod,
    payment_reference: ref || `MANUAL-${Date.now()}`,
    currency: currentCurrency
  });

  if (res.ok) {
    closeModal();
    showToast(`🎉 Merci pour votre soutien ! Abonnement activé jusqu'au ${formatDate(res.data.end_date)}`, 'success');
    await checkAuth();
    renderSubscription();
  } else {
    showToast(res.data.error || 'Erreur lors du paiement', 'error');
    if (btn) { btn.disabled = false; btn.textContent = 'Confirmer →'; }
  }
}

// ============ DASHBOARD ============
async function renderDashboard() {
  const content = document.getElementById('main-content');
  if (!currentUser) {
    // Afficher une page invitant à se connecter (sans forcer)
    content.innerHTML = `
      <div class="fade-in max-w-md mx-auto mt-12">
        <div class="card p-8 text-center">
          <div class="text-6xl mb-4">📊</div>
          <h2 class="text-2xl font-bold text-gray-800 mb-2">Tableau de bord</h2>
          <p class="text-gray-500 mb-6">Connectez-vous pour accéder à votre tableau de bord personnalisé et suivre votre progression.</p>
          <div class="flex flex-col gap-3">
            <button onclick="navigateTo('login')" class="bg-indigo-600 text-white font-bold py-3 px-6 rounded-xl hover:bg-indigo-700 transition">
              Se connecter
            </button>
            <button onclick="navigateTo('register')" class="border-2 border-indigo-600 text-indigo-600 font-bold py-3 px-6 rounded-xl hover:bg-indigo-50 transition">
              Créer un compte gratuit
            </button>
            <button onclick="navigateTo('home')" class="text-gray-500 hover:underline text-sm">
              Continuer sans compte →
            </button>
          </div>
          <p class="text-xs text-gray-400 mt-4">L'inscription est gratuite et optionnelle.<br>Tout le contenu reste accessible sans compte.</p>
        </div>
      </div>
    `;
    return;
  }

  content.innerHTML = `<div class="flex items-center justify-center min-h-64"><div class="animate-spin rounded-full h-12 w-12 border-t-4 border-indigo-600"></div></div>`;

  const res = await apiCall('GET', '/dashboard');
  if (!res.ok) { content.innerHTML = '<div class="card p-8 text-center"><p class="text-red-500">Erreur de chargement</p></div>'; return; }

  const { stats, subscription, recent_lessons, recent_quizzes, notifications } = res.data;
  const isPremium = subscription && subscription.plan_name !== 'Gratuit';

  content.innerHTML = `
    <div class="fade-in">
      <div class="flex items-center justify-between mb-6">
        <div>
          <h1 class="text-2xl font-bold text-gray-800">👋 Bonjour, ${currentUser.full_name.split(' ')[0]}!</h1>
          <p class="text-gray-500 text-sm mt-1">Terminale ${currentUser.class_level === 'terminale_a1' ? 'A1' : 'A2'} · ${formatDate(new Date().toISOString())}</p>
        </div>
        ${isPremium ? `
          <div class="bg-gradient-to-r from-yellow-400 to-orange-400 text-white px-4 py-2 rounded-xl font-bold text-sm flex items-center gap-2">
            <i class="fas fa-crown"></i> Supporter Premium
          </div>
        ` : `
          <button onclick="navigateTo('subscription')" class="bg-indigo-600 text-white px-4 py-2 rounded-xl font-bold text-sm hover:bg-indigo-700 transition flex items-center gap-2">
            <i class="fas fa-heart"></i> Soutenir
          </button>
        `}
      </div>

      <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        ${[
          { icon: 'book-open', label: 'Leçons complétées', value: stats.completed_lessons, color: 'text-blue-500', bg: 'bg-blue-50' },
          { icon: 'question-circle', label: 'Quiz tentés', value: stats.quiz_attempts, color: 'text-purple-500', bg: 'bg-purple-50' },
          { icon: 'chart-bar', label: 'Score moyen', value: `${stats.avg_quiz_score}%`, color: 'text-green-500', bg: 'bg-green-50' },
          { icon: 'trophy', label: 'Quiz réussis', value: stats.passed_quizzes, color: 'text-yellow-500', bg: 'bg-yellow-50' },
        ].map(s => `
          <div class="stat-card flex items-center gap-3">
            <div class="w-10 h-10 ${s.bg} rounded-xl flex items-center justify-center">
              <i class="fas fa-${s.icon} ${s.color}"></i>
            </div>
            <div>
              <p class="text-2xl font-bold text-gray-800">${s.value}</p>
              <p class="text-xs text-gray-500">${s.label}</p>
            </div>
          </div>
        `).join('')}
      </div>

      <div class="grid md:grid-cols-3 gap-6">
        <div class="md:col-span-2 space-y-5">
          <div class="card p-5">
            <h3 class="font-bold text-gray-800 mb-4">📖 Dernières Leçons</h3>
            ${recent_lessons?.length ? `
              <div class="space-y-3">
                ${recent_lessons.map(l => `
                  <div class="flex items-center gap-3 cursor-pointer hover:bg-gray-50 p-2 rounded-xl transition" onclick="navigateTo('lesson', {id: ${l.lesson_id}})">
                    <div class="w-8 h-8 rounded-lg flex items-center justify-center" style="background: ${l.color}20; color: ${l.color}">${l.icon}</div>
                    <div class="flex-1 min-w-0">
                      <p class="text-sm font-medium text-gray-800 truncate">${l.lesson_title}</p>
                      <p class="text-xs text-gray-400">${l.subject_name}</p>
                    </div>
                    ${l.is_completed ? '<i class="fas fa-check-circle text-green-500"></i>' : '<i class="fas fa-circle text-gray-200"></i>'}
                  </div>
                `).join('')}
              </div>
            ` : '<p class="text-gray-400 text-sm text-center py-4">Aucune leçon récente</p>'}
            <button onclick="navigateTo('subjects')" class="mt-3 text-indigo-600 text-sm font-medium hover:underline w-full text-center">Continuer à apprendre →</button>
          </div>

          <div class="card p-5">
            <h3 class="font-bold text-gray-800 mb-4">🎯 Derniers Quiz</h3>
            ${recent_quizzes?.length ? `
              <div class="space-y-3">
                ${recent_quizzes.map(q => {
                  const pct = q.total_points > 0 ? Math.round((q.score / q.total_points) * 100) : 0;
                  return `
                    <div class="flex items-center gap-3 p-2 rounded-xl">
                      <div class="w-8 h-8 rounded-lg flex items-center justify-center ${q.passed ? 'bg-green-100 text-green-600' : 'bg-orange-100 text-orange-600'}">
                        <i class="fas fa-${q.passed ? 'check' : 'times'} text-sm"></i>
                      </div>
                      <div class="flex-1 min-w-0">
                        <p class="text-sm font-medium text-gray-800 truncate">${q.quiz_title}</p>
                        <p class="text-xs text-gray-400">${q.subject_name}</p>
                      </div>
                      <span class="text-sm font-bold ${pct >= 60 ? 'text-green-600' : 'text-orange-500'}">${pct}%</span>
                    </div>
                  `;
                }).join('')}
              </div>
            ` : '<p class="text-gray-400 text-sm text-center py-4">Aucun quiz récent</p>'}
          </div>
        </div>

        <div class="space-y-5">
          <div class="card p-5">
            <h3 class="font-bold text-gray-800 mb-3">💎 Statut</h3>
            <div class="text-center">
              <div class="text-3xl mb-2">${isPremium ? '⭐' : '🆓'}</div>
              <p class="font-bold text-lg text-gray-800">${subscription?.plan_name || 'Gratuit'}</p>
              ${isPremium ? `<p class="font-semibold text-indigo-600 text-sm mt-1">Expire le ${formatDate(subscription.end_date)}</p>` : ''}
              <button onclick="navigateTo('subscription')" class="mt-3 w-full bg-indigo-600 text-white py-2 rounded-xl text-sm font-bold hover:bg-indigo-700 transition">
                ${isPremium ? 'Renouveler' : 'Soutenir la plateforme →'}
              </button>
            </div>
          </div>

          <div class="card p-5">
            <div class="flex items-center justify-between mb-3">
              <h3 class="font-bold text-gray-800">🔔 Notifications</h3>
              <button onclick="markNotifsRead()" class="text-xs text-indigo-600 hover:underline">Tout lire</button>
            </div>
            <div class="space-y-2 max-h-48 overflow-y-auto">
              ${notifications?.slice(0, 5).map(n => `
                <div class="flex items-start gap-2 p-2 rounded-lg ${n.is_read ? '' : 'bg-indigo-50'}">
                  <span class="text-sm">${n.type === 'success' ? '✅' : n.type === 'warning' ? '⚠️' : 'ℹ️'}</span>
                  <div>
                    <p class="text-xs font-semibold text-gray-800">${n.title}</p>
                    <p class="text-xs text-gray-500">${n.message}</p>
                  </div>
                </div>
              `).join('') || '<p class="text-gray-400 text-xs text-center">Aucune notification</p>'}
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  apiCall('POST', '/dashboard/notifications/read');
}

async function markNotifsRead() {
  await apiCall('POST', '/dashboard/notifications/read');
  showToast('Notifications marquées comme lues', 'success');
}

// ============ ADMIN ============
async function renderAdmin() {
  const content = document.getElementById('main-content');
  if (!currentUser || (currentUser.role !== 'admin' && currentUser.role !== 'teacher')) {
    content.innerHTML = `
      <div class="card p-8 text-center max-w-md mx-auto mt-12">
        <div class="text-5xl mb-4">🔒</div>
        <h2 class="text-xl font-bold text-gray-800 mb-2">Accès Administrateur</h2>
        <p class="text-gray-500 mb-6">Connectez-vous avec un compte administrateur pour accéder à cette section.</p>
        <button onclick="navigateTo('login')" class="bg-indigo-600 text-white font-bold py-3 px-8 rounded-xl hover:bg-indigo-700">
          Se connecter
        </button>
      </div>
    `;
    return;
  }

  const res = await apiCall('GET', '/admin/stats');
  if (!res.ok) { content.innerHTML = '<div class="card p-8 text-center"><p class="text-red-500">Erreur admin</p></div>'; return; }

  const { stats, recent_users } = res.data;

  content.innerHTML = `
    <div class="fade-in">
      <h1 class="text-2xl font-bold text-gray-800 mb-6">⚙️ Administration</h1>

      <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        ${[
          { label: 'Étudiants', value: stats.total_students, icon: '👨‍🎓', color: 'bg-blue-50 text-blue-600' },
          { label: 'Supporters', value: stats.active_subscriptions, icon: '⭐', color: 'bg-yellow-50 text-yellow-600' },
          { label: 'Leçons', value: stats.total_lessons, icon: '📖', color: 'bg-green-50 text-green-600' },
          { label: 'Tentatives Quiz', value: stats.total_quiz_attempts, icon: '🎯', color: 'bg-purple-50 text-purple-600' },
        ].map(s => `
          <div class="stat-card flex items-center gap-3">
            <div class="w-10 h-10 ${s.color} rounded-xl flex items-center justify-center text-xl">${s.icon}</div>
            <div>
              <p class="text-2xl font-bold text-gray-800">${s.value}</p>
              <p class="text-xs text-gray-500">${s.label}</p>
            </div>
          </div>
        `).join('')}
      </div>

      <div class="grid md:grid-cols-2 gap-6">
        <div class="card p-5">
          <h3 class="font-bold text-gray-800 mb-4">👥 Derniers Inscrits</h3>
          <div class="space-y-2">
            ${recent_users?.map(u => `
              <div class="flex items-center gap-3 p-2 hover:bg-gray-50 rounded-lg">
                <div class="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-xs">
                  ${getInitials(u.full_name)}
                </div>
                <div class="flex-1 min-w-0">
                  <p class="text-sm font-medium text-gray-800 truncate">${u.full_name}</p>
                  <p class="text-xs text-gray-400">${u.email}</p>
                </div>
                <span class="text-xs text-gray-400">${formatDate(u.created_at)}</span>
              </div>
            `).join('') || '<p class="text-gray-400 text-sm text-center">Aucun étudiant</p>'}
          </div>
        </div>

        <div class="card p-5">
          <h3 class="font-bold text-gray-800 mb-4">📢 Nouvelle Annonce</h3>
          <div class="space-y-3">
            <input type="text" id="ann-title" placeholder="Titre de l'annonce" class="w-full border-2 border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:border-indigo-400 focus:outline-none">
            <textarea id="ann-content" rows="3" placeholder="Contenu de l'annonce..." class="w-full border-2 border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:border-indigo-400 focus:outline-none resize-none"></textarea>
            <div class="flex items-center gap-3">
              <label class="flex items-center gap-2 text-sm text-gray-600">
                <input type="checkbox" id="ann-pinned" class="rounded"> Épingler
              </label>
              <select id="ann-audience" class="border-2 border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:border-indigo-400 focus:outline-none">
                <option value="all">Tous</option>
                <option value="subscribers">Supporters</option>
                <option value="a1">Terminale A1</option>
                <option value="a2">Terminale A2</option>
              </select>
            </div>
            <button onclick="publishAnnouncement()" class="w-full bg-indigo-600 text-white font-bold py-2.5 rounded-xl hover:bg-indigo-700 transition">
              Publier l'annonce
            </button>
          </div>
        </div>
      </div>
    </div>
  `;
}

async function publishAnnouncement() {
  const title = document.getElementById('ann-title')?.value;
  const content = document.getElementById('ann-content')?.value;
  const is_pinned = document.getElementById('ann-pinned')?.checked;
  const target_audience = document.getElementById('ann-audience')?.value;
  if (!title || !content) { showToast('Titre et contenu requis', 'error'); return; }

  const res = await apiCall('POST', '/admin/announcements', { title, content, is_pinned, target_audience });
  if (res.ok) {
    showToast('Annonce publiée avec succès!', 'success');
    document.getElementById('ann-title').value = '';
    document.getElementById('ann-content').value = '';
  } else {
    showToast(res.data.error || 'Erreur', 'error');
  }
}

// ============ AUTH PAGES ============
function renderLogin() {
  const content = document.getElementById('main-content');
  content.innerHTML = `
    <div class="fade-in max-w-md mx-auto">
      <div class="card p-8">
        <div class="text-center mb-6">
          <span class="text-5xl">📚</span>
          <h1 class="text-2xl font-bold text-gray-800 mt-2">Connexion</h1>
          <p class="text-gray-500 text-sm mt-1">Accédez à votre espace de suivi personnel</p>
        </div>

        <div class="mb-4 p-3 bg-green-50 border border-green-200 rounded-xl flex items-start gap-2">
          <i class="fas fa-info-circle text-green-500 mt-0.5"></i>
          <p class="text-xs text-green-700">La connexion est <strong>optionnelle</strong>. Tout le contenu est accessible sans compte.</p>
        </div>

        <form onsubmit="handleLogin(event)" class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input type="email" id="login-email" required placeholder="votre@email.mg"
              class="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-sm focus:border-indigo-400 focus:outline-none">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Mot de passe</label>
            <input type="password" id="login-password" required placeholder="••••••••"
              class="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-sm focus:border-indigo-400 focus:outline-none">
          </div>
          <button type="submit" id="login-btn" class="w-full bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700 transition flex items-center justify-center gap-2">
            <i class="fas fa-sign-in-alt"></i> Se connecter
          </button>
        </form>

        <div class="text-center mt-4">
          <button onclick="navigateTo('home')" class="text-gray-400 hover:text-gray-600 text-sm hover:underline">
            ← Continuer sans compte
          </button>
        </div>

        <div class="text-center mt-4 space-y-2">
          <p class="text-gray-500 text-sm">Pas encore de compte?</p>
          <button onclick="navigateTo('register')" class="text-indigo-600 font-semibold hover:underline">
            S'inscrire gratuitement →
          </button>
        </div>

        <div class="mt-6 p-4 bg-gray-50 rounded-xl">
          <p class="text-xs font-semibold text-gray-500 mb-2">COMPTE ADMINISTRATEUR</p>
          <button onclick="fillDemo('ainasolofitiavana123@gmail.com', 'Admin@2024!')" class="text-xs text-indigo-600 hover:underline block">
            <i class="fas fa-user-shield mr-1"></i>ainasolofitiavana123@gmail.com
          </button>
          <p class="text-xs text-gray-400 mt-1">Cliquer pour remplir automatiquement</p>
        </div>
      </div>
    </div>
  `;
}

function fillDemo(email, password) {
  document.getElementById('login-email').value = email;
  document.getElementById('login-password').value = password;
}

async function handleLogin(e) {
  e.preventDefault();
  const btn = document.getElementById('login-btn');
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Connexion...';
  btn.disabled = true;

  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  const success = await login(email, password);
  if (success) {
    showToast(`Bienvenue ${currentUser.full_name}! 👋`, 'success');
    navigateTo('dashboard');
  } else {
    btn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Se connecter';
    btn.disabled = false;
  }
}

function renderRegister() {
  const content = document.getElementById('main-content');
  content.innerHTML = `
    <div class="fade-in max-w-md mx-auto">
      <div class="card p-8">
        <div class="text-center mb-6">
          <span class="text-5xl">🎓</span>
          <h1 class="text-2xl font-bold text-gray-800 mt-2">Créer un compte</h1>
          <p class="text-gray-500 text-sm mt-1">Pour suivre votre progression</p>
        </div>

        <div class="mb-4 p-3 bg-green-50 border border-green-200 rounded-xl flex items-start gap-2">
          <i class="fas fa-check-circle text-green-500 mt-0.5"></i>
          <div>
            <p class="text-xs text-green-700 font-semibold">Inscription 100% gratuite et optionnelle</p>
            <p class="text-xs text-green-600">Tout le contenu est accessible sans compte.</p>
          </div>
        </div>

        <form onsubmit="handleRegister(event)" class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Nom complet</label>
            <input type="text" id="reg-name" required placeholder="Jean Rakoto"
              class="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-sm focus:border-indigo-400 focus:outline-none">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input type="email" id="reg-email" required placeholder="jean@example.mg"
              class="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-sm focus:border-indigo-400 focus:outline-none">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Classe</label>
            <select id="reg-class" class="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-sm focus:border-indigo-400 focus:outline-none">
              <option value="terminale_a1">Terminale A1 (Lettres & Sciences Humaines)</option>
              <option value="terminale_a2">Terminale A2 (Sciences Sociales & Économie)</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Mot de passe</label>
            <input type="password" id="reg-password" required placeholder="Minimum 6 caractères"
              class="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-sm focus:border-indigo-400 focus:outline-none">
          </div>
          <button type="submit" id="register-btn" class="w-full bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700 transition flex items-center justify-center gap-2">
            <i class="fas fa-user-plus"></i> Créer mon compte
          </button>
        </form>

        <div class="text-center mt-4">
          <button onclick="navigateTo('home')" class="text-gray-400 hover:text-gray-600 text-sm hover:underline">
            ← Continuer sans compte
          </button>
        </div>

        <div class="text-center mt-4">
          <p class="text-gray-500 text-sm">Déjà inscrit?
            <button onclick="navigateTo('login')" class="text-indigo-600 font-semibold hover:underline">Se connecter</button>
          </p>
        </div>
      </div>
    </div>
  `;
}

async function handleRegister(e) {
  e.preventDefault();
  const btn = document.getElementById('register-btn');
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Création...';
  btn.disabled = true;

  const success = await register({
    full_name: document.getElementById('reg-name').value,
    email: document.getElementById('reg-email').value,
    password: document.getElementById('reg-password').value,
    class_level: document.getElementById('reg-class').value,
  });

  if (success) {
    showToast('Compte créé avec succès! Bienvenue! 🎉', 'success');
    navigateTo('dashboard');
  } else {
    btn.innerHTML = '<i class="fas fa-user-plus"></i> Créer mon compte';
    btn.disabled = false;
  }
}

// ============ PROFILE PAGE ============
async function renderProfile() {
  const content = document.getElementById('main-content');

  if (!currentUser) {
    content.innerHTML = `
      <div class="fade-in max-w-md mx-auto mt-12">
        <div class="card p-8 text-center">
          <div class="text-6xl mb-4">👤</div>
          <h2 class="text-2xl font-bold mb-2" style="color:var(--text-heading)">Mon Profil</h2>
          <p class="mb-6" style="color:var(--text-secondary)">Connectez-vous pour accéder à votre profil.</p>
          <button onclick="navigateTo('login')" class="btn-primary w-full justify-center">
            <i class="fas fa-sign-in-alt"></i> Se connecter
          </button>
        </div>
      </div>
    `;
    return;
  }

  // Charger les données du dashboard pour avoir les stats
  const dashRes = await apiCall('GET', '/dashboard');
  const stats = dashRes.ok ? dashRes.data.stats : {};
  const subscription = dashRes.ok ? dashRes.data.subscription : null;
  const notifications = dashRes.ok ? (dashRes.data.notifications || []) : [];
  const isPremium = subscription && subscription.plan_name !== 'Gratuit';

  content.innerHTML = `
    <div class="fade-in max-w-3xl mx-auto">
      <!-- Profil card principal -->
      <div class="card overflow-hidden mb-6">
        <!-- Cover -->
        <div class="profile-cover">
          <div class="profile-cover-pattern"></div>
          <!-- Bouton edit cover -->
          <button class="absolute top-3 right-3 bg-white bg-opacity-20 hover:bg-opacity-30 text-white text-xs px-3 py-1.5 rounded-lg transition">
            <i class="fas fa-camera mr-1"></i> Modifier
          </button>
        </div>
        <!-- Avatar + infos -->
        <div class="px-6 pb-6">
          <div class="flex items-end justify-between -mt-12 mb-4">
            <div class="profile-avatar-wrapper">
              <div class="profile-avatar text-white" style="width:80px;height:80px;font-size:1.75rem">
                ${currentUser.avatar ? `<img src="${currentUser.avatar}" alt="" class="w-full h-full object-cover">` : getInitials(currentUser.full_name)}
              </div>
              <button class="avatar-edit-btn" onclick="showAvatarModal()" title="Changer la photo">
                <i class="fas fa-camera"></i>
              </button>
            </div>
            <button onclick="showEditProfileModal()" class="btn-secondary flex items-center gap-2">
              <i class="fas fa-edit"></i> Modifier le profil
            </button>
          </div>
          <div class="flex items-start justify-between flex-wrap gap-4">
            <div>
              <div class="flex items-center gap-3 flex-wrap">
                <h2 class="text-2xl font-black" style="color:var(--text-heading)">${currentUser.full_name}</h2>
                <span class="profile-badge ${currentUser.role === 'admin' ? 'badge-admin' : currentUser.role === 'teacher' ? 'badge-teacher' : 'badge-student'}">
                  ${currentUser.role === 'admin' ? '🛡️ Admin' : currentUser.role === 'teacher' ? '👨‍🏫 Professeur' : '🎓 Étudiant'}
                </span>
                ${isPremium ? '<span class="profile-badge badge-premium">⭐ Supporter</span>' : ''}
              </div>
              <p class="mt-1" style="color:var(--text-secondary)">
                <i class="fas fa-envelope mr-1"></i>${currentUser.email}
              </p>
              <p class="text-sm mt-1" style="color:var(--text-muted)">
                <i class="fas fa-graduation-cap mr-1"></i>
                ${currentUser.class_level === 'terminale_a1' ? 'Terminale A1 – Lettres & Sciences Humaines' : 'Terminale A2 – Sciences Sociales & Économie'}
              </p>
            </div>
            ${isPremium ? `
              <div class="text-right">
                <p class="text-xs font-semibold" style="color:var(--text-muted)">Abonnement</p>
                <p class="font-bold text-yellow-600">${subscription.plan_name}</p>
                <p class="text-xs" style="color:var(--text-muted)">Jusqu'au ${formatDate(subscription.end_date)}</p>
              </div>
            ` : ''}
          </div>
        </div>
      </div>

      <!-- Tabs -->
      <div class="card mb-6">
        <div class="flex border-b overflow-x-auto" style="border-color:var(--border)" id="profile-tabs">
          <button onclick="showProfileTab('stats', this)" class="profile-tab active flex items-center gap-2 whitespace-nowrap">
            <i class="fas fa-chart-bar"></i> Statistiques
          </button>
          <button onclick="showProfileTab('edit', this)" class="profile-tab flex items-center gap-2 whitespace-nowrap">
            <i class="fas fa-edit"></i> Modifier le profil
          </button>
          <button onclick="showProfileTab('security', this)" class="profile-tab flex items-center gap-2 whitespace-nowrap">
            <i class="fas fa-shield-alt"></i> Sécurité
          </button>
          <button onclick="showProfileTab('notifications', this)" class="profile-tab flex items-center gap-2 whitespace-nowrap">
            <i class="fas fa-bell"></i> Notifications
            ${notifications.filter(n => !n.is_read).length > 0 ? `<span class="notif-dot"></span>` : ''}
          </button>
        </div>

        <!-- Tab: Stats -->
        <div id="profile-tab-stats" class="p-6">
          <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            ${[
              { icon: 'book-open', label: 'Leçons complétées', value: stats.completed_lessons || 0, color: 'text-blue-500', bg: 'bg-blue-50' },
              { icon: 'question-circle', label: 'Quiz tentés', value: stats.quiz_attempts || 0, color: 'text-purple-500', bg: 'bg-purple-50' },
              { icon: 'chart-bar', label: 'Score moyen', value: `${stats.avg_quiz_score || 0}%`, color: 'text-green-500', bg: 'bg-green-50' },
              { icon: 'trophy', label: 'Quiz réussis', value: stats.passed_quizzes || 0, color: 'text-yellow-500', bg: 'bg-yellow-50' },
            ].map(s => `
              <div class="profile-stat-item">
                <div class="w-10 h-10 ${s.bg} rounded-xl flex items-center justify-center mx-auto mb-2">
                  <i class="fas fa-${s.icon} ${s.color}"></i>
                </div>
                <p class="text-2xl font-black" style="color:var(--text-heading)">${s.value}</p>
                <p class="text-xs mt-1" style="color:var(--text-muted)">${s.label}</p>
              </div>
            `).join('')}
          </div>

          <!-- Score moyen avec barre -->
          <div class="rounded-2xl p-4 mb-4" style="background:var(--bg);border:1px solid var(--border)">
            <div class="flex justify-between items-center mb-2">
              <span class="font-semibold text-sm" style="color:var(--text-secondary)">Score moyen aux quiz</span>
              <span class="font-black text-lg" style="color:var(--primary)">${stats.avg_quiz_score || 0}%</span>
            </div>
            <div class="progress-bar">
              <div class="progress-fill" style="width:${stats.avg_quiz_score || 0}%"></div>
            </div>
            <p class="text-xs mt-2" style="color:var(--text-muted)">
              ${(stats.avg_quiz_score || 0) >= 60 ? '🎉 Excellent niveau !' : (stats.avg_quiz_score || 0) >= 40 ? '💪 Continue tes efforts !' : '📚 Révise davantage !'}
            </p>
          </div>

          <!-- Abonnement status -->
          <div class="rounded-2xl p-4 flex items-center justify-between" style="background:var(--primary-light);border:1px solid var(--border)">
            <div class="flex items-center gap-3">
              <span class="text-2xl">${isPremium ? '⭐' : '🆓'}</span>
              <div>
                <p class="font-bold" style="color:var(--text-heading)">${subscription?.plan_name || 'Plan Gratuit'}</p>
                <p class="text-xs" style="color:var(--text-muted)">${isPremium ? `Expire le ${formatDate(subscription.end_date)}` : 'Accès à tout le contenu'}</p>
              </div>
            </div>
            <button onclick="navigateTo('subscription')" class="btn-primary text-sm">
              ${isPremium ? 'Renouveler' : 'Soutenir →'}
            </button>
          </div>
        </div>

        <!-- Tab: Edit Profile -->
        <div id="profile-tab-edit" class="p-6 hidden">
          <form onsubmit="saveProfile(event)" class="profile-form space-y-5">
            <div>
              <label class="block text-sm font-semibold mb-2" style="color:var(--text-secondary)">Nom complet</label>
              <input type="text" id="profile-name" value="${currentUser.full_name}" placeholder="Votre nom complet" required>
            </div>
            <div>
              <label class="block text-sm font-semibold mb-2" style="color:var(--text-secondary)">Adresse e-mail</label>
              <input type="email" value="${currentUser.email}" disabled style="opacity:0.6;cursor:not-allowed" title="L'email ne peut pas être modifié">
              <p class="text-xs mt-1" style="color:var(--text-muted)"><i class="fas fa-lock mr-1"></i>L'adresse e-mail ne peut pas être modifiée</p>
            </div>
            <div>
              <label class="block text-sm font-semibold mb-2" style="color:var(--text-secondary)">Classe</label>
              <select id="profile-class">
                <option value="terminale_a1" ${currentUser.class_level === 'terminale_a1' ? 'selected' : ''}>Terminale A1 – Lettres & Sciences Humaines</option>
                <option value="terminale_a2" ${currentUser.class_level === 'terminale_a2' ? 'selected' : ''}>Terminale A2 – Sciences Sociales & Économie</option>
              </select>
            </div>
            <div>
              <label class="block text-sm font-semibold mb-2" style="color:var(--text-secondary)">Avatar (URL d'image optionnel)</label>
              <input type="url" id="profile-avatar" value="${currentUser.avatar || ''}" placeholder="https://exemple.com/photo.jpg">
              <p class="text-xs mt-1" style="color:var(--text-muted)">Entrez l'URL d'une image pour votre avatar</p>
            </div>
            <div class="flex gap-3 pt-2">
              <button type="submit" id="save-profile-btn" class="btn-primary flex-1 justify-center">
                <i class="fas fa-save"></i> Enregistrer les modifications
              </button>
            </div>
          </form>
        </div>

        <!-- Tab: Security -->
        <div id="profile-tab-security" class="p-6 hidden">
          <div class="space-y-5">
            <div class="rounded-2xl p-5" style="background:var(--bg);border:1px solid var(--border)">
              <h3 class="font-bold mb-4 flex items-center gap-2" style="color:var(--text-heading)">
                <i class="fas fa-key text-yellow-500"></i> Changer le mot de passe
              </h3>
              <form onsubmit="changePassword(event)" class="profile-form space-y-4">
                <div>
                  <label class="block text-sm font-semibold mb-2" style="color:var(--text-secondary)">Mot de passe actuel</label>
                  <div class="relative">
                    <input type="password" id="current-password" placeholder="••••••••" required>
                    <button type="button" onclick="togglePasswordVisibility('current-password', this)" class="absolute right-3 top-1/2 transform -translate-y-1/2" style="color:var(--text-muted)">
                      <i class="fas fa-eye text-sm"></i>
                    </button>
                  </div>
                </div>
                <div>
                  <label class="block text-sm font-semibold mb-2" style="color:var(--text-secondary)">Nouveau mot de passe</label>
                  <input type="password" id="new-password" placeholder="Minimum 6 caractères" required>
                </div>
                <div>
                  <label class="block text-sm font-semibold mb-2" style="color:var(--text-secondary)">Confirmer le nouveau mot de passe</label>
                  <input type="password" id="confirm-password" placeholder="Répétez le nouveau mot de passe" required>
                </div>
                <button type="submit" class="btn-primary">
                  <i class="fas fa-lock"></i> Mettre à jour le mot de passe
                </button>
              </form>
            </div>

            <div class="rounded-2xl p-5" style="background:var(--bg);border:1px solid var(--border)">
              <h3 class="font-bold mb-2 flex items-center gap-2" style="color:var(--text-heading)">
                <i class="fas fa-sign-out-alt text-red-500"></i> Déconnexion
              </h3>
              <p class="text-sm mb-4" style="color:var(--text-secondary)">Déconnectez-vous de votre compte sur cet appareil.</p>
              <button onclick="logout()" class="btn-secondary text-red-500 border-red-200 hover:bg-red-50">
                <i class="fas fa-sign-out-alt mr-2"></i> Se déconnecter
              </button>
            </div>
          </div>
        </div>

        <!-- Tab: Notifications -->
        <div id="profile-tab-notifications" class="p-6 hidden">
          <div class="flex items-center justify-between mb-4">
            <h3 class="font-bold" style="color:var(--text-heading)">Toutes les notifications</h3>
            <button onclick="markNotifsRead()" class="text-xs font-semibold hover:underline" style="color:var(--primary)">
              <i class="fas fa-check-double mr-1"></i>Tout marquer comme lu
            </button>
          </div>
          <div class="space-y-2 max-h-96 overflow-y-auto">
            ${notifications.length ? notifications.map(n => `
              <div class="flex items-start gap-3 p-3 rounded-xl transition ${n.is_read ? '' : 'border-l-4 border-indigo-400'}" style="background:${n.is_read ? 'var(--bg)' : 'var(--primary-light)'}">
                <span class="text-lg flex-shrink-0">${n.type === 'success' ? '✅' : n.type === 'warning' ? '⚠️' : n.type === 'error' ? '❌' : 'ℹ️'}</span>
                <div class="flex-1 min-w-0">
                  <p class="text-sm font-semibold" style="color:var(--text-heading)">${n.title}</p>
                  <p class="text-xs mt-0.5" style="color:var(--text-secondary)">${n.message}</p>
                  <p class="text-xs mt-1" style="color:var(--text-muted)">${formatDate(n.created_at)}</p>
                </div>
                ${!n.is_read ? '<div class="notif-dot flex-shrink-0 mt-1"></div>' : ''}
              </div>
            `).join('') : '<div class="text-center py-8"><span class="text-4xl block mb-2">🔔</span><p class="text-sm" style="color:var(--text-muted)">Aucune notification pour le moment</p></div>'}
          </div>
        </div>
      </div>
    </div>
  `;
}

function showProfileTab(tab, btn) {
  // Masquer tous les onglets
  document.querySelectorAll('[id^="profile-tab-"]').forEach(el => el.classList.add('hidden'));
  // Retirer le active des boutons
  document.querySelectorAll('.profile-tab').forEach(el => el.classList.remove('active'));
  // Afficher l'onglet sélectionné
  document.getElementById(`profile-tab-${tab}`)?.classList.remove('hidden');
  btn.classList.add('active');
}

async function saveProfile(e) {
  e.preventDefault();
  const btn = document.getElementById('save-profile-btn');
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enregistrement...';
  btn.disabled = true;

  const full_name = document.getElementById('profile-name')?.value;
  const class_level = document.getElementById('profile-class')?.value;
  const avatar = document.getElementById('profile-avatar')?.value;

  const res = await apiCall('PUT', '/auth/profile', { full_name, class_level, avatar });

  if (res.ok) {
    currentUser = { ...currentUser, full_name, class_level, avatar };
    localStorage.setItem('terminale_mg_user', JSON.stringify(currentUser));
    showToast('Profil mis à jour avec succès ! ✅', 'success');
    renderApp();
    setTimeout(() => navigateTo('profile'), 100);
  } else {
    showToast(res.data.error || 'Erreur lors de la mise à jour', 'error');
    btn.innerHTML = '<i class="fas fa-save"></i> Enregistrer les modifications';
    btn.disabled = false;
  }
}

async function changePassword(e) {
  e.preventDefault();
  const currentPwd = document.getElementById('current-password')?.value;
  const newPwd = document.getElementById('new-password')?.value;
  const confirmPwd = document.getElementById('confirm-password')?.value;

  if (newPwd !== confirmPwd) {
    showToast('Les mots de passe ne correspondent pas', 'error');
    return;
  }
  if (newPwd.length < 6) {
    showToast('Le mot de passe doit comporter au moins 6 caractères', 'error');
    return;
  }

  const res = await apiCall('PUT', '/auth/change-password', {
    current_password: currentPwd,
    new_password: newPwd
  });

  if (res.ok) {
    showToast('Mot de passe mis à jour avec succès !', 'success');
    document.getElementById('current-password').value = '';
    document.getElementById('new-password').value = '';
    document.getElementById('confirm-password').value = '';
  } else {
    showToast(res.data.error || 'Erreur lors du changement de mot de passe', 'error');
  }
}

function togglePasswordVisibility(inputId, btn) {
  const input = document.getElementById(inputId);
  if (!input) return;
  if (input.type === 'password') {
    input.type = 'text';
    btn.innerHTML = '<i class="fas fa-eye-slash text-sm"></i>';
  } else {
    input.type = 'password';
    btn.innerHTML = '<i class="fas fa-eye text-sm"></i>';
  }
}

function showAvatarModal() {
  const html = `
    <div>
      <h3 class="text-xl font-bold mb-4" style="color:var(--text-heading)">
        <i class="fas fa-camera mr-2 text-indigo-500"></i>Changer la photo de profil
      </h3>
      <p class="text-sm mb-5" style="color:var(--text-secondary)">Entrez l'URL d'une image pour votre avatar :</p>
      <input type="url" id="avatar-url-input" placeholder="https://exemple.com/ma-photo.jpg"
        class="w-full mb-4" value="${currentUser.avatar || ''}">
      <div id="avatar-preview" class="text-center mb-4 ${currentUser.avatar ? '' : 'hidden'}">
        <img src="${currentUser.avatar || ''}" alt="Preview" class="w-20 h-20 rounded-full mx-auto object-cover border-4 border-indigo-200">
        <p class="text-xs mt-1" style="color:var(--text-muted)">Aperçu</p>
      </div>
      <div class="flex gap-3">
        <button onclick="closeModal()" class="btn-secondary flex-1 justify-center">Annuler</button>
        <button onclick="applyAvatar()" class="btn-primary flex-1 justify-center">
          <i class="fas fa-check"></i> Appliquer
        </button>
      </div>
    </div>
  `;
  showModal(html);

  // Live preview
  document.getElementById('avatar-url-input')?.addEventListener('input', function() {
    const preview = document.getElementById('avatar-preview');
    const img = preview?.querySelector('img');
    if (this.value && img) {
      img.src = this.value;
      preview.classList.remove('hidden');
    } else {
      preview?.classList.add('hidden');
    }
  });
}

async function applyAvatar() {
  const url = document.getElementById('avatar-url-input')?.value;
  const res = await apiCall('PUT', '/auth/profile', {
    full_name: currentUser.full_name,
    class_level: currentUser.class_level,
    avatar: url
  });
  if (res.ok) {
    currentUser.avatar = url;
    closeModal();
    showToast('Photo de profil mise à jour !', 'success');
    renderApp();
    setTimeout(() => navigateTo('profile'), 100);
  } else {
    showToast(res.data.error || 'Erreur', 'error');
  }
}

function showEditProfileModal() {
  navigateTo('profile');
  setTimeout(() => {
    const editBtn = document.querySelector('.profile-tab:nth-child(2)');
    if (editBtn) editBtn.click();
  }, 200);
}
async function init() {
  const hash = window.location.hash.replace('#', '');
  if (hash && routes[hash]) currentRoute = hash;

  // Auth optionnelle au démarrage
  await checkAuth();

  const loadingScreen = document.getElementById('loading-screen');
  if (loadingScreen) {
    loadingScreen.style.opacity = '0';
    loadingScreen.style.transition = 'opacity 0.5s';
    setTimeout(() => loadingScreen.remove(), 500);
  }

  renderApp();
}

init();
